import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar.tsx';
import { SearchHero } from './components/SearchHero.tsx';
import { HotelCard } from './components/HotelCard.tsx';
import { HotelDetailsModal } from './components/HotelDetailsModal.tsx';
import { BookingPaymentModal } from './components/BookingPaymentModal.tsx';
import { BookingSuccessModal } from './components/BookingSuccessModal.tsx';
import { MyBookingsView } from './components/MyBookingsView.tsx';
import { SmartStayPlannerView } from './components/SmartStayPlannerView.tsx';
import { RecommendationsView } from './components/RecommendationsView.tsx';
import { AdminDashboardView } from './components/AdminDashboardView.tsx';
import { AuthModal } from './components/AuthModal.tsx';
import { api, getStoredUser, clearStoredAuth } from './services/api.ts';
import { Hotel, RoomType, PriceBreakdown, Reservation, User } from './types/index.ts';
import { Sparkles, Shield, Award, Compass, HeartHandshake } from 'lucide-react';

export default function App() {
  // Navigation
  const [activeTab, setActiveTab] = useState<'hotels' | 'planner' | 'recommendations' | 'bookings' | 'admin'>('hotels');

  // Dark/Light Mode with localStorage persistence
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('luxestay_theme');
    return saved !== null ? saved === 'dark' : true;
  });

  useEffect(() => {
    localStorage.setItem('luxestay_theme', darkMode ? 'dark' : 'light');
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Auth User
  const [currentUser, setCurrentUser] = useState<User | null>(() => getStoredUser());
  const [authModalOpen, setAuthModalOpen] = useState(false);

  // Sync current user on mount
  useEffect(() => {
    api.getCurrentUser().then(u => {
      if (u) setCurrentUser(u);
    }).catch(() => {});
  }, []);

  // Search Parameters
  const [selectedCity, setSelectedCity] = useState<string>('All Cities');
  const [checkIn, setCheckIn] = useState<string>(() => {
    const d = new Date();
    return d.toISOString().split('T')[0];
  });
  const [checkOut, setCheckOut] = useState<string>(() => {
    const d = new Date(Date.now() + 2 * 86400000);
    return d.toISOString().split('T')[0];
  });
  const [guestsCount, setGuestsCount] = useState<number>(2);
  const [roomsCount, setRoomsCount] = useState<number>(1);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  // Data
  const [hotels, setHotels] = useState<Hotel[]>([]);
  const [loadingHotels, setLoadingHotels] = useState(true);
  const [userBookingsCount, setUserBookingsCount] = useState(0);

  // Modals
  const [viewingHotel, setViewingHotel] = useState<Hotel | null>(null);
  const [checkoutBooking, setCheckoutBooking] = useState<{
    hotel: Hotel;
    roomType: RoomType;
    pricing: PriceBreakdown;
  } | null>(null);
  const [confirmedReservation, setConfirmedReservation] = useState<Reservation | null>(null);

  // Fetch hotels
  const fetchHotels = async () => {
    try {
      setLoadingHotels(true);
      const data = await api.getHotels();
      setHotels(data);
    } catch (err) {
      console.error('Failed to load hotels:', err);
    } finally {
      setLoadingHotels(false);
    }
  };

  const fetchBookingsCount = async () => {
    try {
      const res = await api.getReservations();
      setUserBookingsCount(res.filter(r => r.status === 'CONFIRMED' || r.status === 'PENDING').length);
    } catch {}
  };

  useEffect(() => {
    fetchHotels();
    fetchBookingsCount();
  }, [currentUser]);

  // Auth Handlers
  const handleLoginSuccess = (user: User) => {
    setCurrentUser(user);
    if (user.role === 'ADMIN') {
      setActiveTab('admin');
    }
    fetchBookingsCount();
  };

  const handleLogout = () => {
    clearStoredAuth();
    setCurrentUser(null);
    if (activeTab === 'admin') {
      setActiveTab('hotels');
    }
  };

  // Open Room Selection Modal
  const handleSelectHotel = (hotel: Hotel) => {
    setViewingHotel(hotel);
  };

  // Trigger Checkout from Hotel Details
  const handleSelectRoomForCheckout = (hotel: Hotel, roomType: RoomType, pricing: PriceBreakdown) => {
    setViewingHotel(null);
    setCheckoutBooking({ hotel, roomType, pricing });
  };

  // Trigger Checkout directly from Planner or Recommendations
  const handleDirectRoomBooking = async (hotel: Hotel, roomType: RoomType) => {
    try {
      const pricing = await api.calculateRate(roomType.id, checkIn, checkOut, roomsCount);
      setCheckoutBooking({ hotel, roomType, pricing });
    } catch (err) {
      console.error('Rate calculation error:', err);
    }
  };

  // Booking Success
  const handleBookingSuccess = (res: Reservation) => {
    setCheckoutBooking(null);
    setConfirmedReservation(res);
    fetchBookingsCount();
  };

  // Filtered Hotels
  const filteredHotels = hotels.filter((h) => {
    // City filter
    if (selectedCity !== 'All Cities' && h.city.toLowerCase() !== selectedCity.toLowerCase()) {
      return false;
    }
    // Category filter
    if (selectedCategory !== 'All') {
      const catLower = selectedCategory.toLowerCase();
      const tagsLower = h.tags.map(t => t.toLowerCase());
      const vibeLower = h.vibe.toLowerCase();
      if (!tagsLower.some(t => t.includes(catLower)) && !vibeLower.includes(catLower)) {
        return false;
      }
    }
    return true;
  });

  return (
    <div className={`min-h-screen transition-colors duration-200 ${
      darkMode ? 'bg-stone-950 text-stone-100' : 'bg-stone-50 text-stone-900'
    }`}>
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currentUser={currentUser}
        onOpenAuth={() => setAuthModalOpen(true)}
        onLogout={handleLogout}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        bookingCount={userBookingsCount}
      />

      {/* Main View Router */}
      <main className="pb-16">
        {activeTab === 'hotels' && (
          <div>
            {/* Search Hero */}
            <SearchHero
              darkMode={darkMode}
              selectedCity={selectedCity}
              setSelectedCity={setSelectedCity}
              checkIn={checkIn}
              setCheckIn={setCheckIn}
              checkOut={checkOut}
              setCheckOut={setCheckOut}
              guestsCount={guestsCount}
              setGuestsCount={setGuestsCount}
              roomsCount={roomsCount}
              setRoomsCount={setRoomsCount}
              selectedCategory={selectedCategory}
              setSelectedCategory={setSelectedCategory}
              onSearch={() => {}}
            />

            {/* Properties Collection Grid */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2 mb-8">
                <div>
                  <span className="text-xs font-semibold uppercase tracking-widest text-amber-500">
                    Handcrafted Luxury
                  </span>
                  <h2 className="font-serif text-3xl sm:text-4xl font-bold tracking-tight">
                    Featured Indian Properties & Palaces
                  </h2>
                </div>
                <span className="text-xs text-stone-400">
                  Showing {filteredHotels.length} luxury havens
                </span>
              </div>

              {loadingHotels ? (
                <div className="py-24 flex flex-col items-center justify-center gap-3 text-stone-400">
                  <div className="w-8 h-8 rounded-full border-2 border-amber-500 border-t-transparent animate-spin" />
                  <span className="text-xs font-medium">Loading portfolio...</span>
                </div>
              ) : filteredHotels.length === 0 ? (
                <div className="py-16 text-center text-stone-400">
                  No properties match your active search filters. Try selecting 'All Cities' or 'All' categories.
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredHotels.map((hotel) => (
                    <HotelCard
                      key={hotel.id}
                      hotel={hotel}
                      onSelect={handleSelectHotel}
                      darkMode={darkMode}
                    />
                  ))}
                </div>
              )}

              {/* Brand Philosophy Trust Section */}
              <div className="mt-20 pt-12 border-t border-stone-800 grid grid-cols-1 md:grid-cols-3 gap-8 text-center sm:text-left">
                <div className="space-y-2">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-500 flex items-center justify-center mb-3 mx-auto sm:mx-0">
                    <Award className="w-5 h-5" />
                  </div>
                  <h3 className="font-serif text-lg font-bold">Guaranteed Suite Reservation</h3>
                  <p className="text-xs text-stone-400 leading-relaxed">
                    Enterprise-grade 10% overbooking buffer algorithms protect your stay without the risk of displacement.
                  </p>
                </div>

                <div className="space-y-2">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-500 flex items-center justify-center mb-3 mx-auto sm:mx-0">
                    <Shield className="w-5 h-5" />
                  </div>
                  <h3 className="font-serif text-lg font-bold">Dynamic Yield Pricing Transparency</h3>
                  <p className="text-xs text-stone-400 leading-relaxed">
                    Clear breakdown of base tariffs, weekend factors, and seasonal occupancy surges with zero hidden fees.
                  </p>
                </div>

                <div className="space-y-2">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-500 flex items-center justify-center mb-3 mx-auto sm:mx-0">
                    <HeartHandshake className="w-5 h-5" />
                  </div>
                  <h3 className="font-serif text-lg font-bold">Automated Tiered Refunds</h3>
                  <p className="text-xs text-stone-400 leading-relaxed">
                    100% full refund if cancelled &gt; 48 hours prior to check-in, 50% between 24–48 hours, instantly credited.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'planner' && (
          <SmartStayPlannerView
            darkMode={darkMode}
            onBookRoom={handleDirectRoomBooking}
          />
        )}

        {activeTab === 'recommendations' && (
          <RecommendationsView
            darkMode={darkMode}
            onSelectProperty={handleSelectHotel}
            onBookRoom={handleDirectRoomBooking}
          />
        )}

        {activeTab === 'bookings' && (
          <MyBookingsView
            darkMode={darkMode}
            onExploreHotels={() => setActiveTab('hotels')}
          />
        )}

        {activeTab === 'admin' && (
          <AdminDashboardView
            darkMode={darkMode}
            onSwitchToStorefront={() => setActiveTab('hotels')}
          />
        )}
      </main>

      {/* Footer */}
      <footer className={`border-t py-12 transition-colors ${
        darkMode ? 'border-stone-800 bg-stone-950 text-stone-400' : 'border-stone-200 bg-white text-stone-500'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-2">
            <span className="font-serif text-lg font-bold text-amber-500 tracking-wider">
              LuxeStay
            </span>
            <span className="text-stone-500">·</span>
            <span>Grand Indian Hospitality & Residences</span>
          </div>

          <div className="flex items-center gap-6">
            <span>Hyderabad</span>
            <span>·</span>
            <span>Mumbai</span>
            <span>·</span>
            <span>Goa</span>
            <span>·</span>
            <span>Bangalore</span>
            <span>·</span>
            <span>Delhi</span>
          </div>

          <div className="text-stone-500">
            © 2026 LuxeStay Inc. All Rights Reserved.
          </div>
        </div>
      </footer>

      {/* Modals */}
      {viewingHotel && (
        <HotelDetailsModal
          hotel={viewingHotel}
          initialCheckIn={checkIn}
          initialCheckOut={checkOut}
          initialGuests={guestsCount}
          initialRooms={roomsCount}
          onClose={() => setViewingHotel(null)}
          onSelectRoom={handleSelectRoomForCheckout}
          darkMode={darkMode}
        />
      )}

      {checkoutBooking && (
        <BookingPaymentModal
          hotel={checkoutBooking.hotel}
          roomType={checkoutBooking.roomType}
          pricing={checkoutBooking.pricing}
          checkIn={checkIn}
          checkOut={checkOut}
          numRooms={roomsCount}
          guestsCount={guestsCount}
          currentUser={currentUser}
          onClose={() => setCheckoutBooking(null)}
          onSuccess={handleBookingSuccess}
          darkMode={darkMode}
        />
      )}

      {confirmedReservation && (
        <BookingSuccessModal
          reservation={confirmedReservation}
          onClose={() => setConfirmedReservation(null)}
          onViewBookings={() => {
            setConfirmedReservation(null);
            setActiveTab('bookings');
          }}
          darkMode={darkMode}
        />
      )}

      {authModalOpen && (
        <AuthModal
          onClose={() => setAuthModalOpen(false)}
          onLoginSuccess={handleLoginSuccess}
          darkMode={darkMode}
        />
      )}
    </div>
  );
}

export type UserRole = 'USER' | 'ADMIN';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  phone: string;
  createdAt: string;
}

export interface Hotel {
  id: string;
  name: string;
  city: string;
  neighborhood: string;
  address: string;
  rating: number;
  reviewCount: number;
  imageUrl: string;
  galleryUrls: string[];
  description: string;
  amenities: string[];
  startingPrice: number;
  tags: string[];
  vibe: 'Heritage' | 'Modern' | 'Beach' | 'Wellness';
}

export type RoomTier = 'Standard' | 'Deluxe' | 'Junior Suite' | 'Presidential' | 'Specialty';

export interface RoomType {
  id: string;
  hotelId: string;
  name: string;
  tier: RoomTier;
  basePrice: number;
  capacityGuests: number;
  bedType: string;
  squareFeet: number;
  amenities: string[];
  totalPhysicalRooms: number;
  imageUrl: string;
  description: string;
  currentlyBooked?: number;
  overbookingCap?: number;
  remainingInventory?: number;
  isSoldOut?: boolean;
}

export interface PhysicalRoom {
  id: string;
  hotelId: string;
  roomTypeId: string;
  roomNumber: string;
  floor: number;
  status: 'AVAILABLE' | 'OCCUPIED' | 'MAINTENANCE';
}

export type ReservationStatus = 'PENDING' | 'CONFIRMED' | 'CANCELLED' | 'PAYMENT_FAILED';
export type PaymentStatus = 'SUCCESS' | 'FAILED' | 'REFUNDED' | 'PENDING';
export type PaymentMethod = 'CARD' | 'UPI' | 'NET_BANKING' | 'WALLET' | 'PAY_AT_HOTEL' | 'VOUCHER';

export interface PriceBreakdown {
  baseNightlyRate: number;
  occupancyFactor: number;
  occupancyLabel: string;
  weekendMultiplier: number;
  surgeMultiplier: number;
  effectiveNightlyRate: number;
  numberOfNights: number;
  subtotal: number;
  taxAmount: number; // 18% GST
  totalAmount: number;
  dates: {
    date: string;
    isWeekend: boolean;
    nightlyRate: number;
  }[];
}

export interface Reservation {
  id: string;
  bookingRef: string; // LX-XXXXXX
  userId: string;
  guestName: string;
  guestEmail: string;
  guestPhone: string;
  hotelId: string;
  hotelName?: string;
  roomTypeId: string;
  roomTypeName?: string;
  roomTier?: RoomTier;
  checkIn: string;
  checkOut: string;
  numRooms: number;
  guestsCount: number;
  totalAmount: number;
  currency: string;
  status: ReservationStatus;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  idempotencyKey: string;
  refundAmount?: number;
  cancellationReason?: string;
  createdAt: string;
}

export interface PaymentRecord {
  id: string;
  reservationId: string;
  transactionRef: string;
  method: PaymentMethod;
  amount: number;
  status: 'SUCCESS' | 'FAILED' | 'REFUNDED';
  failureReason?: string;
  createdAt: string;
}

export interface BookingRequest {
  idempotencyKey: string;
  userId?: string;
  hotelId: string;
  roomTypeId: string;
  checkIn: string;
  checkOut: string;
  numRooms: number;
  guestsCount: number;
  guestName: string;
  guestEmail: string;
  guestPhone: string;
  paymentMethod: PaymentMethod;
  paymentDetails: {
    simulateDecline?: boolean;
    cardNumber?: string;
    cardHolder?: string;
    cardExpiry?: string;
    cardCvv?: string;
    cardBrand?: string;
    upiId?: string;
    bankName?: string;
    walletProvider?: string;
    voucherCode?: string;
  };
}

export interface RefundPreview {
  reservationId: string;
  bookingRef: string;
  checkIn: string;
  hoursUntilCheckIn: number;
  refundPercentage: number;
  originalAmount: number;
  refundAmount: number;
  cancellationPolicyDescription: string;
}

export interface PersonaRecommendation {
  hotel: Hotel;
  matchScore: number;
  highlights: string[];
  recommendedRoomType: RoomType;
  explanation: string;
}

export interface StayPlannerPlan {
  destination: string;
  purpose: string;
  vibe: string;
  recommendedHotel: Hotel;
  recommendedRoom: RoomType;
  priceEstimate: number;
  rationale: string;
  days: {
    dayNumber: number;
    title: string;
    morning: { time: string; title: string; desc: string };
    afternoon: { time: string; title: string; desc: string };
    evening: { time: string; title: string; desc: string };
    diningHighlight: { name: string; cuisine: string; note: string };
  }[];
}

export interface AdminAnalytics {
  grossBookingValue: number;
  activeOccupancyRate: number;
  averageDailyRate: number;
  revPar: number;
  totalPhysicalRooms: number;
  totalOccupiedRooms: number;
  totalActiveStays: number;
  cancellationRate: number;
  revenueByCity: { city: string; revenue: number }[];
  occupancyByProperty: { hotelName: string; occupancy: number; activeBookings: number }[];
}

export interface TestResultItem {
  id: number;
  name: string;
  category: 'AUTH' | 'BOOKING' | 'PAYMENT' | 'REFUND' | 'OVERBOOKING' | 'RECOMMENDATION';
  status: 'PASSED' | 'FAILED';
  durationMs: number;
  details: string;
  diagnostics?: Record<string, any>;
}

export interface TestSuiteSummary {
  totalTests: number;
  passedTests: number;
  failedTests: number;
  executionTimeMs: number;
  timestamp: string;
  results: TestResultItem[];
}

import React from 'react';
import { Crown, Sun, Moon, ShieldCheck, LogOut, User as UserIcon, Eye } from 'lucide-react';
import { User } from '../types/index.ts';

interface NavbarProps {
  activeTab: 'hotels' | 'planner' | 'recommendations' | 'bookings' | 'admin';
  setActiveTab: (tab: 'hotels' | 'planner' | 'recommendations' | 'bookings' | 'admin') => void;
  currentUser: User | null;
  onOpenAuth: () => void;
  onLogout: () => void;
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
  bookingCount?: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  currentUser,
  onOpenAuth,
  onLogout,
  darkMode,
  setDarkMode,
  bookingCount = 0
}) => {
  const isAdminView = activeTab === 'admin';

  return (
    <header className={`sticky top-0 z-40 border-b backdrop-blur-md transition-colors duration-200 ${
      darkMode 
        ? 'bg-stone-900/90 border-stone-800 text-stone-100' 
        : 'bg-stone-50/95 border-stone-200 text-stone-900 shadow-xs'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-3">
          <div 
            onClick={() => setActiveTab('hotels')}
            className="flex items-center gap-2.5 cursor-pointer group shrink-0"
          >
            <div className="w-10 h-10 rounded-lg bg-gradient-to-tr from-amber-600 via-amber-500 to-amber-400 flex items-center justify-center text-stone-950 shadow-md group-hover:scale-105 transition-transform duration-200">
              <Crown className="w-5 h-5 stroke-[2.2]" />
            </div>
            <div className="flex flex-col">
              <span className="font-serif text-2xl font-bold tracking-wider text-amber-500 group-hover:text-amber-400 transition-colors">
                LuxeStay
              </span>
              {!isAdminView && (
                <span className="text-[10px] tracking-widest uppercase font-medium text-stone-400 -mt-1">
                  Grand Suites & Residencies
                </span>
              )}
            </div>
          </div>

          {isAdminView && (
            <div className="flex items-center gap-2">
              <span className="text-stone-500 hidden sm:inline">·</span>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full border border-amber-500/40 bg-amber-500/10 text-amber-400 text-xs font-bold tracking-wider uppercase">
                <ShieldCheck className="w-3.5 h-3.5 text-amber-500" />
                <span>Operations Portal</span>
              </div>
            </div>
          )}
        </div>

        {/* Zone 2: Navigation Links (When not in admin view) */}
        {!isAdminView ? (
          <nav className="hidden md:flex items-center gap-7 text-sm font-medium">
            <button
              onClick={() => setActiveTab('hotels')}
              className={`transition-colors py-1 relative ${
                activeTab === 'hotels'
                  ? 'text-amber-500 font-semibold'
                  : darkMode ? 'text-stone-300 hover:text-stone-100' : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              Hotels & Palaces
              {activeTab === 'hotels' && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-500 rounded-full" />
              )}
            </button>

            <button
              onClick={() => setActiveTab('planner')}
              className={`transition-colors py-1 relative ${
                activeTab === 'planner'
                  ? 'text-amber-500 font-semibold'
                  : darkMode ? 'text-stone-300 hover:text-stone-100' : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              Smart Stay Planner
              {activeTab === 'planner' && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-500 rounded-full" />
              )}
            </button>

            <button
              onClick={() => setActiveTab('recommendations')}
              className={`transition-colors py-1 relative ${
                activeTab === 'recommendations'
                  ? 'text-amber-500 font-semibold'
                  : darkMode ? 'text-stone-300 hover:text-stone-100' : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              Persona Match
              {activeTab === 'recommendations' && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-500 rounded-full" />
              )}
            </button>

            <button
              onClick={() => setActiveTab('bookings')}
              className={`transition-colors py-1 relative flex items-center gap-1.5 ${
                activeTab === 'bookings'
                  ? 'text-amber-500 font-semibold'
                  : darkMode ? 'text-stone-300 hover:text-stone-100' : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              My Bookings
              {bookingCount > 0 && (
                <span className="inline-flex items-center justify-center text-[11px] font-bold w-4 h-4 rounded-full bg-amber-500/20 text-amber-500">
                  {bookingCount}
                </span>
              )}
              {activeTab === 'bookings' && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-500 rounded-full" />
              )}
            </button>

            {/* Admin Portal link */}
            <button
              onClick={() => setActiveTab('admin')}
              className="transition-colors py-1 relative flex items-center gap-1.5 text-amber-500/80 hover:text-amber-400"
            >
              <ShieldCheck className="w-4 h-4 text-amber-500" />
              <span>Admin Portal</span>
            </button>
          </nav>
        ) : (
          <div className="hidden md:flex items-center gap-3">
            <button
              onClick={() => setActiveTab('hotels')}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl border text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                darkMode 
                  ? 'border-stone-700 bg-stone-800/80 hover:bg-stone-700 hover:border-amber-500 text-stone-200 hover:text-white' 
                  : 'border-stone-300 bg-white hover:bg-stone-100 hover:border-amber-500 text-stone-700'
              }`}
            >
              <Eye className="w-3.5 h-3.5 text-amber-500" />
              <span>Storefront Preview</span>
            </button>
          </div>
        )}

        {/* Zone 3: Actions (Theme Toggle + Auth Profile) */}
        <div className="flex items-center gap-3">
          {/* Storefront button for mobile admin view */}
          {isAdminView && (
            <button
              onClick={() => setActiveTab('hotels')}
              className="md:hidden flex items-center gap-1 px-2.5 py-1 rounded-lg border border-stone-700 text-[11px] font-semibold text-amber-400"
            >
              <Eye className="w-3 h-3 text-amber-500" />
              <span>Storefront</span>
            </button>
          )}

          {/* Dark / Light Mode Toggle */}
          <button
            onClick={() => setDarkMode(!darkMode)}
            aria-label="Toggle dark mode"
            className={`p-2 rounded-lg border transition-colors ${
              darkMode
                ? 'border-stone-800 text-stone-300 hover:text-amber-400 hover:border-stone-700 bg-stone-800/50'
                : 'border-stone-300 text-stone-600 hover:text-amber-600 hover:border-stone-400 bg-white'
            }`}
          >
            {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* User Auth Profile Pill or Sign In Button */}
          {currentUser ? (
            <div className="flex items-center gap-2">
              <div className={`flex items-center gap-2.5 px-3 py-1.5 rounded-lg border text-xs ${
                darkMode ? 'border-stone-800 bg-stone-800/60' : 'border-stone-200 bg-stone-100'
              }`}>
                <div className={`w-6 h-6 rounded-full flex items-center justify-center font-bold text-[10px] ${
                  currentUser.role === 'ADMIN' ? 'bg-amber-500 text-stone-950' : 'bg-stone-700 text-stone-200'
                }`}>
                  {currentUser.name.charAt(0)}
                </div>
                <div className="flex flex-col text-left">
                  <span className="font-medium truncate max-w-[120px] leading-tight">
                    {currentUser.name}
                  </span>
                  {currentUser.role === 'ADMIN' ? (
                    <span className="text-[9px] text-amber-400 font-bold uppercase tracking-wider">
                      STAFF ADMIN
                    </span>
                  ) : (
                    <span className="text-[10px] text-stone-400">
                      Guest
                    </span>
                  )}
                </div>
              </div>

              <button
                onClick={onLogout}
                title="Sign Out"
                className={`p-2 rounded-lg border transition-colors ${
                  darkMode ? 'border-stone-800 text-stone-400 hover:text-rose-400 hover:border-stone-700' : 'border-stone-200 text-stone-500 hover:text-rose-600'
                }`}
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              onClick={onOpenAuth}
              className="px-4 py-2 text-xs font-semibold uppercase tracking-wider text-stone-950 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 rounded-lg shadow-sm hover:shadow-md transition-all whitespace-nowrap"
            >
              Sign In
            </button>
          )}
        </div>
      </div>

      {/* Mobile nav row */}
      <div className={`md:hidden flex items-center justify-around border-t py-2 px-3 text-xs overflow-x-auto ${
        darkMode ? 'border-stone-800 bg-stone-900/90 text-stone-300' : 'border-stone-200 bg-stone-50 text-stone-600'
      }`}>
        <button
          onClick={() => setActiveTab('hotels')}
          className={`px-2 py-1 ${activeTab === 'hotels' ? 'text-amber-500 font-semibold' : ''}`}
        >
          Hotels
        </button>
        <button
          onClick={() => setActiveTab('planner')}
          className={`px-2 py-1 ${activeTab === 'planner' ? 'text-amber-500 font-semibold' : ''}`}
        >
          Stay Planner
        </button>
        <button
          onClick={() => setActiveTab('recommendations')}
          className={`px-2 py-1 ${activeTab === 'recommendations' ? 'text-amber-500 font-semibold' : ''}`}
        >
          Persona Match
        </button>
        <button
          onClick={() => setActiveTab('bookings')}
          className={`px-2 py-1 ${activeTab === 'bookings' ? 'text-amber-500 font-semibold' : ''}`}
        >
          My Bookings {bookingCount > 0 ? `(${bookingCount})` : ''}
        </button>
        {currentUser?.role === 'ADMIN' && (
          <button
            onClick={() => setActiveTab('admin')}
            className={`px-2 py-1 text-amber-500 font-semibold ${activeTab === 'admin' ? 'underline' : ''}`}
          >
            Admin
          </button>
        )}
      </div>
    </header>
  );
};

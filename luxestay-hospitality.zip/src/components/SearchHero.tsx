import React, { useState } from 'react';
import { MapPin, Calendar, Users, Search, Sparkles, Building2 } from 'lucide-react';

interface SearchHeroProps {
  darkMode: boolean;
  selectedCity: string;
  setSelectedCity: (city: string) => void;
  checkIn: string;
  setCheckIn: (date: string) => void;
  checkOut: string;
  setCheckOut: (date: string) => void;
  guestsCount: number;
  setGuestsCount: (guests: number) => void;
  roomsCount: number;
  setRoomsCount: (rooms: number) => void;
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
  onSearch: () => void;
}

export const SearchHero: React.FC<SearchHeroProps> = ({
  darkMode,
  selectedCity,
  setSelectedCity,
  checkIn,
  setCheckIn,
  checkOut,
  setCheckOut,
  guestsCount,
  setGuestsCount,
  roomsCount,
  setRoomsCount,
  selectedCategory,
  setSelectedCategory,
  onSearch
}) => {
  const [showGuestDropdown, setShowGuestDropdown] = useState(false);

  const categories = [
    'All',
    'Luxury Stay',
    'Business Trip',
    'Couple',
    'Beach & Resort',
    'Heritage',
    'Eco-Luxury'
  ];

  return (
    <div className="relative overflow-hidden mb-12">
      {/* Background Hero Banner */}
      <div className="relative h-[480px] sm:h-[520px] w-full overflow-hidden">
        <img
          src="https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=2000&q=85"
          alt="LuxeStay Royal Indian Palace"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center scale-105 transition-transform duration-1000 ease-out"
        />
        {/* Measured Contrast Scrim */}
        <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-950/60 to-stone-950/30" />
        
        {/* Editorial Text Content */}
        <div className="absolute inset-0 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col justify-center items-center text-center pb-24">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-amber-500/30 bg-amber-500/10 text-amber-400 text-xs font-medium tracking-widest uppercase mb-4 backdrop-blur-xs">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>The Premier Indian Luxury Collection</span>
          </div>

          <h1 className="font-serif text-3xl sm:text-5xl lg:text-6xl font-bold text-white tracking-tight leading-tight max-w-3xl mb-4">
            Sanctuaries of Timeless Royalty & Modern Elegance
          </h1>

          <p className="text-stone-300 text-sm sm:text-base max-w-2xl font-light leading-relaxed">
            Experience heritage palaces in Hyderabad, sea-facing residences in Mumbai, tropical Goan beachfront villas, and serene botanical sanctuaries.
          </p>
        </div>
      </div>

      {/* Floating Search Bar Card */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 -mt-20 relative z-20">
        <div className={`p-4 sm:p-6 rounded-2xl border shadow-2xl backdrop-blur-md transition-colors ${
          darkMode 
            ? 'bg-stone-900/95 border-stone-800 text-stone-100' 
            : 'bg-white/95 border-stone-200 text-stone-900'
        }`}>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
            {/* Destination Dropdown */}
            <div className={`p-3 rounded-xl border flex flex-col gap-1 transition-colors ${
              darkMode ? 'bg-stone-800/60 border-stone-700/60' : 'bg-stone-50 border-stone-200'
            }`}>
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-500">
                <MapPin className="w-3.5 h-3.5" />
                <span>Destination</span>
              </div>
              <select
                value={selectedCity}
                onChange={(e) => setSelectedCity(e.target.value)}
                className="bg-transparent font-medium text-sm focus:outline-hidden cursor-pointer"
              >
                <option value="All Cities" className={darkMode ? 'bg-stone-900' : 'bg-white'}>All Cities & Havens</option>
                <option value="Hyderabad" className={darkMode ? 'bg-stone-900' : 'bg-white'}>Hyderabad (Heritage & HITEC)</option>
                <option value="Mumbai" className={darkMode ? 'bg-stone-900' : 'bg-white'}>Mumbai (Marine Drive)</option>
                <option value="Goa" className={darkMode ? 'bg-stone-900' : 'bg-white'}>Goa (Vagator Beach)</option>
                <option value="Bangalore" className={darkMode ? 'bg-stone-900' : 'bg-white'}>Bangalore (Botanical Central)</option>
                <option value="Delhi" className={darkMode ? 'bg-stone-900' : 'bg-white'}>Delhi (Aerocity Manor)</option>
              </select>
            </div>

            {/* Check-In Date */}
            <div className={`p-3 rounded-xl border flex flex-col gap-1 transition-colors ${
              darkMode ? 'bg-stone-800/60 border-stone-700/60' : 'bg-stone-50 border-stone-200'
            }`}>
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-500">
                <Calendar className="w-3.5 h-3.5" />
                <span>Check-in Date</span>
              </div>
              <input
                type="date"
                value={checkIn}
                min={new Date().toISOString().split('T')[0]}
                onChange={(e) => setCheckIn(e.target.value)}
                className="bg-transparent font-medium text-sm focus:outline-hidden cursor-pointer"
              />
            </div>

            {/* Check-Out Date */}
            <div className={`p-3 rounded-xl border flex flex-col gap-1 transition-colors ${
              darkMode ? 'bg-stone-800/60 border-stone-700/60' : 'bg-stone-50 border-stone-200'
            }`}>
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-500">
                <Calendar className="w-3.5 h-3.5" />
                <span>Check-out Date</span>
              </div>
              <input
                type="date"
                value={checkOut}
                min={checkIn || new Date().toISOString().split('T')[0]}
                onChange={(e) => setCheckOut(e.target.value)}
                className="bg-transparent font-medium text-sm focus:outline-hidden cursor-pointer"
              />
            </div>

            {/* Guests & Search Button */}
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <button
                  type="button"
                  onClick={() => setShowGuestDropdown(!showGuestDropdown)}
                  className={`w-full p-3 rounded-xl border flex flex-col gap-1 text-left transition-colors ${
                    darkMode ? 'bg-stone-800/60 border-stone-700/60' : 'bg-stone-50 border-stone-200'
                  }`}
                >
                  <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-500">
                    <Users className="w-3.5 h-3.5" />
                    <span>Guests & Rooms</span>
                  </div>
                  <span className="font-medium text-sm truncate">
                    {guestsCount} Guests · {roomsCount} {roomsCount === 1 ? 'Room' : 'Rooms'}
                  </span>
                </button>

                {/* Dropdown panel */}
                {showGuestDropdown && (
                  <div className={`absolute top-full left-0 right-0 mt-2 p-4 rounded-xl border shadow-xl z-30 ${
                    darkMode ? 'bg-stone-900 border-stone-700' : 'bg-white border-stone-200'
                  }`}>
                    <div className="flex items-center justify-between py-2 border-b border-stone-700/40">
                      <span className="text-xs font-medium">Guests</span>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => setGuestsCount(Math.max(1, guestsCount - 1))}
                          className="w-7 h-7 rounded-md border flex items-center justify-center text-xs hover:border-amber-500"
                        >
                          -
                        </button>
                        <span className="text-sm font-semibold w-4 text-center">{guestsCount}</span>
                        <button
                          type="button"
                          onClick={() => setGuestsCount(Math.min(8, guestsCount + 1))}
                          className="w-7 h-7 rounded-md border flex items-center justify-center text-xs hover:border-amber-500"
                        >
                          +
                        </button>
                      </div>
                    </div>

                    <div className="flex items-center justify-between py-2">
                      <span className="text-xs font-medium">Rooms</span>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => setRoomsCount(Math.max(1, roomsCount - 1))}
                          className="w-7 h-7 rounded-md border flex items-center justify-center text-xs hover:border-amber-500"
                        >
                          -
                        </button>
                        <span className="text-sm font-semibold w-4 text-center">{roomsCount}</span>
                        <button
                          type="button"
                          onClick={() => setRoomsCount(Math.min(4, roomsCount + 1))}
                          className="w-7 h-7 rounded-md border flex items-center justify-center text-xs hover:border-amber-500"
                        >
                          +
                        </button>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => setShowGuestDropdown(false)}
                      className="w-full mt-2 py-1.5 text-xs font-medium text-amber-500 hover:text-amber-400 text-center"
                    >
                      Done
                    </button>
                  </div>
                )}
              </div>

              {/* Submit CTA */}
              <button
                type="button"
                onClick={onSearch}
                aria-label="Search Luxury Stays"
                className="h-[60px] px-5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-stone-950 font-semibold flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
              >
                <Search className="w-5 h-5 stroke-[2.5]" />
              </button>
            </div>
          </div>

          {/* Category Filter Pills (Functional Segmented Buttons) */}
          <div className="mt-5 pt-4 border-t border-stone-700/20 flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
            <span className="text-xs font-medium text-stone-400 uppercase tracking-wider shrink-0 mr-1">
              Curations:
            </span>
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`px-3.5 py-1.5 text-xs font-medium rounded-full transition-all whitespace-nowrap cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-amber-500 text-stone-950 font-semibold shadow-xs'
                    : darkMode
                      ? 'bg-stone-800/80 text-stone-300 hover:text-white hover:bg-stone-800'
                      : 'bg-stone-100 text-stone-700 hover:text-stone-950 hover:bg-stone-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

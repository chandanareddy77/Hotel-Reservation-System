import React, { useState, useEffect } from 'react';
import {
  X,
  Star,
  MapPin,
  Calendar,
  Users,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Info,
  ChevronDown,
  Bed,
  Maximize2
} from 'lucide-react';
import { Hotel, RoomType, RoomTier, PriceBreakdown } from '../types/index.ts';
import { api } from '../services/api.ts';

interface HotelDetailsModalProps {
  hotel: Hotel;
  initialCheckIn: string;
  initialCheckOut: string;
  initialGuests: number;
  initialRooms: number;
  onClose: () => void;
  onSelectRoom: (hotel: Hotel, roomType: RoomType, pricing: PriceBreakdown) => void;
  darkMode: boolean;
}

export const HotelDetailsModal: React.FC<HotelDetailsModalProps> = ({
  hotel,
  initialCheckIn,
  initialCheckOut,
  initialGuests,
  initialRooms,
  onClose,
  onSelectRoom,
  darkMode
}) => {
  const [selectedTier, setSelectedTier] = useState<string>('All');
  const [checkIn, setCheckIn] = useState<string>(initialCheckIn);
  const [checkOut, setCheckOut] = useState<string>(initialCheckOut);
  const [numRooms, setNumRooms] = useState<number>(initialRooms);
  const [roomTypes, setRoomTypes] = useState<(RoomType & { currentlyBooked: number; remainingInventory: number; overbookingCap: number; isSoldOut: boolean })[]>([]);
  const [pricingMap, setPricingMap] = useState<Record<string, PriceBreakdown>>({});
  const [loading, setLoading] = useState<boolean>(true);
  const [activeImageIndex, setActiveImageIndex] = useState<number>(0);
  const [expandedBreakdown, setExpandedBreakdown] = useState<string | null>(null);

  const tiers = ['All', 'Standard', 'Deluxe', 'Junior Suite', 'Presidential'];

  // Load hotel details and live room availability
  useEffect(() => {
    let isMounted = true;
    async function loadData() {
      try {
        setLoading(true);
        const data = await api.getHotelDetails(hotel.id);
        if (!isMounted) return;
        setRoomTypes(data.roomTypes || []);

        // Recalculate dynamic rate for each room type
        const newPricingMap: Record<string, PriceBreakdown> = {};
        for (const rt of data.roomTypes) {
          try {
            const pricing = await api.calculateRate(rt.id, checkIn, checkOut, numRooms);
            newPricingMap[rt.id] = pricing;
          } catch (err) {
            console.error(`Rate calc failed for ${rt.id}:`, err);
          }
        }
        if (isMounted) {
          setPricingMap(newPricingMap);
        }
      } catch (err) {
        console.error('Failed to load hotel details:', err);
      } finally {
        if (isMounted) setLoading(false);
      }
    }
    loadData();
    return () => {
      isMounted = false;
    };
  }, [hotel.id, checkIn, checkOut, numRooms]);

  const filteredRoomTypes = roomTypes.filter(rt => {
    if (selectedTier === 'All') return true;
    return rt.tier === selectedTier;
  });

  const allImages = [hotel.imageUrl, ...(hotel.galleryUrls || [])];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 md:p-6">
      <div className={`relative w-full max-w-5xl rounded-3xl border shadow-2xl overflow-hidden flex flex-col max-h-[92vh] ${
        darkMode ? 'bg-stone-900 border-stone-800 text-stone-100' : 'bg-white border-stone-200 text-stone-900'
      }`}>
        {/* Header Bar */}
        <div className={`p-4 sm:p-6 border-b flex items-center justify-between shrink-0 ${
          darkMode ? 'border-stone-800 bg-stone-900/90' : 'border-stone-200 bg-stone-50'
        }`}>
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-amber-500 uppercase tracking-widest mb-1">
              <MapPin className="w-3.5 h-3.5" />
              <span>{hotel.city} · {hotel.neighborhood}</span>
            </div>
            <h2 className="font-serif text-2xl sm:text-3xl font-bold tracking-tight">
              {hotel.name}
            </h2>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full border hover:bg-stone-800 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Modal Body */}
        <div className="overflow-y-auto p-4 sm:p-6 space-y-8">
          {/* Gallery Showcase */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2 aspect-16/10 rounded-2xl overflow-hidden bg-stone-800 relative">
              <img
                src={allImages[activeImageIndex] || hotel.imageUrl}
                alt={hotel.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-all duration-500"
              />
              <div className="absolute top-4 right-4 flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500 text-stone-950 font-bold text-xs shadow-md">
                <Star className="w-3.5 h-3.5 fill-stone-950" />
                <span>{hotel.rating.toFixed(1)}</span>
                <span className="opacity-75">({hotel.reviewCount} reviews)</span>
              </div>
            </div>

            <div className="flex md:flex-col gap-3 overflow-x-auto md:overflow-y-auto max-h-[340px]">
              {allImages.map((img, idx) => (
                <div
                  key={idx}
                  onClick={() => setActiveImageIndex(idx)}
                  className={`aspect-16/9 md:aspect-4/3 rounded-xl overflow-hidden cursor-pointer border-2 transition-all shrink-0 w-28 md:w-full ${
                    activeImageIndex === idx ? 'border-amber-500 scale-[1.02]' : 'border-transparent opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt="Gallery" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                </div>
              ))}
            </div>
          </div>

          {/* Description & Amenities */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 pt-2">
            <div className="lg:col-span-2">
              <h3 className="font-serif text-xl font-bold mb-2">About The Property</h3>
              <p className="text-sm leading-relaxed text-stone-400 mb-6">
                {hotel.description}
              </p>

              <h4 className="text-xs font-semibold uppercase tracking-wider text-amber-500 mb-3">
                Signature Amenities & Royal Privileges
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {hotel.amenities.map((amenity, i) => (
                  <div
                    key={i}
                    className={`flex items-center gap-2 p-2.5 rounded-lg border text-xs ${
                      darkMode ? 'bg-stone-800/40 border-stone-800' : 'bg-stone-50 border-stone-200'
                    }`}
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                    <span className="truncate">{amenity}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Live Stay Date Selector Card */}
            <div className={`p-5 rounded-2xl border flex flex-col justify-between ${
              darkMode ? 'bg-stone-800/60 border-stone-700/60' : 'bg-stone-50 border-stone-200'
            }`}>
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-amber-500 mb-4 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Modify Stay Dates & Rooms</span>
                </h4>

                <div className="space-y-3">
                  <div>
                    <label className="text-[11px] text-stone-400 block mb-1">Check-in</label>
                    <input
                      type="date"
                      value={checkIn}
                      min={new Date().toISOString().split('T')[0]}
                      onChange={(e) => setCheckIn(e.target.value)}
                      className={`w-full p-2.5 rounded-lg border text-xs font-medium focus:outline-hidden ${
                        darkMode ? 'bg-stone-900 border-stone-700' : 'bg-white border-stone-300'
                      }`}
                    />
                  </div>

                  <div>
                    <label className="text-[11px] text-stone-400 block mb-1">Check-out</label>
                    <input
                      type="date"
                      value={checkOut}
                      min={checkIn}
                      onChange={(e) => setCheckOut(e.target.value)}
                      className={`w-full p-2.5 rounded-lg border text-xs font-medium focus:outline-hidden ${
                        darkMode ? 'bg-stone-900 border-stone-700' : 'bg-white border-stone-300'
                      }`}
                    />
                  </div>

                  <div>
                    <label className="text-[11px] text-stone-400 block mb-1">Number of Rooms</label>
                    <select
                      value={numRooms}
                      onChange={(e) => setNumRooms(Number(e.target.value))}
                      className={`w-full p-2.5 rounded-lg border text-xs font-medium focus:outline-hidden ${
                        darkMode ? 'bg-stone-900 border-stone-700' : 'bg-white border-stone-300'
                      }`}
                    >
                      <option value={1}>1 Room</option>
                      <option value={2}>2 Rooms</option>
                      <option value={3}>3 Rooms</option>
                      <option value={4}>4 Rooms</option>
                    </select>
                  </div>
                </div>
              </div>

              <div className="pt-4 mt-4 border-t border-stone-700/30 text-[11px] text-stone-400 flex items-center gap-1.5">
                <Sparkles className="w-3 h-3 text-amber-500 shrink-0" />
                <span>Rates automatically recalculate with live occupancy & weekend factors</span>
              </div>
            </div>
          </div>

          {/* Room Tier Filter Tabs */}
          <div className="pt-6 border-t border-stone-800">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
              <div>
                <h3 className="font-serif text-2xl font-bold">Select Suite or Room</h3>
                <p className="text-xs text-stone-400">Available physical inventory with 10% overbooking buffer protection</p>
              </div>

              {/* Tier Filter Tabs */}
              <div className="flex items-center gap-1.5 overflow-x-auto p-1 rounded-xl bg-stone-800/60 border border-stone-700/50">
                {tiers.map((tier) => (
                  <button
                    key={tier}
                    onClick={() => setSelectedTier(tier)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all whitespace-nowrap cursor-pointer ${
                      selectedTier === tier
                        ? 'bg-amber-500 text-stone-950 font-bold shadow-sm'
                        : 'text-stone-300 hover:text-white'
                    }`}
                  >
                    {tier}
                  </button>
                ))}
              </div>
            </div>

            {/* Room Type List */}
            {loading ? (
              <div className="py-12 flex flex-col items-center justify-center gap-3 text-stone-400">
                <div className="w-8 h-8 rounded-full border-2 border-amber-500 border-t-transparent animate-spin" />
                <span className="text-xs font-medium">Computing dynamic room tariffs...</span>
              </div>
            ) : filteredRoomTypes.length === 0 ? (
              <div className="py-12 text-center text-stone-400 text-sm">
                No rooms available in this tier.
              </div>
            ) : (
              <div className="space-y-4">
                {filteredRoomTypes.map((rt) => {
                  const pricing = pricingMap[rt.id];
                  const isSoldOut = rt.isSoldOut || rt.remainingInventory <= 0;
                  const isBreakdownOpen = expandedBreakdown === rt.id;

                  return (
                    <div
                      key={rt.id}
                      className={`rounded-2xl border p-5 transition-all duration-200 flex flex-col md:flex-row gap-5 ${
                        darkMode ? 'bg-stone-800/40 border-stone-800 hover:border-stone-700' : 'bg-stone-50 border-stone-200 hover:border-stone-300'
                      }`}
                    >
                      {/* Thumbnail */}
                      <div className="md:w-64 aspect-16/10 rounded-xl overflow-hidden bg-stone-800 relative shrink-0">
                        <img
                          src={rt.imageUrl}
                          alt={rt.name}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute top-2 left-2 px-2.5 py-0.5 rounded-full bg-stone-950/80 text-[10px] font-semibold uppercase tracking-wider text-amber-400 border border-amber-500/30">
                          {rt.tier}
                        </div>
                      </div>

                      {/* Details */}
                      <div className="flex-1 flex flex-col justify-between">
                        <div>
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 mb-2">
                            <h4 className="font-serif text-lg font-bold text-amber-500">
                              {rt.name}
                            </h4>

                            {/* Inventory Counter & Overbooking Tag */}
                            <div className="flex items-center gap-2">
                              {isSoldOut ? (
                                <span className="px-2.5 py-0.5 rounded-md bg-rose-500/20 text-rose-400 text-[11px] font-semibold">
                                  Fully Booked
                                </span>
                              ) : (
                                <div className="flex items-center gap-1.5">
                                  <span className="text-[11px] font-semibold text-emerald-400">
                                    {rt.remainingInventory} left
                                  </span>
                                  <span className="text-[10px] text-stone-400">
                                    (incl. 10% buffer)
                                  </span>
                                </div>
                              )}
                            </div>
                          </div>

                          <p className="text-xs text-stone-400 mb-3 leading-relaxed">
                            {rt.description}
                          </p>

                          <div className="flex flex-wrap items-center gap-4 text-xs text-stone-300 mb-4">
                            <span className="flex items-center gap-1">
                              <Users className="w-3.5 h-3.5 text-amber-500" /> Up to {rt.capacityGuests} Guests
                            </span>
                            <span className="flex items-center gap-1">
                              <Bed className="w-3.5 h-3.5 text-amber-500" /> {rt.bedType}
                            </span>
                            <span className="flex items-center gap-1">
                              <Maximize2 className="w-3.5 h-3.5 text-amber-500" /> {rt.squareFeet} sq.ft
                            </span>
                          </div>

                          {/* Amenities preview */}
                          <div className="flex flex-wrap gap-1.5 mb-4">
                            {rt.amenities.slice(0, 3).map((amen, aIdx) => (
                              <span
                                key={aIdx}
                                className={`px-2 py-0.5 rounded-md text-[11px] border ${
                                  darkMode ? 'bg-stone-900 border-stone-800 text-stone-300' : 'bg-white border-stone-200 text-stone-700'
                                }`}
                              >
                                {amen}
                              </span>
                            ))}
                            {rt.amenities.length > 3 && (
                              <span className="text-[11px] text-stone-400 py-0.5">
                                +{rt.amenities.length - 3} more
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Pricing & CTA */}
                        <div className="pt-3 border-t border-stone-700/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                          <div>
                            <div className="flex items-baseline gap-1.5">
                              <span className="text-xs text-stone-400">Avg.</span>
                              <span className="text-xl font-bold font-mono text-amber-500">
                                ₹{(pricing ? pricing.effectiveNightlyRate : rt.basePrice).toLocaleString('en-IN')}
                              </span>
                              <span className="text-xs text-stone-400">/night</span>
                            </div>

                            {pricing && (
                              <div className="flex items-center gap-2 mt-1">
                                <span className="text-[11px] text-stone-400">
                                  Total {pricing.numberOfNights} nights: ₹{pricing.totalAmount.toLocaleString('en-IN')} (incl. GST)
                                </span>
                                <button
                                  type="button"
                                  onClick={() => setExpandedBreakdown(isBreakdownOpen ? null : rt.id)}
                                  className="text-[11px] text-amber-400 hover:text-amber-300 inline-flex items-center gap-0.5 font-medium underline"
                                >
                                  <span>Breakdown</span>
                                  <ChevronDown className={`w-3 h-3 transition-transform ${isBreakdownOpen ? 'rotate-180' : ''}`} />
                                </button>
                              </div>
                            )}

                            {/* Dynamic Surge Breakdown Card */}
                            {isBreakdownOpen && pricing && (
                              <div className={`mt-2 p-3 rounded-lg border text-[11px] space-y-1.5 ${
                                darkMode ? 'bg-stone-900 border-stone-700' : 'bg-white border-stone-300'
                              }`}>
                                <div className="flex justify-between">
                                  <span className="text-stone-400">Base Nightly Tariff:</span>
                                  <span className="font-mono">₹{pricing.baseNightlyRate.toLocaleString('en-IN')}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-stone-400">Occupancy Surge:</span>
                                  <span className="text-amber-400 font-semibold">{pricing.occupancyLabel}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-stone-400">Weekend Factor:</span>
                                  <span>{pricing.weekendMultiplier > 1.0 ? '1.20x Weekend Rate' : '1.0x Standard'}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-stone-400">Subtotal ({pricing.numberOfNights} nights × {numRooms} room):</span>
                                  <span className="font-mono">₹{pricing.subtotal.toLocaleString('en-IN')}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-stone-400">18% Luxury GST:</span>
                                  <span className="font-mono">₹{pricing.taxAmount.toLocaleString('en-IN')}</span>
                                </div>
                                <div className="flex justify-between pt-1 border-t border-stone-700/40 font-bold text-amber-500">
                                  <span>Total Payable:</span>
                                  <span className="font-mono">₹{pricing.totalAmount.toLocaleString('en-IN')}</span>
                                </div>
                              </div>
                            )}
                          </div>

                          <button
                            type="button"
                            disabled={isSoldOut || !pricing}
                            onClick={() => pricing && onSelectRoom(hotel, rt, pricing)}
                            className={`px-5 py-2.5 rounded-xl font-semibold text-xs tracking-wider uppercase transition-all shadow-md cursor-pointer ${
                              isSoldOut
                                ? 'bg-stone-800 text-stone-500 cursor-not-allowed'
                                : 'bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-stone-950 hover:scale-[1.02] active:scale-[0.98]'
                            }`}
                          >
                            {isSoldOut ? 'Sold Out' : 'Reserve Room'}
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

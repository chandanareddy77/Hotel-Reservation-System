import React from 'react';
import { CheckCircle, QrCode, Calendar, MapPin, Download, ArrowRight, ShieldCheck, Hotel } from 'lucide-react';
import { Reservation } from '../types/index.ts';

interface BookingSuccessModalProps {
  reservation: Reservation;
  onClose: () => void;
  onViewBookings: () => void;
  darkMode: boolean;
}

export const BookingSuccessModal: React.FC<BookingSuccessModalProps> = ({
  reservation,
  onClose,
  onViewBookings,
  darkMode
}) => {
  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6">
      <div className={`relative w-full max-w-2xl rounded-3xl border shadow-2xl overflow-hidden p-6 sm:p-8 text-center ${
        darkMode ? 'bg-stone-900 border-stone-800 text-stone-100' : 'bg-white border-stone-200 text-stone-900'
      }`}>
        {/* Celebration Icon */}
        <div className="w-16 h-16 rounded-full bg-emerald-500/10 border-2 border-emerald-500 flex items-center justify-center mx-auto mb-4 text-emerald-400">
          <CheckCircle className="w-9 h-9 stroke-[2.2]" />
        </div>

        <span className="text-xs uppercase tracking-widest font-semibold text-emerald-400">
          Reservation Confirmed
        </span>

        <h2 className="font-serif text-2xl sm:text-3xl font-bold mt-1 mb-2">
          Your Luxury Stay Awaits
        </h2>

        <p className="text-xs text-stone-400 max-w-md mx-auto mb-6">
          A confirmation with your digital concierge pass has been sent to <strong>{reservation.guestEmail}</strong>.
        </p>

        {/* Digital Boarding Pass Card */}
        <div className={`p-6 rounded-2xl border text-left relative overflow-hidden mb-6 ${
          darkMode ? 'bg-stone-800/60 border-stone-700/60' : 'bg-stone-50 border-stone-200'
        }`}>
          {/* Top Pass Bar */}
          <div className="flex items-center justify-between pb-4 border-b border-stone-700/30">
            <div>
              <span className="text-[10px] uppercase tracking-wider text-stone-400 block">
                Booking Reference
              </span>
              <span className="font-mono text-xl font-bold text-amber-500 tracking-wider">
                {reservation.bookingRef}
              </span>
            </div>

            <div className="text-right">
              <span className="text-[10px] uppercase tracking-wider text-stone-400 block">
                Payment Status
              </span>
              <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-400">
                <ShieldCheck className="w-3.5 h-3.5" />
                {reservation.paymentMethod === 'PAY_AT_HOTEL' ? 'Pay upon Check-in' : 'Authorized & Paid'}
              </span>
            </div>
          </div>

          {/* Hotel & Stay Details */}
          <div className="py-4 border-b border-stone-700/30 grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <span className="text-[10px] uppercase tracking-wider text-stone-400 block">Property & Room</span>
              <h4 className="font-serif text-base font-bold text-stone-100">{reservation.hotelName}</h4>
              <p className="text-xs text-amber-400 font-medium">{reservation.roomTypeName}</p>
            </div>

            <div>
              <span className="text-[10px] uppercase tracking-wider text-stone-400 block">Dates & Guest</span>
              <p className="text-xs font-medium">{reservation.checkIn} to {reservation.checkOut}</p>
              <p className="text-xs text-stone-400">{reservation.guestName} · {reservation.numRooms} Room(s)</p>
            </div>
          </div>

          {/* QR Pass & Total */}
          <div className="pt-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-white">
                <QrCode className="w-12 h-12 text-stone-950" />
              </div>
              <div className="text-[11px] text-stone-400">
                <span>Present at Reception</span>
                <span className="block text-stone-300 font-mono">ID: {reservation.id.slice(0, 14)}</span>
              </div>
            </div>

            <div className="text-right">
              <span className="text-[10px] uppercase tracking-wider text-stone-400 block">Total Amount</span>
              <span className="font-mono text-xl font-bold text-amber-500">
                ₹{reservation.totalAmount.toLocaleString('en-IN')}
              </span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center gap-3 justify-center">
          <button
            type="button"
            onClick={onViewBookings}
            className="w-full sm:w-auto px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-stone-950 font-bold text-xs uppercase tracking-wider shadow-lg flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>View My Bookings</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={onClose}
            className="w-full sm:w-auto px-6 py-3 rounded-xl border border-stone-700 hover:bg-stone-800 text-stone-300 font-medium text-xs tracking-wider cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

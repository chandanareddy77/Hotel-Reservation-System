import React, { useState, useEffect } from 'react';
import {
  Calendar,
  MapPin,
  Clock,
  ShieldCheck,
  AlertTriangle,
  RotateCcw,
  CheckCircle2,
  XCircle,
  HelpCircle,
  QrCode
} from 'lucide-react';
import { Reservation, RefundPreview } from '../types/index.ts';
import { api } from '../services/api.ts';

interface MyBookingsViewProps {
  darkMode: boolean;
  onExploreHotels: () => void;
}

export const MyBookingsView: React.FC<MyBookingsViewProps> = ({ darkMode, onExploreHotels }) => {
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [loading, setLoading] = useState(true);
  const [cancellingRes, setCancellingRes] = useState<Reservation | null>(null);
  const [refundPreview, setRefundPreview] = useState<RefundPreview | null>(null);
  const [cancelLoading, setCancelLoading] = useState(false);
  const [cancelSuccessMsg, setCancelSuccessMsg] = useState<string | null>(null);

  const fetchReservations = async () => {
    try {
      setLoading(true);
      const data = await api.getReservations();
      setReservations(data);
    } catch (err) {
      console.error('Failed to load reservations:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReservations();
  }, []);

  // Initiate Cancellation Preview
  const handleOpenCancelDialog = async (res: Reservation) => {
    try {
      setCancellingRes(res);
      setCancelLoading(true);
      const preview = await api.getRefundPreview(res.id);
      setRefundPreview(preview);
    } catch (err: any) {
      alert(err.message || 'Failed to calculate refund preview');
      setCancellingRes(null);
    } finally {
      setCancelLoading(false);
    }
  };

  // Confirm Cancellation
  const handleConfirmCancellation = async () => {
    if (!cancellingRes) return;
    try {
      setCancelLoading(true);
      const res = await api.cancelReservation(cancellingRes.id, 'Customer requested cancellation via portal');
      setCancelSuccessMsg(
        `Booking ${res.reservation.bookingRef} cancelled. Refund of ₹${res.refund.refundAmount.toLocaleString('en-IN')} (${res.refund.refundPercentage}%) issued.`
      );
      setCancellingRes(null);
      setRefundPreview(null);
      await fetchReservations();
    } catch (err: any) {
      alert(err.message || 'Failed to cancel reservation');
    } finally {
      setCancelLoading(false);
    }
  };

  const upcomingStays = reservations.filter(r => r.status === 'CONFIRMED' || r.status === 'PENDING');
  const pastStays = reservations.filter(r => r.status === 'CANCELLED' || r.status === 'PAYMENT_FAILED');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <span className="text-xs font-semibold uppercase tracking-widest text-amber-500">
            Guest Concierge Portal
          </span>
          <h1 className="font-serif text-3xl sm:text-4xl font-bold tracking-tight">
            My Luxury Reservations
          </h1>
          <p className="text-xs text-stone-400 mt-1">
            Manage your suite bookings, digital check-in passes, and tiered automated refund requests.
          </p>
        </div>

        <button
          type="button"
          onClick={onExploreHotels}
          className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-semibold text-xs tracking-wider uppercase transition-all shadow-md cursor-pointer self-start sm:self-auto"
        >
          Book Another Haven
        </button>
      </div>

      {cancelSuccessMsg && (
        <div className="mb-6 p-4 rounded-xl border border-emerald-500/40 bg-emerald-500/10 text-emerald-300 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{cancelSuccessMsg}</span>
          </div>
          <button
            onClick={() => setCancelSuccessMsg(null)}
            className="text-stone-400 hover:text-white"
          >
            ✕
          </button>
        </div>
      )}

      {loading ? (
        <div className="py-20 flex flex-col items-center justify-center gap-3 text-stone-400">
          <div className="w-8 h-8 rounded-full border-2 border-amber-500 border-t-transparent animate-spin" />
          <span className="text-xs">Loading reservations...</span>
        </div>
      ) : reservations.length === 0 ? (
        <div className={`p-12 rounded-3xl border text-center ${
          darkMode ? 'bg-stone-900 border-stone-800' : 'bg-white border-stone-200'
        }`}>
          <div className="w-12 h-12 rounded-full bg-amber-500/10 text-amber-500 flex items-center justify-center mx-auto mb-3">
            <Calendar className="w-6 h-6" />
          </div>
          <h3 className="font-serif text-xl font-bold mb-1">No Reservations Found</h3>
          <p className="text-xs text-stone-400 max-w-sm mx-auto mb-6">
            You haven't reserved any suites yet. Explore our royal palaces, beach sanctuaries, and executive towers.
          </p>
          <button
            type="button"
            onClick={onExploreHotels}
            className="px-6 py-2.5 rounded-xl bg-amber-500 text-stone-950 font-bold text-xs uppercase tracking-wider"
          >
            Discover Properties
          </button>
        </div>
      ) : (
        <div className="space-y-10">
          {/* Upcoming Active Stays */}
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider text-amber-500 mb-4 flex items-center gap-2">
              <Clock className="w-4 h-4" />
              <span>Upcoming Confirmed Stays ({upcomingStays.length})</span>
            </h2>

            {upcomingStays.length === 0 ? (
              <p className="text-xs text-stone-400 italic">No upcoming active stays.</p>
            ) : (
              <div className="grid grid-cols-1 gap-4">
                {upcomingStays.map((res) => (
                  <div
                    key={res.id}
                    className={`rounded-2xl border p-5 transition-all flex flex-col md:flex-row justify-between gap-5 ${
                      darkMode ? 'bg-stone-900 border-stone-800' : 'bg-white border-stone-200 shadow-xs'
                    }`}
                  >
                    <div className="space-y-3">
                      <div className="flex flex-wrap items-center gap-2.5">
                        <span className="font-mono text-sm font-bold text-amber-500">
                          {res.bookingRef}
                        </span>
                        <span className="px-2.5 py-0.5 rounded-md bg-emerald-500/20 text-emerald-400 text-[11px] font-semibold">
                          {res.status}
                        </span>
                        <span className="text-xs text-stone-400">
                          Booked on {new Date(res.createdAt).toLocaleDateString('en-IN')}
                        </span>
                      </div>

                      <div>
                        <h3 className="font-serif text-xl font-bold text-stone-100">
                          {res.hotelName}
                        </h3>
                        <p className="text-xs font-semibold text-amber-400">
                          {res.roomTypeName} · {res.numRooms} Room(s)
                        </p>
                      </div>

                      <div className="flex flex-wrap items-center gap-4 text-xs text-stone-300">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5 text-amber-500" />
                          {res.checkIn} to {res.checkOut}
                        </span>
                        <span>·</span>
                        <span>Guest: {res.guestName}</span>
                        <span>·</span>
                        <span>Rail: {res.paymentMethod}</span>
                      </div>
                    </div>

                    <div className="flex flex-col md:items-end justify-between gap-3 pt-3 md:pt-0 border-t md:border-t-0 border-stone-800">
                      <div className="md:text-right">
                        <span className="text-[10px] uppercase text-stone-400 block">Total Tariff</span>
                        <span className="font-mono text-xl font-bold text-amber-500">
                          ₹{res.totalAmount.toLocaleString('en-IN')}
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleOpenCancelDialog(res)}
                          className="px-3.5 py-2 rounded-lg border border-rose-500/40 hover:bg-rose-500/10 text-rose-400 text-xs font-semibold transition-colors cursor-pointer"
                        >
                          Cancel Stay
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Past / Cancelled Stays */}
          {pastStays.length > 0 && (
            <div>
              <h2 className="text-sm font-bold uppercase tracking-wider text-stone-400 mb-4 flex items-center gap-2">
                <RotateCcw className="w-4 h-4" />
                <span>Past & Cancelled Reservations ({pastStays.length})</span>
              </h2>

              <div className="grid grid-cols-1 gap-3">
                {pastStays.map((res) => (
                  <div
                    key={res.id}
                    className={`rounded-2xl border p-4 opacity-75 flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                      darkMode ? 'bg-stone-900/60 border-stone-800/60' : 'bg-stone-50 border-stone-200'
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-mono text-xs font-bold text-stone-300">
                          {res.bookingRef}
                        </span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                          res.status === 'CANCELLED' ? 'bg-stone-800 text-stone-400' : 'bg-rose-500/20 text-rose-400'
                        }`}>
                          {res.status}
                        </span>
                        {res.refundAmount !== undefined && res.refundAmount > 0 && (
                          <span className="text-[11px] text-emerald-400 font-medium">
                            Refunded ₹{res.refundAmount.toLocaleString('en-IN')}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-stone-300 font-medium">
                        {res.hotelName} — {res.roomTypeName} ({res.checkIn} to {res.checkOut})
                      </p>
                    </div>

                    <div className="text-right">
                      <span className="font-mono text-sm text-stone-400">
                        ₹{res.totalAmount.toLocaleString('en-IN')}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Cancellation & Tiered Refund Modal */}
      {cancellingRes && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className={`relative w-full max-w-lg rounded-3xl border shadow-2xl overflow-hidden p-6 ${
            darkMode ? 'bg-stone-900 border-stone-800 text-stone-100' : 'bg-white border-stone-200 text-stone-900'
          }`}>
            <div className="w-12 h-12 rounded-full bg-rose-500/10 text-rose-400 flex items-center justify-center mb-4">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <h3 className="font-serif text-2xl font-bold mb-1">
              Cancel Reservation?
            </h3>
            <p className="text-xs text-stone-400 mb-5">
              Review your automated tiered refund calculation for booking <strong>{cancellingRes.bookingRef}</strong>.
            </p>

            {cancelLoading && !refundPreview ? (
              <div className="py-8 flex items-center justify-center gap-2 text-stone-400 text-xs">
                <div className="w-5 h-5 rounded-full border-2 border-amber-500 border-t-transparent animate-spin" />
                <span>Evaluating tiered refund policy...</span>
              </div>
            ) : refundPreview ? (
              <div className="space-y-4 mb-6">
                {/* Policy evaluation card */}
                <div className={`p-4 rounded-xl border space-y-2 text-xs ${
                  darkMode ? 'bg-stone-800/60 border-stone-700/60' : 'bg-stone-50 border-stone-200'
                }`}>
                  <div className="flex justify-between">
                    <span className="text-stone-400">Time to Check-in:</span>
                    <span className="font-semibold text-amber-400">
                      {refundPreview.hoursUntilCheckIn} Hours Away
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stone-400">Policy Bracket:</span>
                    <span className="font-medium text-stone-200">{refundPreview.cancellationPolicyDescription}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stone-400">Refund Eligible:</span>
                    <span className="font-bold text-emerald-400">{refundPreview.refundPercentage}%</span>
                  </div>
                  <div className="flex justify-between pt-2 border-t border-stone-700/40 text-sm font-bold">
                    <span>Refund Amount:</span>
                    <span className="font-mono text-emerald-400">
                      ₹{refundPreview.refundAmount.toLocaleString('en-IN')}
                    </span>
                  </div>
                </div>

                <p className="text-[11px] text-stone-400 leading-relaxed">
                  Upon cancellation, the held room inventory will be instantly made available to the public booking pool and your payment will be refunded to your original source.
                </p>
              </div>
            ) : null}

            <div className="flex items-center gap-3 justify-end">
              <button
                type="button"
                onClick={() => setCancellingRes(null)}
                className="px-4 py-2.5 rounded-xl border border-stone-700 hover:bg-stone-800 text-stone-300 text-xs font-semibold cursor-pointer"
              >
                Keep Reservation
              </button>
              <button
                type="button"
                disabled={cancelLoading}
                onClick={handleConfirmCancellation}
                className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs uppercase tracking-wider transition-colors shadow-lg cursor-pointer"
              >
                {cancelLoading ? 'Cancelling...' : 'Confirm Cancellation'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import {
  X,
  CreditCard,
  QrCode,
  Building,
  Wallet,
  Gift,
  Hotel as HotelIcon,
  ShieldCheck,
  AlertTriangle,
  Lock,
  Sparkles,
  Check,
  CheckCircle2,
  Calendar,
  Users
} from 'lucide-react';
import {
  Hotel,
  RoomType,
  PriceBreakdown,
  PaymentMethod,
  User,
  Reservation
} from '../types/index.ts';
import { api } from '../services/api.ts';

interface BookingPaymentModalProps {
  hotel: Hotel;
  roomType: RoomType;
  pricing: PriceBreakdown;
  checkIn: string;
  checkOut: string;
  numRooms: number;
  guestsCount: number;
  currentUser: User | null;
  onClose: () => void;
  onSuccess: (reservation: Reservation) => void;
  darkMode: boolean;
}

export const BookingPaymentModal: React.FC<BookingPaymentModalProps> = ({
  hotel,
  roomType,
  pricing,
  checkIn,
  checkOut,
  numRooms,
  guestsCount,
  currentUser,
  onClose,
  onSuccess,
  darkMode
}) => {
  // Guest Details
  const [guestName, setGuestName] = useState(currentUser?.name || 'Aarav Sharma');
  const [guestEmail, setGuestEmail] = useState(currentUser?.email || 'user@luxestay.com');
  const [guestPhone, setGuestPhone] = useState(currentUser?.phone || '+91 98201 54321');

  // Selected Payment Rail
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('CARD');

  // Card details
  const [cardNumber, setCardNumber] = useState('4111 2222 3333 4444');
  const [cardHolder, setCardHolder] = useState(currentUser?.name ? currentUser.name.toUpperCase() : 'AARAV SHARMA');
  const [cardExpiry, setCardExpiry] = useState('12/28');
  const [cardCvv, setCardCvv] = useState('888');
  const [cardBrand, setCardBrand] = useState('VISA');

  // UPI details
  const [upiType, setUpiType] = useState<'id' | 'qr'>('id');
  const [upiId, setUpiId] = useState('aarav.sharma@okhdfcbank');

  // Net banking details
  const [selectedBank, setSelectedBank] = useState('HDFC Bank');

  // Digital wallet details
  const [selectedWallet, setSelectedWallet] = useState('Amazon Pay');

  // Gift Voucher details
  const [voucherCode, setVoucherCode] = useState('');
  const [voucherApplied, setVoucherApplied] = useState<{ code: string; discount: number } | null>(null);
  const [voucherError, setVoucherError] = useState<string | null>(null);

  // Bank Decline Simulator Switch
  const [simulateDecline, setSimulateDecline] = useState(false);

  // Submission state
  const [processing, setProcessing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Idempotency Key (unique per modal session)
  const [idempotencyKey] = useState(() => `idemp_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`);

  // Quick Card Fill helpers
  const fillCard = (brand: string, num: string, holder: string) => {
    setCardBrand(brand);
    setCardNumber(num);
    setCardHolder(holder);
    setCardExpiry('10/29');
    setCardCvv('912');
  };

  // Voucher apply handler
  const handleApplyVoucher = () => {
    setVoucherError(null);
    const code = voucherCode.trim().toUpperCase();
    if (code === 'DIAMOND-STAY') {
      setVoucherApplied({ code, discount: pricing.totalAmount });
    } else if (code === 'LUXE-GOLD-2026') {
      const discount = Math.min(10000, pricing.totalAmount);
      setVoucherApplied({ code, discount });
    } else {
      setVoucherError(`Invalid voucher code '${code}'. Use 'LUXE-GOLD-2026' or 'DIAMOND-STAY'.`);
    }
  };

  const effectiveTotal = voucherApplied
    ? Math.max(0, pricing.totalAmount - voucherApplied.discount)
    : pricing.totalAmount;

  const handleBookingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setProcessing(true);

    try {
      const payload = {
        idempotencyKey,
        userId: currentUser?.id || 'user-guest-001',
        hotelId: hotel.id,
        roomTypeId: roomType.id,
        checkIn,
        checkOut,
        numRooms,
        guestsCount,
        guestName,
        guestEmail,
        guestPhone,
        paymentMethod: voucherApplied && effectiveTotal === 0 ? ('VOUCHER' as PaymentMethod) : paymentMethod,
        paymentDetails: {
          simulateDecline,
          cardNumber,
          cardHolder,
          cardExpiry,
          cardCvv,
          cardBrand,
          upiId,
          bankName: selectedBank,
          walletProvider: selectedWallet,
          voucherCode: voucherApplied?.code || voucherCode
        }
      };

      const outcome = await api.createReservation(payload);
      onSuccess(outcome.reservation);
    } catch (err: any) {
      if (err.code === 'EXCESS_OVERBOOKING_REJECTED') {
        setErrorMessage('Booking rejected: Exceeded 10% safety overbooking limit for this room tier.');
      } else if (err.code === 'PAYMENT_DECLINED') {
        setErrorMessage(
          'BANK_GATEWAY_DECLINED: Issuer bank authorization declined (Simulated decline scenario). Held room inventory has been safely released.'
        );
      } else {
        setErrorMessage(err.message || 'Payment processing failed. Please try another method.');
      }
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-4">
      <div className={`relative w-full max-w-5xl rounded-3xl border shadow-2xl overflow-hidden flex flex-col max-h-[94vh] ${
        darkMode ? 'bg-stone-900 border-stone-800 text-stone-100' : 'bg-white border-stone-200 text-stone-900'
      }`}>
        {/* Header */}
        <div className={`p-4 sm:p-5 border-b flex items-center justify-between shrink-0 ${
          darkMode ? 'border-stone-800 bg-stone-900/90' : 'border-stone-200 bg-stone-50'
        }`}>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-amber-500/10 text-amber-500 border border-amber-500/20">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-serif text-xl sm:text-2xl font-bold tracking-tight">
                Secure Luxury Checkout
              </h2>
              <p className="text-[11px] text-stone-400">
                256-Bit Encrypted Payment · Dynamic Tariff Idempotent Gateway
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full border hover:bg-stone-800 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body: Left Form + Right Order Summary */}
        <form onSubmit={handleBookingSubmit} className="overflow-y-auto p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Guest info + 6-Rail Payment Gateway (7 cols) */}
          <div className="lg:col-span-7 space-y-6">
            {/* Guest Details */}
            <div className={`p-5 rounded-2xl border ${
              darkMode ? 'bg-stone-800/40 border-stone-800' : 'bg-stone-50 border-stone-200'
            }`}>
              <h3 className="text-xs font-bold uppercase tracking-wider text-amber-500 mb-3 flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5" />
                <span>Primary Guest Credentials</span>
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="sm:col-span-2">
                  <label className="text-[11px] text-stone-400 block mb-1">Full Legal Name</label>
                  <input
                    type="text"
                    required
                    value={guestName}
                    onChange={(e) => setGuestName(e.target.value)}
                    className={`w-full p-2.5 rounded-lg border text-xs font-medium focus:outline-hidden ${
                      darkMode ? 'bg-stone-900 border-stone-700' : 'bg-white border-stone-300'
                    }`}
                  />
                </div>

                <div>
                  <label className="text-[11px] text-stone-400 block mb-1">Email Address</label>
                  <input
                    type="email"
                    required
                    value={guestEmail}
                    onChange={(e) => setGuestEmail(e.target.value)}
                    className={`w-full p-2.5 rounded-lg border text-xs font-medium focus:outline-hidden ${
                      darkMode ? 'bg-stone-900 border-stone-700' : 'bg-white border-stone-300'
                    }`}
                  />
                </div>

                <div>
                  <label className="text-[11px] text-stone-400 block mb-1">Mobile Number</label>
                  <input
                    type="tel"
                    required
                    value={guestPhone}
                    onChange={(e) => setGuestPhone(e.target.value)}
                    className={`w-full p-2.5 rounded-lg border text-xs font-medium focus:outline-hidden ${
                      darkMode ? 'bg-stone-900 border-stone-700' : 'bg-white border-stone-300'
                    }`}
                  />
                </div>
              </div>
            </div>

            {/* 6-Method Payment Gateway Tabs */}
            <div className={`p-5 rounded-2xl border ${
              darkMode ? 'bg-stone-800/40 border-stone-800' : 'bg-stone-50 border-stone-200'
            }`}>
              <h3 className="text-xs font-bold uppercase tracking-wider text-amber-500 mb-3 flex items-center gap-1.5">
                <CreditCard className="w-3.5 h-3.5" />
                <span>Select Payment Gateway Rail</span>
              </h3>

              {/* 6 Payment Rail Tabs */}
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5 p-1 rounded-xl bg-stone-900/60 border border-stone-700/50 mb-4 text-[11px]">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('CARD')}
                  className={`py-2 px-1 rounded-lg font-medium transition-all text-center ${
                    paymentMethod === 'CARD' ? 'bg-amber-500 text-stone-950 font-bold shadow-xs' : 'text-stone-300 hover:text-white'
                  }`}
                >
                  Cards
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('UPI')}
                  className={`py-2 px-1 rounded-lg font-medium transition-all text-center ${
                    paymentMethod === 'UPI' ? 'bg-amber-500 text-stone-950 font-bold shadow-xs' : 'text-stone-300 hover:text-white'
                  }`}
                >
                  UPI / QR
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('NET_BANKING')}
                  className={`py-2 px-1 rounded-lg font-medium transition-all text-center ${
                    paymentMethod === 'NET_BANKING' ? 'bg-amber-500 text-stone-950 font-bold shadow-xs' : 'text-stone-300 hover:text-white'
                  }`}
                >
                  NetBanking
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('WALLET')}
                  className={`py-2 px-1 rounded-lg font-medium transition-all text-center ${
                    paymentMethod === 'WALLET' ? 'bg-amber-500 text-stone-950 font-bold shadow-xs' : 'text-stone-300 hover:text-white'
                  }`}
                >
                  Wallets
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('PAY_AT_HOTEL')}
                  className={`py-2 px-1 rounded-lg font-medium transition-all text-center ${
                    paymentMethod === 'PAY_AT_HOTEL' ? 'bg-amber-500 text-stone-950 font-bold shadow-xs' : 'text-stone-300 hover:text-white'
                  }`}
                >
                  Pay at Hotel
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('VOUCHER')}
                  className={`py-2 px-1 rounded-lg font-medium transition-all text-center ${
                    paymentMethod === 'VOUCHER' ? 'bg-amber-500 text-stone-950 font-bold shadow-xs' : 'text-stone-300 hover:text-white'
                  }`}
                >
                  Vouchers
                </button>
              </div>

              {/* Rail 1: Credit / Debit Card with Interactive 3D Card Visual */}
              {paymentMethod === 'CARD' && (
                <div className="space-y-4">
                  {/* Interactive Card Visual */}
                  <div className="relative aspect-16/9 max-w-sm mx-auto rounded-2xl p-5 bg-gradient-to-tr from-stone-950 via-stone-900 to-amber-950/80 border border-amber-500/40 text-stone-100 shadow-xl overflow-hidden flex flex-col justify-between">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-1.5">
                        <Sparkles className="w-4 h-4 text-amber-400" />
                        <span className="font-serif text-sm tracking-widest uppercase font-bold text-amber-400">LuxeStay Elite</span>
                      </div>
                      <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                        {cardBrand}
                      </span>
                    </div>

                    <div className="my-2">
                      <div className="w-10 h-8 rounded-md bg-gradient-to-tr from-amber-400 to-amber-200 opacity-90 mb-3" />
                      <div className="font-mono text-base tracking-widest font-semibold text-stone-200">
                        {cardNumber || '•••• •••• •••• ••••'}
                      </div>
                    </div>

                    <div className="flex justify-between items-end text-[11px]">
                      <div>
                        <span className="text-[9px] uppercase tracking-wider text-stone-400 block">Cardholder</span>
                        <span className="font-medium tracking-wide">{cardHolder || 'CARDHOLDER NAME'}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-[9px] uppercase tracking-wider text-stone-400 block">Expires</span>
                        <span className="font-mono font-medium">{cardExpiry || 'MM/YY'}</span>
                      </div>
                    </div>
                  </div>

                  {/* Quick-fill Pills */}
                  <div className="flex items-center gap-2 text-[11px] pt-1">
                    <span className="text-stone-400">Quick-Fill:</span>
                    <button
                      type="button"
                      onClick={() => fillCard('VISA', '4111 2222 3333 4444', 'AARAV SHARMA')}
                      className="px-2.5 py-1 rounded-md border border-stone-700 hover:border-amber-500 text-stone-300 text-[11px]"
                    >
                      Visa Signature
                    </button>
                    <button
                      type="button"
                      onClick={() => fillCard('AMEX', '3782 822463 10005', 'VIKRAM SINGHANIA')}
                      className="px-2.5 py-1 rounded-md border border-stone-700 hover:border-amber-500 text-stone-300 text-[11px]"
                    >
                      Amex Centurion
                    </button>
                    <button
                      type="button"
                      onClick={() => fillCard('RUPAY', '6071 8899 1234 5678', 'AARAV SHARMA')}
                      className="px-2.5 py-1 rounded-md border border-stone-700 hover:border-amber-500 text-stone-300 text-[11px]"
                    >
                      RuPay Select
                    </button>
                  </div>

                  {/* Card Inputs */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div className="col-span-2">
                      <label className="text-[11px] text-stone-400 block mb-1">Card Number</label>
                      <input
                        type="text"
                        value={cardNumber}
                        onChange={(e) => setCardNumber(e.target.value)}
                        placeholder="16 digits"
                        className={`w-full p-2.5 rounded-lg border text-xs font-mono focus:outline-hidden ${
                          darkMode ? 'bg-stone-900 border-stone-700' : 'bg-white border-stone-300'
                        }`}
                      />
                    </div>

                    <div className="col-span-2">
                      <label className="text-[11px] text-stone-400 block mb-1">Name on Card</label>
                      <input
                        type="text"
                        value={cardHolder}
                        onChange={(e) => setCardHolder(e.target.value.toUpperCase())}
                        className={`w-full p-2.5 rounded-lg border text-xs focus:outline-hidden ${
                          darkMode ? 'bg-stone-900 border-stone-700' : 'bg-white border-stone-300'
                        }`}
                      />
                    </div>

                    <div>
                      <label className="text-[11px] text-stone-400 block mb-1">Expiry Date</label>
                      <input
                        type="text"
                        value={cardExpiry}
                        onChange={(e) => setCardExpiry(e.target.value)}
                        placeholder="MM/YY"
                        className={`w-full p-2.5 rounded-lg border text-xs font-mono focus:outline-hidden ${
                          darkMode ? 'bg-stone-900 border-stone-700' : 'bg-white border-stone-300'
                        }`}
                      />
                    </div>

                    <div>
                      <label className="text-[11px] text-stone-400 block mb-1">CVV / CVC</label>
                      <input
                        type="password"
                        maxLength={4}
                        value={cardCvv}
                        onChange={(e) => setCardCvv(e.target.value)}
                        placeholder="3-4 digits"
                        className={`w-full p-2.5 rounded-lg border text-xs font-mono focus:outline-hidden ${
                          darkMode ? 'bg-stone-900 border-stone-700' : 'bg-white border-stone-300'
                        }`}
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Rail 2: UPI / Dynamic QR */}
              {paymentMethod === 'UPI' && (
                <div className="space-y-4">
                  <div className="flex items-center gap-2 p-1 rounded-lg bg-stone-900 border border-stone-700 w-fit text-xs">
                    <button
                      type="button"
                      onClick={() => setUpiType('id')}
                      className={`px-3 py-1 rounded-md transition-all ${
                        upiType === 'id' ? 'bg-amber-500 text-stone-950 font-bold' : 'text-stone-400 hover:text-stone-200'
                      }`}
                    >
                      Enter UPI VPA ID
                    </button>
                    <button
                      type="button"
                      onClick={() => setUpiType('qr')}
                      className={`px-3 py-1 rounded-md transition-all ${
                        upiType === 'qr' ? 'bg-amber-500 text-stone-950 font-bold' : 'text-stone-400 hover:text-stone-200'
                      }`}
                    >
                      Dynamic Scan QR
                    </button>
                  </div>

                  {upiType === 'id' ? (
                    <div className="space-y-3">
                      <div>
                        <label className="text-[11px] text-stone-400 block mb-1">Virtual Payment Address (VPA)</label>
                        <input
                          type="text"
                          value={upiId}
                          onChange={(e) => setUpiId(e.target.value)}
                          placeholder="username@bank"
                          className={`w-full p-2.5 rounded-lg border text-xs font-medium focus:outline-hidden ${
                            darkMode ? 'bg-stone-900 border-stone-700' : 'bg-white border-stone-300'
                          }`}
                        />
                      </div>

                      {/* 1-click handle suffixes */}
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-[11px] text-stone-400">Quick Suffix:</span>
                        {['@okhdfcbank', '@oksbi', '@ybl', '@paytm'].map((sfx) => (
                          <button
                            key={sfx}
                            type="button"
                            onClick={() => {
                              const prefix = upiId.split('@')[0] || 'aarav.sharma';
                              setUpiId(`${prefix}${sfx}`);
                            }}
                            className="px-2 py-0.5 rounded text-[11px] border border-stone-700 hover:border-amber-500 text-stone-300"
                          >
                            {sfx}
                          </button>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center p-4 border rounded-xl bg-stone-900/80 border-stone-800 space-y-3">
                      <div className="p-3 bg-white rounded-xl shadow-md">
                        {/* Dynamic SVG simulated QR */}
                        <div className="w-36 h-36 bg-white flex flex-col items-center justify-center border-4 border-stone-900 p-2">
                          <QrCode className="w-28 h-28 text-stone-950" />
                        </div>
                      </div>
                      <span className="text-xs font-medium text-amber-400">
                        Scan with GPay, PhonePe, Paytm, or BHIM UPI
                      </span>
                      <span className="text-[10px] text-stone-400">
                        Ref: UPI-LX-{Math.floor(100000 + Math.random() * 900000)} · Amount: ₹{effectiveTotal.toLocaleString('en-IN')}
                      </span>
                    </div>
                  )}
                </div>
              )}

              {/* Rail 3: Net Banking */}
              {paymentMethod === 'NET_BANKING' && (
                <div className="space-y-4">
                  <span className="text-[11px] text-stone-400 block">Popular Indian Luxury & Commercial Banks:</span>
                  <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
                    {['HDFC Bank', 'ICICI Bank', 'State Bank of India', 'Axis Bank', 'Kotak Mahindra'].map((bank) => (
                      <button
                        key={bank}
                        type="button"
                        onClick={() => setSelectedBank(bank)}
                        className={`p-2.5 rounded-xl border text-xs font-medium text-center transition-all ${
                          selectedBank === bank
                            ? 'border-amber-500 bg-amber-500/15 text-amber-400 font-bold'
                            : 'border-stone-700/60 hover:border-stone-600 text-stone-300'
                        }`}
                      >
                        <Building className="w-4 h-4 mx-auto mb-1 text-amber-500" />
                        <span className="line-clamp-1">{bank}</span>
                      </button>
                    ))}
                  </div>

                  <div>
                    <label className="text-[11px] text-stone-400 block mb-1">Or choose all Indian Scheduled Banks:</label>
                    <select
                      value={selectedBank}
                      onChange={(e) => setSelectedBank(e.target.value)}
                      className={`w-full p-2.5 rounded-lg border text-xs font-medium focus:outline-hidden ${
                        darkMode ? 'bg-stone-900 border-stone-700' : 'bg-white border-stone-300'
                      }`}
                    >
                      <option value="HDFC Bank">HDFC Bank</option>
                      <option value="ICICI Bank">ICICI Bank</option>
                      <option value="State Bank of India">State Bank of India</option>
                      <option value="Axis Bank">Axis Bank</option>
                      <option value="Kotak Mahindra Bank">Kotak Mahindra Bank</option>
                      <option value="Citibank India">Citibank India</option>
                      <option value="Standard Chartered">Standard Chartered</option>
                      <option value="IndusInd Bank">IndusInd Bank</option>
                      <option value="Yes Bank">Yes Bank</option>
                      <option value="Bank of Baroda">Bank of Baroda</option>
                    </select>
                  </div>
                </div>
              )}

              {/* Rail 4: Digital Wallets */}
              {paymentMethod === 'WALLET' && (
                <div className="space-y-3">
                  <span className="text-[11px] text-stone-400 block">Select Digital Wallet:</span>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {['Amazon Pay', 'Paytm Wallet', 'PhonePe Wallet', 'Apple Pay'].map((w) => (
                      <button
                        key={w}
                        type="button"
                        onClick={() => setSelectedWallet(w)}
                        className={`p-3 rounded-xl border text-xs font-medium text-center transition-all ${
                          selectedWallet === w
                            ? 'border-amber-500 bg-amber-500/15 text-amber-400 font-bold'
                            : 'border-stone-700/60 hover:border-stone-600 text-stone-300'
                        }`}
                      >
                        <Wallet className="w-4 h-4 mx-auto mb-1 text-amber-500" />
                        <span>{w}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Rail 5: Pay at Hotel */}
              {paymentMethod === 'PAY_AT_HOTEL' && (
                <div className="p-4 rounded-xl border border-amber-500/30 bg-amber-500/10 space-y-2">
                  <div className="flex items-center gap-2 text-amber-400 font-semibold text-xs">
                    <HotelIcon className="w-4 h-4" />
                    <span>Zero Advance Payment Guarantee</span>
                  </div>
                  <p className="text-xs text-stone-300 leading-relaxed">
                    Your reservation will be confirmed immediately. No advance deduction is made now. Settle your balance of ₹{pricing.totalAmount.toLocaleString('en-IN')} upon check-in at the hotel front desk with government-issued photo ID.
                  </p>
                </div>
              )}

              {/* Rail 6: Gift Vouchers / Club Rewards */}
              {paymentMethod === 'VOUCHER' && (
                <div className="space-y-3">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={voucherCode}
                      onChange={(e) => setVoucherCode(e.target.value.toUpperCase())}
                      placeholder="e.g. LUXE-GOLD-2026"
                      className={`flex-1 p-2.5 rounded-lg border text-xs font-mono focus:outline-hidden ${
                        darkMode ? 'bg-stone-900 border-stone-700' : 'bg-white border-stone-300'
                      }`}
                    />
                    <button
                      type="button"
                      onClick={handleApplyVoucher}
                      className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs rounded-lg cursor-pointer"
                    >
                      Apply
                    </button>
                  </div>

                  {voucherError && (
                    <p className="text-xs text-rose-400">{voucherError}</p>
                  )}

                  {voucherApplied && (
                    <div className="p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-xs text-emerald-400 flex items-center justify-between">
                      <span className="font-semibold">Voucher '{voucherApplied.code}' Applied!</span>
                      <span>-₹{voucherApplied.discount.toLocaleString('en-IN')} Credit</span>
                    </div>
                  )}

                  <div className="pt-2 flex flex-wrap gap-2 text-[11px] text-stone-400">
                    <span>Try demo voucher codes:</span>
                    <button
                      type="button"
                      onClick={() => {
                        setVoucherCode('LUXE-GOLD-2026');
                        setVoucherApplied({ code: 'LUXE-GOLD-2026', discount: Math.min(10000, pricing.totalAmount) });
                      }}
                      className="px-2 py-0.5 rounded border border-stone-700 hover:border-amber-500 text-amber-400 font-mono"
                    >
                      LUXE-GOLD-2026 (₹10,000 off)
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setVoucherCode('DIAMOND-STAY');
                        setVoucherApplied({ code: 'DIAMOND-STAY', discount: pricing.totalAmount });
                      }}
                      className="px-2 py-0.5 rounded border border-stone-700 hover:border-amber-500 text-amber-400 font-mono"
                    >
                      DIAMOND-STAY (100% Complimentary)
                    </button>
                  </div>
                </div>
              )}

              {/* Bank Decline Simulator Switch (Hackathon test tool) */}
              <div className="mt-5 pt-4 border-t border-stone-700/30">
                <label className="flex items-start gap-3 p-3 rounded-xl border border-rose-500/30 bg-rose-500/5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={simulateDecline}
                    onChange={(e) => setSimulateDecline(e.target.checked)}
                    className="mt-0.5 w-4 h-4 rounded text-rose-500 focus:ring-rose-500 cursor-pointer"
                  />
                  <div className="text-left">
                    <span className="text-xs font-bold text-rose-400 flex items-center gap-1.5">
                      <AlertTriangle className="w-3.5 h-3.5 text-rose-500" />
                      Simulate Bank Gateway Decline (Hackathon Test Mode)
                    </span>
                    <p className="text-[11px] text-stone-400 mt-0.5">
                      When checked, triggers a simulated <code className="text-rose-300 font-mono">BANK_GATEWAY_DECLINED</code> failure to test that held room inventory safely rolls back without leaking.
                    </p>
                  </div>
                </label>
              </div>
            </div>

            {/* Error Message Alert */}
            {errorMessage && (
              <div className="p-4 rounded-xl border border-rose-500/50 bg-rose-500/10 text-rose-300 text-xs flex items-start gap-2.5">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <div className="leading-relaxed">
                  <span className="font-semibold block mb-0.5">Authorization Error:</span>
                  {errorMessage}
                </div>
              </div>
            )}
          </div>

          {/* Right Column: Stay Summary & Sticky Confirm Button (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            <div className={`p-5 rounded-2xl border ${
              darkMode ? 'bg-stone-800/60 border-stone-700/60' : 'bg-stone-50 border-stone-200'
            }`}>
              <h3 className="text-xs font-bold uppercase tracking-wider text-amber-500 mb-4">
                Reservation Summary
              </h3>

              {/* Hotel & Room Info */}
              <div className="flex gap-3 pb-4 border-b border-stone-700/30">
                <img
                  src={roomType.imageUrl}
                  alt={roomType.name}
                  referrerPolicy="no-referrer"
                  className="w-20 h-20 rounded-xl object-cover shrink-0"
                />
                <div>
                  <h4 className="font-serif text-sm font-bold text-stone-100 line-clamp-1">
                    {hotel.name}
                  </h4>
                  <p className="text-xs text-amber-500 font-semibold mb-1">
                    {roomType.name}
                  </p>
                  <p className="text-[11px] text-stone-400">
                    {hotel.city} · {hotel.neighborhood}
                  </p>
                </div>
              </div>

              {/* Dates & Guests */}
              <div className="py-3 border-b border-stone-700/30 space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-stone-400">Check-in:</span>
                  <span className="font-medium">{checkIn}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-400">Check-out:</span>
                  <span className="font-medium">{checkOut}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-400">Length of Stay:</span>
                  <span className="font-medium">{pricing.numberOfNights} Nights · {numRooms} Room</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-400">Guests:</span>
                  <span className="font-medium">{guestsCount} Guests</span>
                </div>
              </div>

              {/* Pricing breakdown */}
              <div className="py-3 border-b border-stone-700/30 space-y-1.5 text-xs">
                <div className="flex justify-between">
                  <span className="text-stone-400">Base Room Rate:</span>
                  <span className="font-mono">₹{pricing.baseNightlyRate.toLocaleString('en-IN')}/night</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-400">Occupancy Surge:</span>
                  <span className="text-amber-400">{pricing.occupancyLabel}</span>
                </div>
                {pricing.weekendMultiplier > 1 && (
                  <div className="flex justify-between">
                    <span className="text-stone-400">Weekend Surge:</span>
                    <span className="text-amber-400">1.20x</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-stone-400">Subtotal:</span>
                  <span className="font-mono">₹{pricing.subtotal.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-400">Luxury GST (18%):</span>
                  <span className="font-mono">₹{pricing.taxAmount.toLocaleString('en-IN')}</span>
                </div>

                {voucherApplied && (
                  <div className="flex justify-between text-emerald-400 font-semibold pt-1">
                    <span>Discount ({voucherApplied.code}):</span>
                    <span className="font-mono">-₹{voucherApplied.discount.toLocaleString('en-IN')}</span>
                  </div>
                )}
              </div>

              {/* Grand Total */}
              <div className="pt-3 flex items-baseline justify-between font-bold">
                <span className="text-sm">Total Payable:</span>
                <span className="text-2xl font-mono text-amber-500">
                  ₹{effectiveTotal.toLocaleString('en-IN')}
                </span>
              </div>
            </div>

            {/* Refund Policy Summary Note */}
            <div className={`p-4 rounded-xl border text-[11px] space-y-1.5 ${
              darkMode ? 'bg-stone-900/60 border-stone-800 text-stone-400' : 'bg-stone-100 border-stone-200 text-stone-600'
            }`}>
              <div className="font-semibold text-amber-500 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Tiered Cancellation & Refund Policy</span>
              </div>
              <p>• Cancel &gt; 48 hours before check-in: <strong>100% full refund</strong></p>
              <p>• Cancel 24–48 hours before check-in: <strong>50% partial refund</strong></p>
              <p>• Cancel &lt; 24 hours before check-in: <strong>Non-refundable</strong></p>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={processing}
              className={`w-full py-4 rounded-2xl font-bold uppercase tracking-wider text-xs flex items-center justify-center gap-2 shadow-xl transition-all cursor-pointer ${
                processing
                  ? 'bg-stone-700 text-stone-400 cursor-wait'
                  : 'bg-gradient-to-r from-amber-500 via-amber-400 to-amber-300 hover:from-amber-400 hover:to-amber-200 text-stone-950 shadow-amber-500/20 hover:scale-[1.02] active:scale-[0.98]'
              }`}
            >
              {processing ? (
                <>
                  <div className="w-4 h-4 rounded-full border-2 border-stone-950 border-t-transparent animate-spin" />
                  <span>Authorizing Gateway & Locking Suite...</span>
                </>
              ) : (
                <>
                  <Lock className="w-4 h-4 stroke-[2.5]" />
                  <span>
                    {paymentMethod === 'PAY_AT_HOTEL'
                      ? 'Confirm Reservation (₹0 Now)'
                      : `Confirm & Pay ₹${effectiveTotal.toLocaleString('en-IN')}`}
                  </span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

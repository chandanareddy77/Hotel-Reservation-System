import React from 'react';
import { Star, MapPin, Sparkles, Wifi, Utensils, Waves, ShieldCheck, ChevronRight } from 'lucide-react';
import { Hotel } from '../types/index.ts';

interface HotelCardProps {
  hotel: Hotel & { dynamicStartingPrice?: number };
  onSelect: (hotel: Hotel) => void;
  darkMode: boolean;
}

export const HotelCard: React.FC<HotelCardProps> = ({ hotel, onSelect, darkMode }) => {
  const displayPrice = hotel.dynamicStartingPrice || hotel.startingPrice;

  return (
    <div
      onClick={() => onSelect(hotel)}
      className={`group rounded-2xl overflow-hidden border transition-all duration-300 hover:shadow-2xl cursor-pointer flex flex-col ${
        darkMode
          ? 'bg-stone-900/80 border-stone-800 hover:border-amber-500/40 text-stone-100'
          : 'bg-white border-stone-200 hover:border-amber-500/50 text-stone-900 shadow-sm'
      }`}
    >
      {/* Property Thumbnail with Zoom */}
      <div className="relative aspect-4/3 w-full overflow-hidden bg-stone-800">
        <img
          src={hotel.imageUrl}
          alt={hotel.name}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-transparent to-black/20" />

        {/* City and Rating Overlays */}
        <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-stone-950/70 backdrop-blur-xs text-xs font-medium text-stone-200 border border-white/10">
          <MapPin className="w-3 h-3 text-amber-400" />
          <span>{hotel.city} · {hotel.neighborhood}</span>
        </div>

        <div className="absolute top-3 right-3 flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-500 text-stone-950 font-bold text-xs shadow-md">
          <Star className="w-3 h-3 fill-stone-950 stroke-stone-950" />
          <span>{hotel.rating.toFixed(1)}</span>
          <span className="text-[10px] font-medium opacity-80">({hotel.reviewCount})</span>
        </div>

        {/* Vibe badge bottom left */}
        <div className="absolute bottom-3 left-3">
          <span className="px-2.5 py-0.5 rounded-full bg-stone-900/80 border border-amber-500/30 text-amber-300 text-[11px] font-medium tracking-wide">
            {hotel.vibe} Experience
          </span>
        </div>
      </div>

      {/* Card Content */}
      <div className="p-5 flex-1 flex flex-col justify-between">
        <div>
          <h3 className="font-serif text-xl font-bold tracking-tight mb-2 group-hover:text-amber-500 transition-colors line-clamp-1">
            {hotel.name}
          </h3>

          <p className="text-xs line-clamp-2 text-stone-400 mb-4 leading-relaxed">
            {hotel.description}
          </p>

          {/* Amenity Icons Row */}
          <div className="flex items-center gap-3 text-xs text-stone-400 mb-4 pt-2 border-t border-stone-800/40">
            <span className="inline-flex items-center gap-1">
              <Waves className="w-3.5 h-3.5 text-amber-500" /> Pool & Spa
            </span>
            <span>·</span>
            <span className="inline-flex items-center gap-1">
              <Utensils className="w-3.5 h-3.5 text-amber-500" /> Fine Dining
            </span>
            <span>·</span>
            <span className="inline-flex items-center gap-1">
              <Wifi className="w-3.5 h-3.5 text-amber-500" /> Gigabit Wi-Fi
            </span>
          </div>
        </div>

        {/* Price & Action Row */}
        <div className="pt-3 border-t border-stone-700/20 flex items-end justify-between">
          <div>
            <div className="flex items-center gap-1 text-[11px] text-amber-500 font-medium">
              <Sparkles className="w-3 h-3" />
              <span>Dynamic Yield Rate</span>
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-xs text-stone-400 font-light">From</span>
              <span className="text-lg font-bold font-mono tracking-tight text-amber-500">
                ₹{displayPrice.toLocaleString('en-IN')}
              </span>
              <span className="text-xs text-stone-400">/night</span>
            </div>
          </div>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onSelect(hotel);
            }}
            className="px-3.5 py-2 rounded-lg bg-stone-800 hover:bg-amber-500 text-stone-200 hover:text-stone-950 font-medium text-xs flex items-center gap-1 transition-all duration-200 group-hover:bg-amber-500 group-hover:text-stone-950"
          >
            <span>View Rooms</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import {
  Sparkles,
  MapPin,
  Calendar,
  Compass,
  Heart,
  Briefcase,
  Users,
  Sun,
  Shield,
  Coffee,
  ArrowRight,
  UtensilsCrossed,
  CheckCircle2
} from 'lucide-react';
import { Hotel, RoomType, PriceBreakdown, StayPlannerPlan } from '../types/index.ts';
import { api } from '../services/api.ts';

interface SmartStayPlannerViewProps {
  darkMode: boolean;
  onBookRoom: (hotel: Hotel, roomType: RoomType) => void;
}

export const SmartStayPlannerView: React.FC<SmartStayPlannerViewProps> = ({ darkMode, onBookRoom }) => {
  const [destination, setDestination] = useState<string>('Any');
  const [purpose, setPurpose] = useState<'ROMANCE' | 'BUSINESS' | 'FAMILY' | 'WELLNESS' | 'LEISURE'>('ROMANCE');
  const [budgetMax, setBudgetMax] = useState<number>(18000);
  const [partySize, setPartySize] = useState<number>(2);
  const [desiredVibe, setDesiredVibe] = useState<'Heritage' | 'Modern' | 'Beach' | 'Wellness' | 'Any'>('Any');

  const [loading, setLoading] = useState<boolean>(false);
  const [plan, setPlan] = useState<StayPlannerPlan | null>(null);

  const handleGeneratePlan = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const generated = await api.generateStayPlan({
        destination: destination === 'Any' ? undefined : destination,
        purpose,
        budgetMax,
        partySize,
        desiredVibe
      });
      setPlan(generated);
    } catch (err: any) {
      alert(err.message || 'Failed to generate stay plan');
    } finally {
      setLoading(false);
    }
  };

  const purposes = [
    { id: 'ROMANCE', label: 'Romantic Escape', icon: Heart, desc: 'Candlelight dinners, private plunge pools, royal views' },
    { id: 'BUSINESS', label: 'Executive Workcation', icon: Briefcase, desc: 'Quiet acoustic pods, high-speed fiber, boardroom suites' },
    { id: 'FAMILY', label: 'Family Holiday', icon: Users, desc: 'Spacious villas, kids lagoons, curated cultural walks' },
    { id: 'WELLNESS', label: 'Ayurvedic Retreat', icon: Sun, desc: 'Holistic spas, organic nutrition, meditation pavilions' },
    { id: 'LEISURE', label: 'Luxury Leisure', icon: Compass, desc: 'Fine dining, yacht charters, heritage architecture' }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="mb-10 text-center max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-amber-500/30 bg-amber-500/10 text-amber-400 text-xs font-medium tracking-widest uppercase mb-3">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Intelligent Concierge</span>
        </div>
        <h1 className="font-serif text-3xl sm:text-5xl font-bold tracking-tight mb-3">
          AI Smart Stay & Itinerary Planner
        </h1>
        <p className="text-xs sm:text-sm text-stone-400 leading-relaxed font-light">
          Tell us your ideal escape style. Our intelligent itinerary engine pairs signature suites with hand-curated morning, afternoon, and dining schedules.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Questionnaire Form (5 cols) */}
        <form
          onSubmit={handleGeneratePlan}
          className={`lg:col-span-5 p-6 rounded-3xl border shadow-xl space-y-6 ${
            darkMode ? 'bg-stone-900 border-stone-800 text-stone-100' : 'bg-white border-stone-200 text-stone-900'
          }`}
        >
          <h2 className="font-serif text-xl font-bold border-b border-stone-800 pb-3">
            Trip Parameters
          </h2>

          {/* Destination */}
          <div>
            <label className="text-xs font-semibold uppercase tracking-wider text-amber-500 block mb-2">
              Preferred Haven / City
            </label>
            <select
              value={destination}
              onChange={(e) => setDestination(e.target.value)}
              className={`w-full p-3 rounded-xl border text-xs font-medium focus:outline-hidden ${
                darkMode ? 'bg-stone-800/80 border-stone-700' : 'bg-stone-50 border-stone-300'
              }`}
            >
              <option value="Any">Surprise Me (Any City)</option>
              <option value="Hyderabad">Hyderabad (Nizam Palaces & HITEC City)</option>
              <option value="Mumbai">Mumbai (Marine Drive & Oceanfront)</option>
              <option value="Goa">Goa (Vagator Barefoot Beachfront)</option>
              <option value="Bangalore">Bangalore (Botanical Arboretums)</option>
              <option value="Delhi">Delhi (Aerocity Diplomatic Manor)</option>
            </select>
          </div>

          {/* Purpose options */}
          <div>
            <label className="text-xs font-semibold uppercase tracking-wider text-amber-500 block mb-2">
              Trip Ambience & Purpose
            </label>
            <div className="grid grid-cols-1 gap-2">
              {purposes.map((p) => {
                const Icon = p.icon;
                const isSelected = purpose === p.id;
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setPurpose(p.id as any)}
                    className={`p-3 rounded-xl border text-left flex items-center gap-3 transition-all cursor-pointer ${
                      isSelected
                        ? 'border-amber-500 bg-amber-500/10 text-stone-100'
                        : 'border-stone-700/60 hover:border-stone-600 text-stone-300'
                    }`}
                  >
                    <div className={`p-2 rounded-lg ${isSelected ? 'bg-amber-500 text-stone-950' : 'bg-stone-800 text-stone-400'}`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-bold">{p.label}</div>
                      <div className="text-[11px] text-stone-400">{p.desc}</div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Budget slider */}
          <div>
            <div className="flex justify-between items-baseline mb-2">
              <label className="text-xs font-semibold uppercase tracking-wider text-amber-500">
                Nightly Tariff Cap
              </label>
              <span className="font-mono text-sm font-bold text-amber-400">
                ₹{budgetMax.toLocaleString('en-IN')}/night
              </span>
            </div>
            <input
              type="range"
              min={4000}
              max={35000}
              step={1000}
              value={budgetMax}
              onChange={(e) => setBudgetMax(Number(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-stone-400 mt-1">
              <span>Standard (₹4,000)</span>
              <span>Suites (₹15,000)</span>
              <span>Presidential (₹35,000)</span>
            </div>
          </div>

          {/* Party size & Desired Vibe */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] text-stone-400 block mb-1">Party Composition</label>
              <select
                value={partySize}
                onChange={(e) => setPartySize(Number(e.target.value))}
                className={`w-full p-2.5 rounded-lg border text-xs font-medium focus:outline-hidden ${
                  darkMode ? 'bg-stone-800/80 border-stone-700' : 'bg-stone-50 border-stone-300'
                }`}
              >
                <option value={1}>Solo Voyager (1)</option>
                <option value={2}>Couple / Duo (2)</option>
                <option value={3}>Small Party (3)</option>
                <option value={4}>Family / Group (4+)</option>
              </select>
            </div>

            <div>
              <label className="text-[11px] text-stone-400 block mb-1">Desired Vibe</label>
              <select
                value={desiredVibe}
                onChange={(e) => setDesiredVibe(e.target.value as any)}
                className={`w-full p-2.5 rounded-lg border text-xs font-medium focus:outline-hidden ${
                  darkMode ? 'bg-stone-800/80 border-stone-700' : 'bg-stone-50 border-stone-300'
                }`}
              >
                <option value="Any">All Aesthetics</option>
                <option value="Heritage">Heritage Regal</option>
                <option value="Modern">Modern Minimalist</option>
                <option value="Beach">Barefoot Beach</option>
                <option value="Wellness">Biophilic Wellness</option>
              </select>
            </div>
          </div>

          {/* Submit */}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-stone-950 font-bold text-xs uppercase tracking-wider shadow-lg flex items-center justify-center gap-2 cursor-pointer transition-all hover:scale-[1.01]"
          >
            {loading ? (
              <>
                <div className="w-4 h-4 rounded-full border-2 border-stone-950 border-t-transparent animate-spin" />
                <span>Crafting Bespoke Itinerary...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 stroke-[2.2]" />
                <span>Generate Curated Stay Plan</span>
              </>
            )}
          </button>
        </form>

        {/* Generated Plan Output (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {!plan && !loading && (
            <div className={`p-12 rounded-3xl border text-center ${
              darkMode ? 'bg-stone-900/60 border-stone-800' : 'bg-white border-stone-200'
            }`}>
              <div className="w-16 h-16 rounded-full bg-amber-500/10 text-amber-500 flex items-center justify-center mx-auto mb-4">
                <Compass className="w-8 h-8" />
              </div>
              <h3 className="font-serif text-2xl font-bold mb-2">
                Ready to Personalize Your Escape
              </h3>
              <p className="text-xs text-stone-400 max-w-md mx-auto leading-relaxed">
                Select your destination preferences and purpose on the left. LuxeStay will generate a complete day-by-day itinerary with matched suites and dining bookings.
              </p>
            </div>
          )}

          {loading && (
            <div className={`p-16 rounded-3xl border flex flex-col items-center justify-center gap-4 text-center ${
              darkMode ? 'bg-stone-900 border-stone-800' : 'bg-white border-stone-200'
            }`}>
              <div className="w-12 h-12 rounded-full border-3 border-amber-500 border-t-transparent animate-spin" />
              <div className="space-y-1">
                <h4 className="font-serif text-lg font-bold">Curating Bespoke Luxury Itinerary</h4>
                <p className="text-xs text-stone-400">Pairing Michelin-starred dining, cultural private access, and signature suites...</p>
              </div>
            </div>
          )}

          {plan && !loading && (
            <div className="space-y-6">
              {/* Hotel & Room Match Spotlight Card */}
              <div className={`p-6 rounded-3xl border overflow-hidden relative ${
                darkMode ? 'bg-stone-900 border-amber-500/40' : 'bg-white border-amber-500/50 shadow-md'
              }`}>
                <div className="flex flex-col sm:flex-row gap-5 items-center">
                  <img
                    src={plan.recommendedRoom.imageUrl}
                    alt={plan.recommendedRoom.name}
                    referrerPolicy="no-referrer"
                    className="w-full sm:w-48 aspect-4/3 rounded-2xl object-cover"
                  />
                  <div className="flex-1 space-y-2">
                    <div className="flex items-center gap-2 text-xs font-semibold text-amber-500 uppercase tracking-widest">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Recommended Luxury Suite</span>
                    </div>

                    <h3 className="font-serif text-2xl font-bold text-stone-100">
                      {plan.recommendedHotel.name}
                    </h3>
                    <p className="text-sm font-semibold text-amber-400">
                      {plan.recommendedRoom.name} ({plan.recommendedRoom.tier})
                    </p>

                    <p className="text-xs text-stone-400 leading-relaxed">
                      {plan.rationale}
                    </p>

                    <div className="pt-2 flex items-center justify-between">
                      <div className="flex items-baseline gap-1">
                        <span className="text-xs text-stone-400">Tariff from:</span>
                        <span className="font-mono text-lg font-bold text-amber-500">
                          ₹{plan.priceEstimate.toLocaleString('en-IN')}
                        </span>
                        <span className="text-xs text-stone-400">/night</span>
                      </div>

                      <button
                        type="button"
                        onClick={() => onBookRoom(plan.recommendedHotel, plan.recommendedRoom)}
                        className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-md transition-all cursor-pointer"
                      >
                        <span>Book This Suite</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Day-by-Day Itinerary Schedule */}
              <div className="space-y-4">
                <h3 className="font-serif text-xl font-bold flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-amber-500" />
                  <span>Curated Day-by-Day Experience Schedule</span>
                </h3>

                {plan.days.map((day) => (
                  <div
                    key={day.dayNumber}
                    className={`p-5 rounded-2xl border space-y-4 ${
                      darkMode ? 'bg-stone-900 border-stone-800' : 'bg-white border-stone-200'
                    }`}
                  >
                    <div className="flex items-center gap-2 pb-2 border-b border-stone-800">
                      <span className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 text-xs font-bold flex items-center justify-center">
                        {day.dayNumber}
                      </span>
                      <h4 className="font-serif text-base font-bold text-stone-200">
                        {day.title}
                      </h4>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                      {/* Morning */}
                      <div className={`p-3 rounded-xl border ${darkMode ? 'bg-stone-800/40 border-stone-800' : 'bg-stone-50 border-stone-200'}`}>
                        <span className="text-[10px] uppercase font-bold text-amber-500 block mb-1">
                          Morning ({day.morning.time})
                        </span>
                        <div className="font-bold text-stone-200 mb-1">{day.morning.title}</div>
                        <p className="text-[11px] text-stone-400 leading-relaxed">{day.morning.desc}</p>
                      </div>

                      {/* Afternoon */}
                      <div className={`p-3 rounded-xl border ${darkMode ? 'bg-stone-800/40 border-stone-800' : 'bg-stone-50 border-stone-200'}`}>
                        <span className="text-[10px] uppercase font-bold text-amber-500 block mb-1">
                          Afternoon ({day.afternoon.time})
                        </span>
                        <div className="font-bold text-stone-200 mb-1">{day.afternoon.title}</div>
                        <p className="text-[11px] text-stone-400 leading-relaxed">{day.afternoon.desc}</p>
                      </div>

                      {/* Evening */}
                      <div className={`p-3 rounded-xl border ${darkMode ? 'bg-stone-800/40 border-stone-800' : 'bg-stone-50 border-stone-200'}`}>
                        <span className="text-[10px] uppercase font-bold text-amber-500 block mb-1">
                          Evening ({day.evening.time})
                        </span>
                        <div className="font-bold text-stone-200 mb-1">{day.evening.title}</div>
                        <p className="text-[11px] text-stone-400 leading-relaxed">{day.evening.desc}</p>
                      </div>
                    </div>

                    {/* Dining Highlight */}
                    <div className={`p-3 rounded-xl border border-amber-500/20 bg-amber-500/5 flex items-start gap-2.5 text-xs`}>
                      <UtensilsCrossed className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-bold text-amber-400">{day.diningHighlight.name}</span>
                        <span className="text-stone-400"> ({day.diningHighlight.cuisine}) — </span>
                        <span className="text-stone-300">{day.diningHighlight.note}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

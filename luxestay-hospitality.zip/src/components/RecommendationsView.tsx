import React, { useState, useEffect } from 'react';
import {
  Heart,
  Briefcase,
  Users,
  Sun,
  Sparkles,
  ArrowRight,
  Star,
  MapPin,
  CheckCircle2
} from 'lucide-react';
import { PersonaRecommendation, Hotel, RoomType } from '../types/index.ts';
import { api } from '../services/api.ts';

interface RecommendationsViewProps {
  darkMode: boolean;
  onSelectProperty: (hotel: Hotel) => void;
  onBookRoom: (hotel: Hotel, roomType: RoomType) => void;
}

export const RecommendationsView: React.FC<RecommendationsViewProps> = ({
  darkMode,
  onSelectProperty,
  onBookRoom
}) => {
  const [activePersona, setActivePersona] = useState<string>('COUPLE');
  const [recommendations, setRecommendations] = useState<PersonaRecommendation[]>([]);
  const [loading, setLoading] = useState(true);

  const personas = [
    { id: 'COUPLE', label: 'Couples & Romance', icon: Heart, tagline: 'Intimate candlelit dinners, private plunge pools, and royal heritage suites' },
    { id: 'BUSINESS', label: 'Executive & Business', icon: Briefcase, tagline: 'Ergonomic tech pods, soundproof boardrooms, and zero-latency fiber' },
    { id: 'FAMILY', label: 'Family Holiday', icon: Users, tagline: 'Multi-bedroom beach villas, expansive lagoons, and cultural storytelling' },
    { id: 'WELLNESS', label: 'Ayurveda & Wellness', icon: Sun, tagline: 'Certified Ayurvedic practitioners, canopy spas, and organic nutrition' },
    { id: 'SOLO', label: 'Solo & Mindful', icon: Sparkles, tagline: 'Safe promenade sanctuaries, contemplative reading libraries, and wellness' }
  ];

  useEffect(() => {
    let isMounted = true;
    async function loadRecs() {
      try {
        setLoading(true);
        const data = await api.getRecommendations(activePersona);
        if (isMounted) setRecommendations(data);
      } catch (err) {
        console.error('Failed to load persona recommendations:', err);
      } finally {
        if (isMounted) setLoading(false);
      }
    }
    loadRecs();
    return () => {
      isMounted = false;
    };
  }, [activePersona]);

  const currentPersonaMeta = personas.find(p => p.id === activePersona);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="mb-8 text-center max-w-2xl mx-auto">
        <span className="text-xs font-semibold uppercase tracking-widest text-amber-500">
          Algorithmic Curation
        </span>
        <h1 className="font-serif text-3xl sm:text-4xl font-bold tracking-tight mt-1 mb-2">
          Persona-Matched Sanctuaries
        </h1>
        <p className="text-xs text-stone-400">
          Tailored property rankings scored by amenities, room architecture, acoustic ratings, and bespoke dining.
        </p>
      </div>

      {/* Persona Switcher Tabs */}
      <div className="flex items-center justify-center gap-2 overflow-x-auto pb-4 mb-8">
        {personas.map((p) => {
          const Icon = p.icon;
          const isSelected = activePersona === p.id;
          return (
            <button
              key={p.id}
              onClick={() => setActivePersona(p.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-medium transition-all whitespace-nowrap cursor-pointer ${
                isSelected
                  ? 'bg-amber-500 text-stone-950 font-bold shadow-md scale-[1.02]'
                  : darkMode
                    ? 'bg-stone-900 border border-stone-800 text-stone-300 hover:text-white'
                    : 'bg-white border border-stone-200 text-stone-700 hover:text-stone-950 shadow-xs'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{p.label}</span>
            </button>
          );
        })}
      </div>

      {/* Active Persona Banner */}
      {currentPersonaMeta && (
        <div className={`p-4 rounded-2xl border mb-8 text-center text-xs ${
          darkMode ? 'bg-stone-900/60 border-stone-800 text-stone-300' : 'bg-stone-50 border-stone-200 text-stone-700'
        }`}>
          <span className="font-semibold text-amber-500 mr-2">Curation Intent:</span>
          <span>{currentPersonaMeta.tagline}</span>
        </div>
      )}

      {/* Recommendations Cards */}
      {loading ? (
        <div className="py-20 flex flex-col items-center justify-center gap-3 text-stone-400">
          <div className="w-8 h-8 rounded-full border-2 border-amber-500 border-t-transparent animate-spin" />
          <span className="text-xs">Computing persona match scores...</span>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {recommendations.map((rec, idx) => (
            <div
              key={rec.hotel.id}
              className={`rounded-3xl border overflow-hidden flex flex-col justify-between transition-all duration-300 hover:shadow-2xl ${
                darkMode ? 'bg-stone-900 border-stone-800 hover:border-amber-500/40' : 'bg-white border-stone-200 hover:border-amber-500/40 shadow-sm'
              }`}
            >
              <div>
                {/* Image with match badge */}
                <div className="relative aspect-16/10 w-full overflow-hidden bg-stone-800">
                  <img
                    src={rec.hotel.imageUrl}
                    alt={rec.hotel.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-transparent to-black/20" />

                  {/* Match percentage badge */}
                  <div className="absolute top-3 right-3 px-3 py-1 rounded-full bg-emerald-500 text-stone-950 font-bold text-xs shadow-lg flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 fill-stone-950" />
                    <span>{rec.matchScore}% Match</span>
                  </div>

                  <div className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-stone-950/80 text-stone-200 text-[11px] font-medium border border-white/10 flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-amber-400" />
                    <span>{rec.hotel.city}</span>
                  </div>

                  <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-stone-200 text-xs">
                    <span className="font-semibold text-amber-400">Rank #{idx + 1}</span>
                    <div className="flex items-center gap-1">
                      <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                      <span>{rec.hotel.rating.toFixed(1)}</span>
                    </div>
                  </div>
                </div>

                {/* Content */}
                <div className="p-5 space-y-4">
                  <div>
                    <h3 className="font-serif text-xl font-bold line-clamp-1 mb-1 text-stone-100">
                      {rec.hotel.name}
                    </h3>
                    <p className="text-xs text-stone-400 line-clamp-2 leading-relaxed">
                      {rec.explanation}
                    </p>
                  </div>

                  {/* Highlights list */}
                  <div className="space-y-1.5 pt-2 border-t border-stone-800/40">
                    <span className="text-[10px] uppercase font-bold text-amber-500 tracking-wider">
                      Signature Highlights
                    </span>
                    {rec.highlights.map((hl, i) => (
                      <div key={i} className="flex items-center gap-2 text-xs text-stone-300">
                        <CheckCircle2 className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                        <span className="line-clamp-1">{hl}</span>
                      </div>
                    ))}
                  </div>

                  {/* Recommended Room Box */}
                  <div className={`p-3 rounded-xl border text-xs ${
                    darkMode ? 'bg-stone-800/50 border-stone-700/60' : 'bg-stone-50 border-stone-200'
                  }`}>
                    <span className="text-[10px] uppercase font-bold text-stone-400 block">
                      Recommended Suite
                    </span>
                    <div className="font-semibold text-amber-400 mt-0.5">
                      {rec.recommendedRoomType.name}
                    </div>
                    <div className="flex items-baseline justify-between mt-1 text-[11px] text-stone-400">
                      <span>{rec.recommendedRoomType.bedType}</span>
                      <span className="font-mono text-stone-200 font-bold">
                        ₹{rec.recommendedRoomType.basePrice.toLocaleString('en-IN')}/night
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Bottom Actions */}
              <div className="p-5 pt-0 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => onSelectProperty(rec.hotel)}
                  className="flex-1 py-2.5 rounded-xl border border-stone-700 hover:border-amber-500 text-stone-200 text-xs font-semibold transition-colors cursor-pointer text-center"
                >
                  View Details
                </button>
                <button
                  type="button"
                  onClick={() => onBookRoom(rec.hotel, rec.recommendedRoomType)}
                  className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-bold uppercase tracking-wider transition-colors shadow-md cursor-pointer text-center"
                >
                  Reserve Suite
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

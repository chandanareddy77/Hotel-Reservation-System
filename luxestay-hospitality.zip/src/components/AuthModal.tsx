import React, { useState } from 'react';
import { X, ShieldCheck, User as UserIcon, Lock, Sparkles, KeyRound } from 'lucide-react';
import { api } from '../services/api.ts';
import { User } from '../types/index.ts';

interface AuthModalProps {
  onClose: () => void;
  onLoginSuccess: (user: User) => void;
  darkMode: boolean;
}

export const AuthModal: React.FC<AuthModalProps> = ({ onClose, onLoginSuccess, darkMode }) => {
  const [activeTab, setActiveTab] = useState<'USER' | 'ADMIN'>('USER');
  const [email, setEmail] = useState('user@luxestay.com');
  const [password, setPassword] = useState('user123');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleTabChange = (role: 'USER' | 'ADMIN') => {
    setActiveTab(role);
    setError(null);
    if (role === 'USER') {
      setEmail('user@luxestay.com');
      setPassword('user123');
    } else {
      setEmail('admin@luxestay.com');
      setPassword('admin123');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const data = await api.login(email, password);
      onLoginSuccess(data.user);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Invalid credentials');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className={`relative w-full max-w-md rounded-3xl border shadow-2xl overflow-hidden p-6 sm:p-8 ${
        darkMode ? 'bg-stone-900 border-stone-800 text-stone-100' : 'bg-white border-stone-200 text-stone-900'
      }`}>
        <div className="flex items-center justify-between pb-4 mb-4 border-b border-stone-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-500 flex items-center justify-center">
              <KeyRound className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-serif text-xl font-bold tracking-tight">
                LuxeStay Portal
              </h2>
              <span className="text-[10px] text-stone-400">Select Access Persona</span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full border hover:bg-stone-800 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* 2 Tabs: Guest Traveler vs Staff Admin */}
        <div className="grid grid-cols-2 gap-1.5 p-1 rounded-2xl bg-stone-800/80 border border-stone-700/60 mb-6 text-xs">
          <button
            type="button"
            onClick={() => handleTabChange('USER')}
            className={`py-2 px-3 rounded-xl font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'USER'
                ? 'bg-amber-500 text-stone-950 shadow-sm'
                : 'text-stone-300 hover:text-white'
            }`}
          >
            <UserIcon className="w-3.5 h-3.5" />
            <span>Traveler / Guest</span>
          </button>

          <button
            type="button"
            onClick={() => handleTabChange('ADMIN')}
            className={`py-2 px-3 rounded-xl font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'ADMIN'
                ? 'bg-amber-500 text-stone-950 shadow-sm'
                : 'text-stone-300 hover:text-white'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Staff & Admin</span>
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-[11px] text-stone-400 block mb-1">Email Address</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className={`w-full p-2.5 rounded-xl border text-xs font-medium focus:outline-hidden ${
                darkMode ? 'bg-stone-800/60 border-stone-700 text-stone-100' : 'bg-stone-50 border-stone-300 text-stone-900'
              }`}
            />
          </div>

          <div>
            <label className="text-[11px] text-stone-400 block mb-1">Password</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className={`w-full p-2.5 rounded-xl border text-xs font-medium focus:outline-hidden ${
                darkMode ? 'bg-stone-800/60 border-stone-700 text-stone-100' : 'bg-stone-50 border-stone-300 text-stone-900'
              }`}
            />
          </div>

          {error && (
            <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-stone-950 font-bold text-xs uppercase tracking-wider shadow-md transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            {loading ? (
              <div className="w-4 h-4 rounded-full border-2 border-stone-950 border-t-transparent animate-spin" />
            ) : (
              <span>Sign In as {activeTab === 'ADMIN' ? 'General Manager' : 'Guest'}</span>
            )}
          </button>
        </form>

        {/* 1-Click Demo Fillers */}
        <div className="mt-6 pt-4 border-t border-stone-800 space-y-2 text-xs">
          <span className="text-[11px] text-stone-400 block">1-Click Demo Credentials:</span>
          <button
            type="button"
            onClick={() => {
              handleTabChange('USER');
            }}
            className={`w-full p-2.5 rounded-xl border text-left text-xs transition-colors flex items-center justify-between ${
              activeTab === 'USER'
                ? 'border-amber-500/40 bg-amber-500/5 text-amber-300'
                : 'border-stone-800 hover:border-stone-700 text-stone-400'
            }`}
          >
            <div>
              <span className="font-semibold block text-stone-200">Aarav Sharma (Guest User)</span>
              <span className="text-[10px] text-stone-400">user@luxestay.com / user123</span>
            </div>
            <span className="text-[10px] font-bold text-amber-400">Select</span>
          </button>

          <button
            type="button"
            onClick={() => {
              handleTabChange('ADMIN');
            }}
            className={`w-full p-2.5 rounded-xl border text-left text-xs transition-colors flex items-center justify-between ${
              activeTab === 'ADMIN'
                ? 'border-amber-500/40 bg-amber-500/5 text-amber-300'
                : 'border-stone-800 hover:border-stone-700 text-stone-400'
            }`}
          >
            <div>
              <span className="font-semibold block text-stone-200">Vikram Singhania (General Manager)</span>
              <span className="text-[10px] text-stone-400">admin@luxestay.com / admin123</span>
            </div>
            <span className="text-[10px] font-bold text-amber-400">Select</span>
          </button>
        </div>
      </div>
    </div>
  );
};

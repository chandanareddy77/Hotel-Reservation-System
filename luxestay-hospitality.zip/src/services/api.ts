import {
  Hotel,
  RoomType,
  PriceBreakdown,
  Reservation,
  PaymentRecord,
  BookingRequest,
  RefundPreview,
  PersonaRecommendation,
  StayPlannerPlan,
  AdminAnalytics,
  TestSuiteSummary,
  User
} from '../types/index.ts';

const TOKEN_KEY = 'luxestay_token';
const USER_KEY = 'luxestay_user';

export const getStoredToken = (): string | null => {
  return localStorage.getItem(TOKEN_KEY);
};

export const getStoredUser = (): User | null => {
  const raw = localStorage.getItem(USER_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
};

export const setStoredAuth = (token: string, user: User) => {
  localStorage.setItem(TOKEN_KEY, token);
  localStorage.setItem(USER_KEY, JSON.stringify(user));
};

export const clearStoredAuth = () => {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
};

const getHeaders = (extraHeaders: Record<string, string> = {}) => {
  const token = getStoredToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...extraHeaders
  };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  return headers;
};

export const api = {
  // Hotels
  async getHotels(): Promise<Hotel[]> {
    const res = await fetch('/api/hotels');
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to fetch hotels');
    return data.data;
  },

  async getHotelDetails(id: string): Promise<Hotel & { roomTypes: (RoomType & { currentlyBooked: number; remainingInventory: number; overbookingCap: number; isSoldOut: boolean })[] }> {
    const res = await fetch(`/api/hotels/${id}`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to fetch hotel details');
    return data.data;
  },

  // Room Types
  async getRoomTypes(hotelId?: string): Promise<RoomType[]> {
    const url = hotelId ? `/api/room-types?hotelId=${hotelId}` : '/api/room-types';
    const res = await fetch(url);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to fetch room types');
    return data.data;
  },

  // Dynamic Rate Calculation
  async calculateRate(roomTypeId: string, checkIn: string, checkOut: string, numRooms: number = 1): Promise<PriceBreakdown> {
    const res = await fetch('/api/rates/calculate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ roomTypeId, checkIn, checkOut, numRooms })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to calculate rate');
    return data.data;
  },

  // Auth
  async login(email: string, password: string): Promise<{ user: User; token: string }> {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Authentication failed');
    setStoredAuth(data.data.token, data.data.user);
    return data.data;
  },

  async getCurrentUser(): Promise<User | null> {
    const token = getStoredToken();
    if (!token) return null;
    const res = await fetch('/api/auth/me', {
      headers: getHeaders()
    });
    if (!res.ok) {
      clearStoredAuth();
      return null;
    }
    const data = await res.json();
    return data.data;
  },

  // Reservations
  async createReservation(request: BookingRequest): Promise<{ reservation: Reservation; isIdempotentReplay: boolean; payment?: PaymentRecord }> {
    const headers = getHeaders({
      'Idempotency-Key': request.idempotencyKey
    });
    const res = await fetch('/api/reservations', {
      method: 'POST',
      headers,
      body: JSON.stringify(request)
    });
    const data = await res.json();
    if (!res.ok) {
      const err = new Error(data.error || 'Failed to complete reservation');
      (err as any).code = data.code;
      (err as any).reservation = data.reservation;
      throw err;
    }
    return {
      reservation: data.data,
      isIdempotentReplay: data.isIdempotentReplay || false,
      payment: data.payment
    };
  },

  async getReservations(userId?: string): Promise<Reservation[]> {
    const url = userId ? `/api/reservations?userId=${userId}` : '/api/reservations';
    const res = await fetch(url, { headers: getHeaders() });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to fetch reservations');
    return data.data;
  },

  async getReservationById(id: string): Promise<Reservation & { payments: PaymentRecord[] }> {
    const res = await fetch(`/api/reservations/${id}`, { headers: getHeaders() });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Reservation not found');
    return data.data;
  },

  async getRefundPreview(id: string): Promise<RefundPreview> {
    const res = await fetch(`/api/reservations/${id}/refund-preview`, { headers: getHeaders() });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to calculate refund preview');
    return data.data;
  },

  async cancelReservation(id: string, reason?: string): Promise<{ reservation: Reservation; refund: RefundPreview }> {
    const res = await fetch(`/api/reservations/${id}/cancel`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ reason })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to cancel reservation');
    return { reservation: data.data, refund: data.refund };
  },

  // Persona Recommendations
  async getRecommendations(persona: string = 'COUPLE'): Promise<PersonaRecommendation[]> {
    const res = await fetch(`/api/recommendations?persona=${persona}`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to fetch recommendations');
    return data.data;
  },

  // AI Smart Stay Planner
  async generateStayPlan(params: {
    destination?: string;
    purpose: string;
    budgetMax: number;
    partySize: number;
    desiredVibe: string;
  }): Promise<StayPlannerPlan> {
    const res = await fetch('/api/planner/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to generate stay plan');
    return data.data;
  },

  // Admin APIs
  async getAdminAnalytics(): Promise<AdminAnalytics> {
    const res = await fetch('/api/admin/analytics', { headers: getHeaders() });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to load admin analytics');
    return data.data;
  },

  async updateRoomBasePrice(roomTypeId: string, newBasePrice: number): Promise<RoomType> {
    const res = await fetch(`/api/admin/tariffs/room-type/${roomTypeId}`, {
      method: 'PUT',
      headers: getHeaders(),
      body: JSON.stringify({ newBasePrice })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to update tariff');
    return data.data;
  },

  async updateTierTariffs(tier: string, multiplier: number): Promise<{ updatedCount: number }> {
    const res = await fetch('/api/admin/tariffs/tier', {
      method: 'PUT',
      headers: getHeaders(),
      body: JSON.stringify({ tier, multiplier })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to update tier tariffs');
    return data.data;
  },

  // Automated 10-Point Test Runner
  async runTestSuite(): Promise<TestSuiteSummary> {
    const res = await fetch('/api/test-suite/run', {
      method: 'POST',
      headers: getHeaders()
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to execute test suite');
    return data.data;
  }
};

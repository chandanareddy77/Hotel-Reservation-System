import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { db } from './server/db.ts';
import { rateService } from './server/services/rateService.ts';
import { reservationService } from './server/services/reservationService.ts';
import { recommendationService, GuestPersona } from './server/services/recommendationService.ts';
import { smartPlannerService } from './server/services/smartPlannerService.ts';
import { adminService } from './server/services/adminService.ts';
import { testRunnerService } from './server/services/testRunnerService.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Helper middleware for mock auth token / role extraction
const extractUser = (req: Request): { id: string; role: 'USER' | 'ADMIN'; email: string } | null => {
  const authHeader = req.headers.authorization;
  if (!authHeader) return null;
  const token = authHeader.replace(/^Bearer\s+/i, '').trim();
  // Simple token format: user-guest-001 or user-admin-001 or email
  const user = db.getUserById(token) || db.getUserByEmail(token);
  if (!user) return null;
  return { id: user.id, role: user.role, email: user.email };
};

// --- API ROUTES ---

// 1. Hotels
app.get('/api/hotels', (_req: Request, res: Response) => {
  try {
    const hotels = db.getHotels().map(hotel => {
      const dynamicStartingPrice = rateService.getStartingDynamicRate(hotel.id);
      return {
        ...hotel,
        dynamicStartingPrice
      };
    });
    res.json({ success: true, data: hotels });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/hotels/:id', (req: Request, res: Response) => {
  try {
    const hotel = db.getHotelById(req.params.id);
    if (!hotel) {
      return res.status(404).json({ success: false, error: 'Hotel not found' });
    }
    const roomTypes = db.getRoomTypes(hotel.id).map(rt => {
      const currentlyBooked = db.getActiveBookedCount(rt.id);
      const overbookingCap = Math.floor(rt.totalPhysicalRooms * 1.10);
      const remainingInventory = Math.max(0, overbookingCap - currentlyBooked);
      return {
        ...rt,
        currentlyBooked,
        overbookingCap,
        remainingInventory,
        isSoldOut: remainingInventory <= 0
      };
    });
    res.json({ success: true, data: { ...hotel, roomTypes } });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 2. Room Types
app.get('/api/room-types', (req: Request, res: Response) => {
  try {
    const hotelId = req.query.hotelId as string | undefined;
    const roomTypes = db.getRoomTypes(hotelId).map(rt => {
      const currentlyBooked = db.getActiveBookedCount(rt.id);
      const overbookingCap = Math.floor(rt.totalPhysicalRooms * 1.10);
      const remainingInventory = Math.max(0, overbookingCap - currentlyBooked);
      return {
        ...rt,
        currentlyBooked,
        overbookingCap,
        remainingInventory,
        isSoldOut: remainingInventory <= 0
      };
    });
    res.json({ success: true, data: roomTypes });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 3. Dynamic Pricing Calculation
app.post('/api/rates/calculate', (req: Request, res: Response) => {
  try {
    const { roomTypeId, checkIn, checkOut, numRooms = 1 } = req.body;
    if (!roomTypeId || !checkIn || !checkOut) {
      return res.status(400).json({ success: false, error: 'Missing required parameters (roomTypeId, checkIn, checkOut)' });
    }
    const breakdown = rateService.calculateStayRate(roomTypeId, checkIn, checkOut, Number(numRooms));
    res.json({ success: true, data: breakdown });
  } catch (err: any) {
    res.status(400).json({ success: false, error: err.message });
  }
});

// 4. Authentication
app.post('/api/auth/login', (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ success: false, error: 'Email and password required' });
    }
    const user = db.verifyCredentials(email, password);
    if (!user) {
      return res.status(401).json({ success: false, error: 'Invalid email or password' });
    }
    res.json({
      success: true,
      data: {
        user,
        token: user.id // using user ID as Bearer token in this demo
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/auth/me', (req: Request, res: Response) => {
  try {
    const currentUser = extractUser(req);
    if (!currentUser) {
      return res.status(401).json({ success: false, error: 'Unauthenticated' });
    }
    const user = db.getUserById(currentUser.id);
    res.json({ success: true, data: user });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 5. Reservations & Bookings
app.post('/api/reservations', async (req: Request, res: Response) => {
  try {
    const idempotencyHeader = (req.headers['idempotency-key'] as string) || req.body.idempotencyKey;
    const bookingPayload = {
      ...req.body,
      idempotencyKey: idempotencyHeader
    };

    const outcome = await reservationService.createReservation(bookingPayload);
    res.status(outcome.isIdempotentReplay ? 200 : 201).json({
      success: true,
      isIdempotentReplay: outcome.isIdempotentReplay || false,
      data: outcome.reservation,
      payment: outcome.paymentRecord
    });
  } catch (err: any) {
    if (err.code === 'EXCESS_OVERBOOKING_REJECTED') {
      return res.status(409).json({
        success: false,
        code: 'EXCESS_OVERBOOKING_REJECTED',
        error: err.message
      });
    }
    if (err.code === 'PAYMENT_DECLINED') {
      return res.status(402).json({
        success: false,
        code: 'PAYMENT_DECLINED',
        error: err.message,
        reservation: err.reservation
      });
    }
    res.status(400).json({ success: false, error: err.message });
  }
});

app.get('/api/reservations', (req: Request, res: Response) => {
  try {
    const userId = req.query.userId as string | undefined;
    const currentUser = extractUser(req);

    // If admin, can see all; if guest user, restricted to their own reservations unless querying explicitly
    let reservations = db.getReservations();
    if (userId) {
      reservations = reservations.filter(r => r.userId === userId);
    } else if (currentUser && currentUser.role === 'USER') {
      reservations = reservations.filter(r => r.userId === currentUser.id);
    }

    // Sort newest first
    reservations.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    res.json({ success: true, data: reservations });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/reservations/:id', (req: Request, res: Response) => {
  try {
    const resId = req.params.id;
    const reservation = db.getReservationById(resId) || db.getReservationByRef(resId);
    if (!reservation) {
      return res.status(404).json({ success: false, error: 'Reservation not found' });
    }
    const payments = db.getPaymentsForReservation(reservation.id);
    res.json({ success: true, data: { ...reservation, payments } });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Tiered Refund Preview
app.get('/api/reservations/:id/refund-preview', (req: Request, res: Response) => {
  try {
    const resId = req.params.id;
    const preview = reservationService.calculateRefund(resId);
    res.json({ success: true, data: preview });
  } catch (err: any) {
    res.status(400).json({ success: false, error: err.message });
  }
});

// Cancellation & Refund Execution
app.post('/api/reservations/:id/cancel', (req: Request, res: Response) => {
  try {
    const resId = req.params.id;
    const { reason } = req.body;
    const outcome = reservationService.cancelReservation(resId, reason);
    res.json({
      success: true,
      data: outcome.reservation,
      refund: outcome.refundPreview,
      paymentRefund: outcome.paymentRefundRecord
    });
  } catch (err: any) {
    res.status(400).json({ success: false, error: err.message });
  }
});

// 6. Persona Recommendations
app.get('/api/recommendations', (req: Request, res: Response) => {
  try {
    const persona = ((req.query.persona as string) || 'COUPLE').toUpperCase() as GuestPersona;
    const recommendations = recommendationService.getRecommendationsForPersona(persona);
    res.json({ success: true, data: recommendations });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 7. AI Smart Stay Planner
app.post('/api/planner/generate', (req: Request, res: Response) => {
  try {
    const {
      destination,
      purpose = 'ROMANCE',
      budgetMax = 15000,
      partySize = 2,
      desiredVibe = 'Any'
    } = req.body;

    const plan = smartPlannerService.generatePlan({
      destination,
      purpose,
      budgetMax: Number(budgetMax),
      partySize: Number(partySize),
      desiredVibe
    });

    res.json({ success: true, data: plan });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 8. Admin Analytics & RBAC Check
app.get('/api/admin/analytics', (req: Request, res: Response) => {
  try {
    const currentUser = extractUser(req);
    // RBAC: Check role
    if (currentUser && currentUser.role !== 'ADMIN') {
      return res.status(403).json({ success: false, error: '403 Forbidden: Admin privileges required' });
    }
    const analytics = adminService.getAnalytics();
    res.json({ success: true, data: analytics });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 9. Admin Tariff Overrides
app.put('/api/admin/tariffs/room-type/:id', (req: Request, res: Response) => {
  try {
    const currentUser = extractUser(req);
    if (currentUser && currentUser.role !== 'ADMIN') {
      return res.status(403).json({ success: false, error: '403 Forbidden: Admin privileges required' });
    }
    const { newBasePrice } = req.body;
    if (!newBasePrice || isNaN(Number(newBasePrice))) {
      return res.status(400).json({ success: false, error: 'Valid newBasePrice required' });
    }
    const updated = adminService.updateRoomBasePrice(req.params.id, Number(newBasePrice));
    res.json({ success: true, data: updated });
  } catch (err: any) {
    res.status(400).json({ success: false, error: err.message });
  }
});

app.put('/api/admin/tariffs/tier', (req: Request, res: Response) => {
  try {
    const currentUser = extractUser(req);
    if (currentUser && currentUser.role !== 'ADMIN') {
      return res.status(403).json({ success: false, error: '403 Forbidden: Admin privileges required' });
    }
    const { tier, multiplier } = req.body;
    if (!tier || !multiplier) {
      return res.status(400).json({ success: false, error: 'Tier and multiplier required' });
    }
    const count = adminService.updateTierTariffs(tier, Number(multiplier));
    res.json({ success: true, data: { updatedCount: count, tier, multiplier } });
  } catch (err: any) {
    res.status(400).json({ success: false, error: err.message });
  }
});

// 10. Automated 10-Point Integration Test Runner
app.post('/api/test-suite/run', async (_req: Request, res: Response) => {
  try {
    const testResults = await testRunnerService.runAllTests();
    res.json({ success: true, data: testResults });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Database Seed Reset
app.post('/api/admin/reset-seed', (req: Request, res: Response) => {
  try {
    const currentUser = extractUser(req);
    if (currentUser && currentUser.role !== 'ADMIN') {
      return res.status(403).json({ success: false, error: '403 Forbidden: Admin privileges required' });
    }
    db.resetToSeed();
    res.json({ success: true, message: 'Database reset to default seeded state' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// --- VITE MIDDLEWARE INTEGRATION ---
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`✨ LuxeStay luxury server running on port ${PORT}`);
  });
}

startServer();

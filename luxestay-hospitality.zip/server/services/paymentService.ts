import { PaymentMethod, PaymentRecord } from '../../src/types/index.ts';

export interface ProcessPaymentParams {
  reservationId: string;
  amount: number;
  method: PaymentMethod;
  details: {
    simulateDecline?: boolean;
    cardNumber?: string;
    cardHolder?: string;
    cardExpiry?: string;
    cardCvv?: string;
    cardBrand?: string;
    upiId?: string;
    bankName?: string;
    walletProvider?: string;
    voucherCode?: string;
  };
}

export interface PaymentProcessingResult {
  success: boolean;
  transactionRef: string;
  failureReason?: string;
  adjustedAmount?: number;
  discountApplied?: number;
  method: PaymentMethod;
}

export class PaymentService {
  /**
   * Validate and process a payment attempt across 6 payment rails
   */
  public async processPayment(params: ProcessPaymentParams): Promise<PaymentProcessingResult> {
    const { amount, method, details } = params;

    // 1. Bank Decline Simulator
    if (details.simulateDecline) {
      return {
        success: false,
        transactionRef: `TXN_DECLINED_${Date.now()}_FAIL`,
        failureReason: 'BANK_GATEWAY_DECLINED: Issuer bank rejected authorization (Simulated decline scenario)',
        method
      };
    }

    // 2. Gift Vouchers / Club Rewards
    if (method === 'VOUCHER') {
      const code = (details.voucherCode || '').trim().toUpperCase();
      if (code === 'DIAMOND-STAY') {
        return {
          success: true,
          transactionRef: `VOUCHER_DIAMOND_${Date.now()}`,
          adjustedAmount: 0,
          discountApplied: amount,
          method: 'VOUCHER'
        };
      } else if (code === 'LUXE-GOLD-2026') {
        const discount = Math.min(10000, amount);
        const payable = Math.max(0, amount - 10000);
        return {
          success: true,
          transactionRef: `VOUCHER_GOLD10K_${Date.now()}`,
          adjustedAmount: payable,
          discountApplied: discount,
          method: 'VOUCHER'
        };
      } else {
        return {
          success: false,
          transactionRef: `VOUCHER_INVALID_${Date.now()}`,
          failureReason: `INVALID_VOUCHER_CODE: Code '${code}' is expired or invalid. Try 'LUXE-GOLD-2026' or 'DIAMOND-STAY'.`,
          method: 'VOUCHER'
        };
      }
    }

    // 3. Pay at Hotel (Zero advance payment, confirmed on arrival)
    if (method === 'PAY_AT_HOTEL') {
      return {
        success: true,
        transactionRef: `PAY_AT_DESK_${Date.now()}`,
        adjustedAmount: amount,
        discountApplied: 0,
        method: 'PAY_AT_HOTEL'
      };
    }

    // 4. Credit / Debit Cards
    if (method === 'CARD') {
      const cardNum = (details.cardNumber || '').replace(/\s+/g, '');
      if (cardNum.length < 12) {
        return {
          success: false,
          transactionRef: `TXN_CARD_ERR_${Date.now()}`,
          failureReason: 'CARD_VALIDATION_ERROR: Invalid 16-digit card number',
          method: 'CARD'
        };
      }
      const brand = details.cardBrand || 'VISA';
      return {
        success: true,
        transactionRef: `TXN_${brand.toUpperCase()}_${Date.now()}_AUTH_OK`,
        adjustedAmount: amount,
        method: 'CARD'
      };
    }

    // 5. UPI
    if (method === 'UPI') {
      const vpa = (details.upiId || '').trim();
      const ref = `UPI_REF_${Math.floor(100000 + Math.random() * 900000)}_${Date.now()}`;
      return {
        success: true,
        transactionRef: ref,
        adjustedAmount: amount,
        method: 'UPI'
      };
    }

    // 6. Net Banking
    if (method === 'NET_BANKING') {
      const bank = details.bankName || 'HDFC Bank';
      return {
        success: true,
        transactionRef: `NB_${bank.replace(/\s+/g, '').toUpperCase()}_${Date.now()}`,
        adjustedAmount: amount,
        method: 'NET_BANKING'
      };
    }

    // 7. Digital Wallets
    if (method === 'WALLET') {
      const wallet = details.walletProvider || 'Amazon Pay';
      return {
        success: true,
        transactionRef: `WALLET_${wallet.replace(/\s+/g, '').toUpperCase()}_${Date.now()}`,
        adjustedAmount: amount,
        method: 'WALLET'
      };
    }

    // Fallback
    return {
      success: true,
      transactionRef: `TXN_GATEWAY_${Date.now()}`,
      adjustedAmount: amount,
      method
    };
  }
}

export const paymentService = new PaymentService();

import { db } from '../db.ts';
import { reservationService } from './reservationService.ts';
import { recommendationService } from './recommendationService.ts';
import { TestResultItem, TestSuiteSummary } from '../../src/types/index.ts';

export class TestRunnerService {
  /**
   * Run the automated 10-point backend integration test suite in real time
   */
  public async runAllTests(): Promise<TestSuiteSummary> {
    const startTime = Date.now();
    const results: TestResultItem[] = [];

    // Test 1: User Login with Valid Credentials
    results.push(await this.testUserLogin());

    // Test 2: Admin Login with Role Authorization
    results.push(await this.testAdminLogin());

    // Test 3: Reject Invalid Credentials
    results.push(await this.testInvalidCredentials());

    // Test 4: Successful Room Type Reservation
    results.push(await this.testSuccessfulReservation());

    // Test 5: Duplicate Reservation Idempotency Protection
    results.push(await this.testIdempotencyProtection());

    // Test 6: 10% Overbooking Cap & Excess Inventory Rejection
    results.push(await this.testOverbookingCapRejection());

    // Test 7: Payment Simulation (Success Path)
    results.push(await this.testPaymentSuccessPath());

    // Test 8: Simulated Payment Failure & Inventory Safe Release
    results.push(await this.testPaymentDeclineInventoryRollback());

    // Test 9: Tiered Refund Calculation (>48h = 100% Refund)
    results.push(await this.testTieredRefundEngine());

    // Test 10: Multi-factor Recommendation Scoring
    results.push(await this.testRecommendationScoring());

    const totalTests = results.length;
    const passedTests = results.filter(r => r.status === 'PASSED').length;
    const failedTests = totalTests - passedTests;
    const executionTimeMs = Date.now() - startTime;

    return {
      totalTests,
      passedTests,
      failedTests,
      executionTimeMs,
      timestamp: new Date().toISOString(),
      results
    };
  }

  // 1. User Login
  private async testUserLogin(): Promise<TestResultItem> {
    const t0 = Date.now();
    try {
      const user = db.verifyCredentials('user@luxestay.com', 'user123');
      if (!user) throw new Error('Guest credentials rejected');
      if (user.role !== 'USER') throw new Error(`Expected role USER, got ${user.role}`);
      if (user.name !== 'Aarav Sharma') throw new Error(`Expected Aarav Sharma, got ${user.name}`);

      return {
        id: 1,
        name: 'User Login with Valid Credentials',
        category: 'AUTH',
        status: 'PASSED',
        durationMs: Date.now() - t0,
        details: 'Verified guest account authentication (user@luxestay.com), session claims, and role USER.',
        diagnostics: { email: user.email, role: user.role, name: user.name }
      };
    } catch (err: any) {
      return {
        id: 1,
        name: 'User Login with Valid Credentials',
        category: 'AUTH',
        status: 'FAILED',
        durationMs: Date.now() - t0,
        details: err.message
      };
    }
  }

  // 2. Admin Login
  private async testAdminLogin(): Promise<TestResultItem> {
    const t0 = Date.now();
    try {
      const admin = db.verifyCredentials('admin@luxestay.com', 'admin123');
      if (!admin) throw new Error('Admin credentials rejected');
      if (admin.role !== 'ADMIN') throw new Error(`Expected role ADMIN, got ${admin.role}`);

      return {
        id: 2,
        name: 'Admin Login with Role Authorization',
        category: 'AUTH',
        status: 'PASSED',
        durationMs: Date.now() - t0,
        details: 'Verified administrator account authentication (admin@luxestay.com) with role ADMIN permissions.',
        diagnostics: { email: admin.email, role: admin.role, name: admin.name }
      };
    } catch (err: any) {
      return {
        id: 2,
        name: 'Admin Login with Role Authorization',
        category: 'AUTH',
        status: 'FAILED',
        durationMs: Date.now() - t0,
        details: err.message
      };
    }
  }

  // 3. Reject Invalid Credentials
  private async testInvalidCredentials(): Promise<TestResultItem> {
    const t0 = Date.now();
    try {
      const user = db.verifyCredentials('user@luxestay.com', 'wrongpassword_999');
      if (user !== null) throw new Error('Invalid password was erroneously accepted');

      const nonExistent = db.verifyCredentials('unknown_guest_fake@test.com', 'password');
      if (nonExistent !== null) throw new Error('Non-existent user was erroneously accepted');

      return {
        id: 3,
        name: 'Reject Invalid Credentials',
        category: 'AUTH',
        status: 'PASSED',
        durationMs: Date.now() - t0,
        details: 'Rejected unauthorized access attempts with invalid password and nonexistent email.',
        diagnostics: { rejectionVerified: true }
      };
    } catch (err: any) {
      return {
        id: 3,
        name: 'Reject Invalid Credentials',
        category: 'AUTH',
        status: 'FAILED',
        durationMs: Date.now() - t0,
        details: err.message
      };
    }
  }

  // 4. Successful Room Type Reservation
  private async testSuccessfulReservation(): Promise<TestResultItem> {
    const t0 = Date.now();
    try {
      const idemp = `test-idemp-res-${Date.now()}`;
      const outcome = await reservationService.createReservation({
        idempotencyKey: idemp,
        hotelId: 'hotel-hyd-heritage',
        roomTypeId: 'rt-hyd-h-std',
        checkIn: '2026-12-01',
        checkOut: '2026-12-03',
        numRooms: 1,
        guestsCount: 2,
        guestName: 'Ananya Roy',
        guestEmail: 'ananya.roy@example.com',
        guestPhone: '+91 99887 76655',
        paymentMethod: 'UPI',
        paymentDetails: { upiId: 'ananya@okhdfcbank' }
      });

      if (!outcome.reservation) throw new Error('No reservation record created');
      if (outcome.reservation.status !== 'CONFIRMED') {
        throw new Error(`Expected status CONFIRMED, got ${outcome.reservation.status}`);
      }
      if (!outcome.reservation.bookingRef.startsWith('LX-')) {
        throw new Error(`Invalid booking reference format: ${outcome.reservation.bookingRef}`);
      }

      return {
        id: 4,
        name: 'Successful Room Type Reservation',
        category: 'BOOKING',
        status: 'PASSED',
        durationMs: Date.now() - t0,
        details: `Confirmed reservation ${outcome.reservation.bookingRef} with dynamic rate calculation and UPI gateway authorization.`,
        diagnostics: {
          bookingRef: outcome.reservation.bookingRef,
          totalAmount: outcome.reservation.totalAmount,
          status: outcome.reservation.status
        }
      };
    } catch (err: any) {
      return {
        id: 4,
        name: 'Successful Room Type Reservation',
        category: 'BOOKING',
        status: 'FAILED',
        durationMs: Date.now() - t0,
        details: err.message
      };
    }
  }

  // 5. Duplicate Reservation Idempotency Protection
  private async testIdempotencyProtection(): Promise<TestResultItem> {
    const t0 = Date.now();
    try {
      const idempKey = `test-idemp-dedup-${Date.now()}`;
      const bookingData = {
        idempotencyKey: idempKey,
        hotelId: 'hotel-mum-marine',
        roomTypeId: 'rt-mum-m-std',
        checkIn: '2026-12-10',
        checkOut: '2026-12-12',
        numRooms: 1,
        guestsCount: 2,
        guestName: 'Rohan Mehra',
        guestEmail: 'rohan@example.com',
        guestPhone: '+91 98765 43210',
        paymentMethod: 'CARD' as const,
        paymentDetails: { cardNumber: '4111222233334444', cardBrand: 'VISA' }
      };

      // Call 1
      const res1 = await reservationService.createReservation(bookingData);
      const bookedCount1 = db.getActiveBookedCount('rt-mum-m-std');

      // Call 2 with identical Idempotency-Key
      const res2 = await reservationService.createReservation(bookingData);
      const bookedCount2 = db.getActiveBookedCount('rt-mum-m-std');

      if (res1.reservation.id !== res2.reservation.id) {
        throw new Error(`Idempotency failed: Created different reservation ID (${res1.reservation.id} vs ${res2.reservation.id})`);
      }
      if (res2.isIdempotentReplay !== true) {
        throw new Error('isIdempotentReplay flag was not set to true');
      }
      if (bookedCount1 !== bookedCount2) {
        throw new Error(`Inventory double-counted! Before: ${bookedCount1}, After: ${bookedCount2}`);
      }

      return {
        id: 5,
        name: 'Duplicate Reservation Idempotency Protection',
        category: 'BOOKING',
        status: 'PASSED',
        durationMs: Date.now() - t0,
        details: `Verified identical idempotency key '${idempKey}' intercepted duplicate charge; returned existing ${res1.reservation.bookingRef} with 0 inventory drift.`,
        diagnostics: {
          idempotencyKey: idempKey,
          returnedReservationId: res2.reservation.id,
          inventoryPreserved: true
        }
      };
    } catch (err: any) {
      return {
        id: 5,
        name: 'Duplicate Reservation Idempotency Protection',
        category: 'BOOKING',
        status: 'FAILED',
        durationMs: Date.now() - t0,
        details: err.message
      };
    }
  }

  // 6. 10% Overbooking Cap & Excess Inventory Rejection
  private async testOverbookingCapRejection(): Promise<TestResultItem> {
    const t0 = Date.now();
    try {
      // Pick Presidential suite (total physical = 2)
      // 10% buffer = Math.floor(2 * 1.10) = 2 rooms max allowed
      const roomType = db.getRoomTypeById('rt-mum-m-pres')!;
      const totalPhysical = roomType.totalPhysicalRooms;
      const overbookingCap = Math.floor(totalPhysical * 1.10);

      let rejectedAsExpected = false;
      try {
        await reservationService.createReservation({
          idempotencyKey: `test-overbook-breach-${Date.now()}`,
          hotelId: roomType.hotelId,
          roomTypeId: roomType.id,
          checkIn: '2026-12-15',
          checkOut: '2026-12-17',
          numRooms: overbookingCap + 1, // Exceeds cap
          guestsCount: 4,
          guestName: 'Overbooking Test',
          guestEmail: 'overbook@test.com',
          guestPhone: '+91 99999 00000',
          paymentMethod: 'PAY_AT_HOTEL',
          paymentDetails: {}
        });
      } catch (err: any) {
        if (err.code === 'EXCESS_OVERBOOKING_REJECTED') {
          rejectedAsExpected = true;
        } else {
          throw err;
        }
      }

      if (!rejectedAsExpected) {
        throw new Error('Expected reservation exceeding 110% overbooking cap to be strictly rejected');
      }

      return {
        id: 6,
        name: '10% Overbooking Cap & Excess Inventory Rejection',
        category: 'OVERBOOKING',
        status: 'PASSED',
        durationMs: Date.now() - t0,
        details: `Successfully enforced 10% overbooking buffer cap (${overbookingCap} rooms maximum). Excessive reservation rejected with EXCESS_OVERBOOKING_REJECTED.`,
        diagnostics: {
          physicalRooms: totalPhysical,
          overbookingCap,
          rejectedExcessCount: overbookingCap + 1
        }
      };
    } catch (err: any) {
      return {
        id: 6,
        name: '10% Overbooking Cap & Excess Inventory Rejection',
        category: 'OVERBOOKING',
        status: 'FAILED',
        durationMs: Date.now() - t0,
        details: err.message
      };
    }
  }

  // 7. Payment Simulation (Success Path)
  private async testPaymentSuccessPath(): Promise<TestResultItem> {
    const t0 = Date.now();
    try {
      const outcome = await reservationService.createReservation({
        idempotencyKey: `test-pay-ok-${Date.now()}`,
        hotelId: 'hotel-hyd-tech',
        roomTypeId: 'rt-hyd-t-dlx',
        checkIn: '2026-12-20',
        checkOut: '2026-12-22',
        numRooms: 1,
        guestsCount: 2,
        guestName: 'Deepak Verma',
        guestEmail: 'deepak@verma.com',
        guestPhone: '+91 98111 22334',
        paymentMethod: 'CARD',
        paymentDetails: {
          cardNumber: '378282246310005',
          cardBrand: 'AMEX',
          cardHolder: 'DEEPAK VERMA',
          simulateDecline: false
        }
      });

      if (!outcome.paymentRecord) throw new Error('No payment record created');
      if (outcome.paymentRecord.status !== 'SUCCESS') {
        throw new Error(`Expected payment status SUCCESS, got ${outcome.paymentRecord.status}`);
      }
      if (!outcome.paymentRecord.transactionRef.includes('AMEX')) {
        throw new Error(`Unexpected transaction ref format: ${outcome.paymentRecord.transactionRef}`);
      }

      return {
        id: 7,
        name: 'Payment Simulation (Success Path)',
        category: 'PAYMENT',
        status: 'PASSED',
        durationMs: Date.now() - t0,
        details: `Successfully simulated multi-rail payment authorization with transaction ref ${outcome.paymentRecord.transactionRef}.`,
        diagnostics: {
          transactionRef: outcome.paymentRecord.transactionRef,
          amount: outcome.paymentRecord.amount,
          method: outcome.paymentRecord.method
        }
      };
    } catch (err: any) {
      return {
        id: 7,
        name: 'Payment Simulation (Success Path)',
        category: 'PAYMENT',
        status: 'FAILED',
        durationMs: Date.now() - t0,
        details: err.message
      };
    }
  }

  // 8. Simulated Payment Failure & Inventory Safe Release
  private async testPaymentDeclineInventoryRollback(): Promise<TestResultItem> {
    const t0 = Date.now();
    try {
      const roomTypeId = 'rt-goa-b-jste';
      const initialBookedCount = db.getActiveBookedCount(roomTypeId);

      let declineCaught = false;
      let reservationIdFailed = '';

      try {
        await reservationService.createReservation({
          idempotencyKey: `test-decline-flow-${Date.now()}`,
          hotelId: 'hotel-goa-beach',
          roomTypeId,
          checkIn: '2026-12-25',
          checkOut: '2026-12-27',
          numRooms: 1,
          guestsCount: 2,
          guestName: 'Decline Test User',
          guestEmail: 'decline@test.com',
          guestPhone: '+91 98888 77777',
          paymentMethod: 'CARD',
          paymentDetails: {
            cardNumber: '4111222233334444',
            simulateDecline: true // Triggers simulator
          }
        });
      } catch (err: any) {
        if (err.code === 'PAYMENT_DECLINED') {
          declineCaught = true;
          reservationIdFailed = err.reservation?.id;
        } else {
          throw err;
        }
      }

      if (!declineCaught) {
        throw new Error('Bank decline simulation did not trigger expected PAYMENT_DECLINED');
      }

      // Verify status is PAYMENT_FAILED
      const failedRes = db.getReservationById(reservationIdFailed);
      if (!failedRes || failedRes.status !== 'PAYMENT_FAILED') {
        throw new Error(`Reservation status expected PAYMENT_FAILED, found ${failedRes?.status}`);
      }

      // Verify inventory was NOT consumed
      const postDeclineBookedCount = db.getActiveBookedCount(roomTypeId);
      if (postDeclineBookedCount !== initialBookedCount) {
        throw new Error(`Inventory leaked on decline! Initial: ${initialBookedCount}, Post: ${postDeclineBookedCount}`);
      }

      return {
        id: 8,
        name: 'Simulated Payment Failure & Inventory Safe Release',
        category: 'PAYMENT',
        status: 'PASSED',
        durationMs: Date.now() - t0,
        details: 'Verified BANK_GATEWAY_DECLINED simulation set reservation to PAYMENT_FAILED and safely rolled back held room inventory.',
        diagnostics: {
          declineReason: 'BANK_GATEWAY_DECLINED',
          reservationStatus: failedRes.status,
          inventoryPreservedCount: postDeclineBookedCount
        }
      };
    } catch (err: any) {
      return {
        id: 8,
        name: 'Simulated Payment Failure & Inventory Safe Release',
        category: 'PAYMENT',
        status: 'FAILED',
        durationMs: Date.now() - t0,
        details: err.message
      };
    }
  }

  // 9. Tiered Refund Calculation (>48h = 100% Refund)
  private async testTieredRefundEngine(): Promise<TestResultItem> {
    const t0 = Date.now();
    try {
      // Create a reservation for 10 days in the future (> 48h)
      const futureCheckIn = new Date(Date.now() + 10 * 86400000).toISOString().split('T')[0];
      const futureCheckOut = new Date(Date.now() + 12 * 86400000).toISOString().split('T')[0];

      const outcome = await reservationService.createReservation({
        idempotencyKey: `test-refund-calc-${Date.now()}`,
        hotelId: 'hotel-blr-botanical',
        roomTypeId: 'rt-blr-b-dlx',
        checkIn: futureCheckIn,
        checkOut: futureCheckOut,
        numRooms: 1,
        guestsCount: 2,
        guestName: 'Kavita Nair',
        guestEmail: 'kavita@example.com',
        guestPhone: '+91 97777 66666',
        paymentMethod: 'NET_BANKING',
        paymentDetails: { bankName: 'HDFC Bank' }
      });

      const resId = outcome.reservation.id;
      const refundPreview = reservationService.calculateRefund(resId);

      if (refundPreview.refundPercentage !== 100) {
        throw new Error(`Expected 100% refund for >48h advance check-in, got ${refundPreview.refundPercentage}%`);
      }
      if (refundPreview.refundAmount !== outcome.reservation.totalAmount) {
        throw new Error(`Refund amount mismatch: ${refundPreview.refundAmount} vs ${outcome.reservation.totalAmount}`);
      }

      // Execute cancellation
      const cancelOutcome = reservationService.cancelReservation(resId, 'Test cancellation');
      if (cancelOutcome.reservation.status !== 'CANCELLED') {
        throw new Error(`Expected reservation status CANCELLED, got ${cancelOutcome.reservation.status}`);
      }
      if (cancelOutcome.reservation.paymentStatus !== 'REFUNDED') {
        throw new Error(`Expected paymentStatus REFUNDED, got ${cancelOutcome.reservation.paymentStatus}`);
      }

      return {
        id: 9,
        name: 'Tiered Refund Calculation (>48h = 100% Refund)',
        category: 'REFUND',
        status: 'PASSED',
        durationMs: Date.now() - t0,
        details: `Calculated 100% refund (₹${refundPreview.refundAmount.toLocaleString('en-IN')}) for >48h advance cancellation; successfully recorded refund transaction.`,
        diagnostics: {
          hoursUntilCheckIn: refundPreview.hoursUntilCheckIn,
          refundPercentage: refundPreview.refundPercentage,
          refundAmount: refundPreview.refundAmount
        }
      };
    } catch (err: any) {
      return {
        id: 9,
        name: 'Tiered Refund Calculation (>48h = 100% Refund)',
        category: 'REFUND',
        status: 'FAILED',
        durationMs: Date.now() - t0,
        details: err.message
      };
    }
  }

  // 10. Multi-factor Recommendation Scoring
  private async testRecommendationScoring(): Promise<TestResultItem> {
    const t0 = Date.now();
    try {
      const coupleRecs = recommendationService.getRecommendationsForPersona('COUPLE');
      if (!coupleRecs || coupleRecs.length === 0) {
        throw new Error('No couple recommendations returned');
      }
      // Top couple recommendation should be Heritage or Beach with high score >= 95%
      const topCouple = coupleRecs[0];
      if (topCouple.matchScore < 95) {
        throw new Error(`Expected top couple match score >= 95%, got ${topCouple.matchScore}%`);
      }

      const businessRecs = recommendationService.getRecommendationsForPersona('BUSINESS');
      const topBusiness = businessRecs[0];
      if (topBusiness.hotel.id !== 'hotel-hyd-tech' && topBusiness.hotel.id !== 'hotel-del-aerocity') {
        throw new Error(`Expected tech or aerocity hotel for business persona, got ${topBusiness.hotel.name}`);
      }
      if (topBusiness.matchScore < 95) {
        throw new Error(`Expected top business match score >= 95%, got ${topBusiness.matchScore}%`);
      }

      return {
        id: 10,
        name: 'Multi-factor Recommendation Scoring',
        category: 'RECOMMENDATION',
        status: 'PASSED',
        durationMs: Date.now() - t0,
        details: `Persona algorithm correctly weighted Heritage (${topCouple.matchScore}%) for Couples and HITEC City (${topBusiness.matchScore}%) for Business Executives.`,
        diagnostics: {
          topCoupleMatch: `${topCouple.hotel.name} (${topCouple.matchScore}%)`,
          topBusinessMatch: `${topBusiness.hotel.name} (${topBusiness.matchScore}%)`
        }
      };
    } catch (err: any) {
      return {
        id: 10,
        name: 'Multi-factor Recommendation Scoring',
        category: 'RECOMMENDATION',
        status: 'FAILED',
        durationMs: Date.now() - t0,
        details: err.message
      };
    }
  }
}

export const testRunnerService = new TestRunnerService();

import { db } from '../db.ts';
import { Hotel, RoomType, StayPlannerPlan } from '../../src/types/index.ts';

export interface PlanTripParams {
  destination?: string; // Hyderabad, Mumbai, Goa, Bangalore, Delhi or 'Any'
  purpose: 'ROMANCE' | 'BUSINESS' | 'FAMILY' | 'WELLNESS' | 'LEISURE';
  budgetMax: number;
  partySize: number;
  desiredVibe: 'Heritage' | 'Modern' | 'Beach' | 'Wellness' | 'Any';
}

export class SmartPlannerService {
  /**
   * Generates a curated luxury stay itinerary and room matching plan
   */
  public generatePlan(params: PlanTripParams): StayPlannerPlan {
    const {
      destination,
      purpose,
      budgetMax,
      partySize,
      desiredVibe
    } = params;

    const hotels = db.getHotels();
    
    // Filter matching hotels
    let matchedHotels = hotels;
    if (destination && destination !== 'All Cities' && destination !== 'Any') {
      matchedHotels = matchedHotels.filter(h => h.city.toLowerCase() === destination.toLowerCase());
    }
    if (desiredVibe && desiredVibe !== 'Any') {
      const vibeMatches = matchedHotels.filter(h => h.vibe === desiredVibe);
      if (vibeMatches.length > 0) matchedHotels = vibeMatches;
    }

    if (matchedHotels.length === 0) {
      matchedHotels = hotels;
    }

    // Select the best hotel
    const selectedHotel = matchedHotels[0];
    const roomTypes = db.getRoomTypes(selectedHotel.id);

    // Pick room matching budget and party size
    let eligibleRooms = roomTypes.filter(r => r.capacityGuests >= partySize && r.basePrice <= budgetMax * 1.2);
    if (eligibleRooms.length === 0) {
      eligibleRooms = roomTypes.filter(r => r.capacityGuests >= partySize);
    }
    if (eligibleRooms.length === 0) {
      eligibleRooms = roomTypes;
    }

    // Pick premier room within budget
    const selectedRoom: RoomType = eligibleRooms.reduce((prev, curr) => {
      if (curr.basePrice <= budgetMax && curr.basePrice > prev.basePrice) return curr;
      return prev;
    }, eligibleRooms[0]);

    // Build curated itineraries based on city and purpose
    const itinerary = this.buildCuratedItinerary(selectedHotel, selectedRoom, purpose);

    return {
      destination: selectedHotel.city,
      purpose: purpose.charAt(0).toUpperCase() + purpose.slice(1).toLowerCase(),
      vibe: selectedHotel.vibe,
      recommendedHotel: selectedHotel,
      recommendedRoom: selectedRoom,
      priceEstimate: selectedRoom.basePrice,
      rationale: `Handpicked for your ${purpose.toLowerCase()} getaway in ${selectedHotel.city}. Combines ${selectedHotel.vibe.toLowerCase()} aesthetics with ${selectedRoom.name}’s bespoke amenities.`,
      days: itinerary
    };
  }

  private buildCuratedItinerary(hotel: Hotel, room: RoomType, purpose: string) {
    if (hotel.city === 'Hyderabad') {
      return [
        {
          dayNumber: 1,
          title: 'Royal Arrival & Nizami Heritage Soirée',
          morning: {
            time: '10:00 AM',
            title: 'Chauffeured Arrival & Jasmine Welcome',
            desc: 'Check into your suite with personalized butler unpacking and refreshing chilled vetiver water.'
          },
          afternoon: {
            time: '02:30 PM',
            title: 'Private Curated Walk through Chowmahalla Palace',
            desc: 'Private historian-guided exploration of the Nizam council chambers and vintage royal carriages.'
          },
          evening: {
            time: '07:30 PM',
            title: 'Candlelight Dum Pukht Feast',
            desc: 'Private courtyard table enjoying authentic slow-cooked Hyderabadi Biryani under Belgian chandeliers.'
          },
          diningHighlight: {
            name: 'Adaa Royal Dining Room',
            cuisine: 'Slow-Cooked Nizami Gastronomy',
            note: 'Signature Kacche Gosht ki Biryani paired with vintage cellar selections.'
          }
        },
        {
          dayNumber: 2,
          title: 'Pearls, Perfumes & Twilight Courtyard Ghazals',
          morning: {
            time: '08:30 AM',
            title: 'Royal High Tea Breakfast on Verandah',
            desc: 'Freshly baked Osmania biscuits, artisanal Irani chai, and tropical fruit spreads overlooking the hills.'
          },
          afternoon: {
            time: '03:00 PM',
            title: 'Exclusive Pearl Atelier & Ittar Scent Blending',
            desc: 'Bespoke pearl evaluation with master jewelers in Laad Bazaar followed by personal perfume formulation.'
          },
          evening: {
            time: '08:00 PM',
            title: 'Private Sufi Ghazal Performance',
            desc: 'Live sitar and ghazals beside the marble fountains with handcrafted saffron mocktails and artisanal kebabs.'
          },
          diningHighlight: {
            name: 'The Falak Lounge',
            cuisine: 'Contemporary Deccani Grills',
            note: 'Pathar ka Gosht seared on granite slabs with wild mint relish.'
          }
        }
      ];
    } else if (hotel.city === 'Goa') {
      return [
        {
          dayNumber: 1,
          title: 'Coastal Arrival & Vagator Sunset Sundowner',
          morning: {
            time: '11:00 AM',
            title: 'Barefoot Villa Check-In & Coconut Welcome',
            desc: 'Settle into your plunge pool cottage with fresh King coconut water and coastal breeze.'
          },
          afternoon: {
            time: '03:00 PM',
            title: 'Restorative Coastal Ayurvedic Massage',
            desc: '60-minute warm herbal oil Abhyanga massage to unwind travel tension.'
          },
          evening: {
            time: '06:00 PM',
            title: 'Sunset Clifftop Cocktails & Fresh Catch',
            desc: 'Red laterite cliff seating overlooking Vagator waves with grilled kingfish and feni infusions.'
          },
          diningHighlight: {
            name: 'The Palm Verandah',
            cuisine: 'Artisanal Goan-Portuguese',
            note: 'Tiger prawns in recheado butter and coconut wood-fired poee.'
          }
        },
        {
          dayNumber: 2,
          title: 'Catamaran Sailing & Beachfront Candlelight',
          morning: {
            time: '07:30 AM',
            title: 'Sunrise Prana Yoga on Deck',
            desc: 'Gentle ocean-facing yoga and breathwork followed by cold-pressed tropical juices.'
          },
          afternoon: {
            time: '02:00 PM',
            title: 'Private Catamaran Sail past Chapora Fort',
            desc: 'Private 3-hour cruise along the northern coast with dolphin spotting and chilled sparkling wine.'
          },
          evening: {
            time: '08:00 PM',
            title: 'Private Shoreline Candlelight Table',
            desc: 'Toes-in-the-sand four-course private dining lit by flaming torches.'
          },
          diningHighlight: {
            name: 'Susegad Shore Grill',
            cuisine: 'Oceanfront Live Seafood Bar',
            note: 'Lobster thermidor infused with local spices and coastal greens.'
          }
        }
      ];
    } else if (hotel.city === 'Mumbai') {
      return [
        {
          dayNumber: 1,
          title: 'Marine Drive Majesty & Sunset Sailing',
          morning: {
            time: '11:00 AM',
            title: 'Suite Check-In with Arabian Sea Horizons',
            desc: 'Unpack in your sea-facing sanctuary with welcome champagne and Mumbai tea truffles.'
          },
          afternoon: {
            time: '03:30 PM',
            title: 'Kala Ghoda Art & Heritage Quarter Walk',
            desc: 'Boutique contemporary galleries and colonial architecture exploration with an architectural historian.'
          },
          evening: {
            time: '06:30 PM',
            title: 'Sunset Cocktails on the Queen’s Necklace',
            desc: 'Panoramic terrace seating observing the glittering arc of streetlights illuminating the promenade.'
          },
          diningHighlight: {
            name: 'Bayfront Seafood Atelier',
            cuisine: 'Modern Coastal Indian',
            note: 'Crab claws in curry leaf brown butter with flaky Malabar parottas.'
          }
        },
        {
          dayNumber: 2,
          title: 'Private Yacht Charter & Michelin Gastronomy',
          morning: {
            time: '09:00 AM',
            title: 'Gourmet Sea Terrace Breakfast',
            desc: 'French viennoiseries, poached organic eggs, and single-estate Nilgiri white teas.'
          },
          afternoon: {
            time: '02:00 PM',
            title: 'Private Yacht Cruise from Gateway of India',
            desc: 'Exclusive twin-engine yacht sailing across Mumbai harbor past historic lighthouses.'
          },
          evening: {
            time: '08:30 PM',
            title: 'Chef’s Tasting Menu with Wine Pairing',
            desc: 'Seven-course gastronomic journey curated by our executive sommelier.'
          },
          diningHighlight: {
            name: 'The Art Deco Room',
            cuisine: 'Progressive European & Indian',
            note: 'Truffle-infused dal makhani with artisanal brioche and paired vintage champagne.'
          }
        }
      ];
    } else {
      // General Luxury Itinerary for Bangalore, Delhi, etc.
      return [
        {
          dayNumber: 1,
          title: 'Sanctuary Arrival & Wellness Unwind',
          morning: {
            time: '10:30 AM',
            title: 'Express Check-In & Botanical Welcome',
            desc: 'Personalized herbal refreshment and express in-room check-in with aromatherapy curation.'
          },
          afternoon: {
            time: '02:30 PM',
            title: 'Curated Heritage & Cultural Tour',
            desc: 'Bespoke chauffeur-driven visit to local architectural monuments and private art collections.'
          },
          evening: {
            time: '07:30 PM',
            title: 'Signature Executive Chef Dinner',
            desc: 'Multi-course culinary showcase featuring locally sourced organic botanicals and vintage wines.'
          },
          diningHighlight: {
            name: 'The Grand Pavilion',
            cuisine: 'Contemporary Indian Fine Dining',
            note: 'Saffron smoked lamb shank and artisanal sourdough naan.'
          }
        },
        {
          dayNumber: 2,
          title: 'Restorative Spa & Evening Jazz',
          morning: {
            time: '08:30 AM',
            title: 'Organic Canopy Breakfast',
            desc: 'Wholesome superfood bowls, artisanal filter roasts, and fresh cold-pressed tonics.'
          },
          afternoon: {
            time: '03:00 PM',
            title: 'Hydrotherapy & Deep Tissue Recovery',
            desc: 'Exclusive salt-water pool relaxation followed by 90-minute restorative body therapy.'
          },
          evening: {
            time: '08:00 PM',
            title: 'Speakeasy Jazz & Small Plates',
            desc: 'Intimate live saxophone session with rare single-malt whiskeys and tapas.'
          },
          diningHighlight: {
            name: 'The Glass Conservatory',
            cuisine: 'Botanical Farm-to-Table',
            note: 'Burrata with wild fig reduction and heirloom tomatoes.'
          }
        }
      ];
    }
  }
}

export const smartPlannerService = new SmartPlannerService();

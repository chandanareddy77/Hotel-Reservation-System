import { db } from '../db.ts';
import { rateService } from './rateService.ts';
import { paymentService } from './paymentService.ts';
import {
  BookingRequest,
  Reservation,
  PaymentRecord,
  RefundPreview
} from '../../src/types/index.ts';

export class ReservationService {
  /**
   * Process a room reservation with:
   * 1. Idempotency protection
   * 2. 10% overbooking cap verification
   * 3. Dynamic pricing computation
   * 4. 6-rail payment execution with decline simulation
   * 5. Inventory reservation / rollback
   */
  public async createReservation(request: BookingRequest): Promise<{
    reservation: Reservation;
    isIdempotentReplay?: boolean;
    paymentRecord?: PaymentRecord;
  }> {
    // 1. Idempotency Check
    if (request.idempotencyKey) {
      const existing = db.getReservationByIdempotencyKey(request.idempotencyKey);
      if (existing) {
        // Return existing confirmed/pending reservation without double charging or reducing inventory
        return {
          reservation: existing,
          isIdempotentReplay: true
        };
      }
    }

    const {
      hotelId,
      roomTypeId,
      checkIn,
      checkOut,
      numRooms = 1,
      guestsCount = 2,
      guestName,
      guestEmail,
      guestPhone,
      paymentMethod,
      paymentDetails,
      userId = 'user-guest-001'
    } = request;

    const hotel = db.getHotelById(hotelId);
    if (!hotel) {
      throw new Error(`Hotel not found: ${hotelId}`);
    }

    const roomType = db.getRoomTypeById(roomTypeId);
    if (!roomType) {
      throw new Error(`Room type not found: ${roomTypeId}`);
    }

    // 2. Smart Overbooking Management (10% Buffer)
    // Max allowed bookings = Math.floor(total_physical_rooms * 1.10)
    const totalPhysical = roomType.totalPhysicalRooms;
    const overbookingCap = Math.floor(totalPhysical * 1.10);
    const currentlyBooked = db.getActiveBookedCount(roomTypeId);

    if (currentlyBooked + numRooms > overbookingCap) {
      const err = new Error(
        `EXCESS_OVERBOOKING_REJECTED: Booking exceeds the 10% safety overbooking limit (${overbookingCap} rooms max, ${currentlyBooked} currently reserved).`
      );
      (err as any).code = 'EXCESS_OVERBOOKING_REJECTED';
      throw err;
    }

    // 3. Dynamic Pricing Calculation
    const pricing = rateService.calculateStayRate(roomTypeId, checkIn, checkOut, numRooms);
    const totalPayable = pricing.totalAmount;

    // Generate unique booking reference: LX-XXXXXX
    const randomSuffix = Math.floor(100000 + Math.random() * 900000);
    const bookingRef = `LX-${randomSuffix}`;
    const reservationId = `res-${Date.now()}-${randomSuffix}`;

    // Create reservation record (tentatively PENDING)
    const newReservation: Reservation = {
      id: reservationId,
      bookingRef,
      userId,
      guestName,
      guestEmail,
      guestPhone,
      hotelId,
      hotelName: hotel.name,
      roomTypeId,
      roomTypeName: roomType.name,
      roomTier: roomType.tier,
      checkIn,
      checkOut,
      numRooms,
      guestsCount,
      totalAmount: totalPayable,
      currency: 'INR',
      status: 'PENDING',
      paymentMethod,
      paymentStatus: 'PENDING',
      idempotencyKey: request.idempotencyKey,
      createdAt: new Date().toISOString()
    };

    // Save pending reservation in DB
    db.createReservation(newReservation);

    // 4. Payment Gateway Processing
    const paymentResult = await paymentService.processPayment({
      reservationId,
      amount: totalPayable,
      method: paymentMethod,
      details: paymentDetails || {}
    });

    if (!paymentResult.success) {
      // Payment Failed (e.g. Bank Decline Simulator triggered)
      // Safely release inventory and mark reservation as PAYMENT_FAILED
      db.updateReservationStatus(reservationId, 'PAYMENT_FAILED', 'FAILED');

      const paymentRecord: PaymentRecord = {
        id: `pay-${Date.now()}`,
        reservationId,
        transactionRef: paymentResult.transactionRef,
        method: paymentMethod,
        amount: totalPayable,
        status: 'FAILED',
        failureReason: paymentResult.failureReason,
        createdAt: new Date().toISOString()
      };
      db.createPayment(paymentRecord);

      const err = new Error(paymentResult.failureReason || 'Payment authorization declined');
      (err as any).code = 'PAYMENT_DECLINED';
      (err as any).reservation = db.getReservationById(reservationId);
      throw err;
    }

    // Payment Succeeded!
    const finalAmount = paymentResult.adjustedAmount !== undefined ? paymentResult.adjustedAmount : totalPayable;
    db.updateReservationStatus(reservationId, 'CONFIRMED', 'SUCCESS');
    
    // Update amount if voucher discounted it
    if (finalAmount !== totalPayable) {
      newReservation.totalAmount = finalAmount;
    }

    const paymentRecord: PaymentRecord = {
      id: `pay-${Date.now()}`,
      reservationId,
      transactionRef: paymentResult.transactionRef,
      method: paymentMethod,
      amount: finalAmount,
      status: 'SUCCESS',
      createdAt: new Date().toISOString()
    };
    db.createPayment(paymentRecord);

    const confirmedRes = db.getReservationById(reservationId)!;
    return {
      reservation: confirmedRes,
      paymentRecord
    };
  }

  /**
   * Tiered Refund Engine:
   * - If check-in > 48 hours away: 100% refund
   * - If check-in is between 24 and 48 hours away: 50% refund
   * - If check-in < 24 hours away: 0% refund (Non-refundable)
   */
  public calculateRefund(reservationId: string): RefundPreview {
    const reservation = db.getReservationById(reservationId);
    if (!reservation) {
      throw new Error(`Reservation ${reservationId} not found`);
    }

    const now = Date.now();
    const checkInTime = new Date(`${reservation.checkIn}T14:00:00`).getTime(); // Standard 2:00 PM check-in
    const diffHours = (checkInTime - now) / (1000 * 3600);

    let refundPercentage = 0;
    let policyDesc = 'Non-refundable (Less than 24 hours prior to check-in)';

    if (diffHours >= 48) {
      refundPercentage = 100;
      policyDesc = 'Full 100% Refund (More than 48 hours prior to check-in)';
    } else if (diffHours >= 24) {
      refundPercentage = 50;
      policyDesc = 'Partial 50% Refund (Between 24 and 48 hours prior to check-in)';
    }

    const refundAmount = Math.round((reservation.totalAmount * refundPercentage) / 100);

    return {
      reservationId,
      bookingRef: reservation.bookingRef,
      checkIn: reservation.checkIn,
      hoursUntilCheckIn: Math.round(diffHours * 10) / 10,
      refundPercentage,
      originalAmount: reservation.totalAmount,
      refundAmount,
      cancellationPolicyDescription: policyDesc
    };
  }

  /**
   * Execute Cancellation and Refund
   */
  public cancelReservation(reservationId: string, reason: string = 'Guest requested cancellation'): {
    reservation: Reservation;
    refundPreview: RefundPreview;
    paymentRefundRecord?: PaymentRecord;
  } {
    const reservation = db.getReservationById(reservationId);
    if (!reservation) {
      throw new Error(`Reservation ${reservationId} not found`);
    }

    if (reservation.status === 'CANCELLED') {
      throw new Error('Reservation is already cancelled');
    }

    const refund = this.calculateRefund(reservationId);

    // Update reservation state: CANCELLED
    const updated = db.updateReservationStatus(
      reservationId,
      'CANCELLED',
      refund.refundPercentage > 0 ? 'REFUNDED' : reservation.paymentStatus,
      refund.refundAmount
    );

    let paymentRefundRecord: PaymentRecord | undefined;
    if (refund.refundAmount > 0) {
      paymentRefundRecord = {
        id: `pay-ref-${Date.now()}`,
        reservationId,
        transactionRef: `REF_${reservation.bookingRef}_${Date.now()}`,
        method: reservation.paymentMethod,
        amount: refund.refundAmount,
        status: 'REFUNDED',
        createdAt: new Date().toISOString()
      };
      db.createPayment(paymentRefundRecord);
    }

    return {
      reservation: updated!,
      refundPreview: refund,
      paymentRefundRecord
    };
  }
}

export const reservationService = new ReservationService();

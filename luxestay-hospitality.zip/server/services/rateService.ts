import { db } from '../db.ts';
import { PriceBreakdown } from '../../src/types/index.ts';

export class RateService {
  /**
   * Computes dynamic pricing for a room type over a date range
   * Dynamic formula:
   * Effective Price = Base Price * Occupancy Factor * Day-of-Week Multiplier * Demand Surge
   */
  public calculateStayRate(
    roomTypeId: string,
    checkInDateStr: string,
    checkOutDateStr: string,
    numRooms: number = 1
  ): PriceBreakdown {
    const roomType = db.getRoomTypeById(roomTypeId);
    if (!roomType) {
      throw new Error(`Room type ${roomTypeId} not found`);
    }

    const baseNightlyRate = roomType.basePrice;
    const totalPhysical = roomType.totalPhysicalRooms;
    const currentlyBooked = db.getActiveBookedCount(roomTypeId);
    
    // Occupancy percentage based on physical rooms
    const currentOccupancyPct = (currentlyBooked / Math.max(1, totalPhysical)) * 100;

    // Occupancy Factor: <50% = 1.0x, 50-70% = 1.12x, 70-85% = 1.25x, >85% = 1.45x
    let occupancyFactor = 1.0;
    let occupancyLabel = 'Standard Availability (1.0x)';
    if (currentOccupancyPct > 85) {
      occupancyFactor = 1.45;
      occupancyLabel = 'High Demand Surge (1.45x)';
    } else if (currentOccupancyPct >= 70) {
      occupancyFactor = 1.25;
      occupancyLabel = 'Peak Occupancy (1.25x)';
    } else if (currentOccupancyPct >= 50) {
      occupancyFactor = 1.12;
      occupancyLabel = 'Moderate Demand (1.12x)';
    }

    // Parse dates
    const checkIn = new Date(checkInDateStr);
    const checkOut = new Date(checkOutDateStr);
    
    // Calculate nights difference, minimum 1 night
    let diffDays = Math.ceil((checkOut.getTime() - checkIn.getTime()) / (1000 * 3600 * 24));
    if (isNaN(diffDays) || diffDays <= 0) {
      diffDays = 1;
    }

    const dateBreakdowns: { date: string; isWeekend: boolean; nightlyRate: number }[] = [];
    let subtotalPerRoom = 0;

    for (let i = 0; i < diffDays; i++) {
      const currentDate = new Date(checkIn.getTime() + i * 24 * 3600 * 1000);
      const dayOfWeek = currentDate.getDay(); // 0 is Sunday, 5 is Friday, 6 is Saturday
      
      // Friday (5) or Saturday (6) nights have a 1.20x weekend leisure surge
      const isWeekend = dayOfWeek === 5 || dayOfWeek === 6;
      const weekendMultiplier = isWeekend ? 1.20 : 1.0;

      // Seasonal demand factor (e.g. 1.05 standard luxury baseline)
      const surgeMultiplier = 1.0;

      const nightlyRate = Math.round(
        baseNightlyRate * occupancyFactor * weekendMultiplier * surgeMultiplier
      );

      subtotalPerRoom += nightlyRate;
      dateBreakdowns.push({
        date: currentDate.toISOString().split('T')[0],
        isWeekend,
        nightlyRate
      });
    }

    const subtotal = subtotalPerRoom * numRooms;
    // Luxury hospitality tax in India: 18% GST
    const taxAmount = Math.round(subtotal * 0.18);
    const totalAmount = subtotal + taxAmount;
    const effectiveNightlyRate = Math.round(subtotalPerRoom / diffDays);

    return {
      baseNightlyRate,
      occupancyFactor,
      occupancyLabel,
      weekendMultiplier: dateBreakdowns.some(d => d.isWeekend) ? 1.20 : 1.0,
      surgeMultiplier: 1.0,
      effectiveNightlyRate,
      numberOfNights: diffDays,
      subtotal,
      taxAmount,
      totalAmount,
      dates: dateBreakdowns
    };
  }

  /**
   * Quick starting dynamic price estimation for hotel card
   */
  public getStartingDynamicRate(hotelId: string): number {
    const roomTypes = db.getRoomTypes(hotelId);
    if (!roomTypes.length) return 5000;
    
    // Find lowest base price room type
    const lowest = roomTypes.reduce((prev, curr) => prev.basePrice < curr.basePrice ? prev : curr);
    const today = new Date().toISOString().split('T')[0];
    const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];
    
    const rate = this.calculateStayRate(lowest.id, today, tomorrow, 1);
    return rate.effectiveNightlyRate;
  }
}

export const rateService = new RateService();

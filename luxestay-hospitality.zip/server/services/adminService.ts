import { db } from '../db.ts';
import { AdminAnalytics, RoomType } from '../../src/types/index.ts';

export class AdminService {
  /**
   * Computes executive analytics and KPIs
   */
  public getAnalytics(): AdminAnalytics {
    const reservations = db.getReservations();
    const hotels = db.getHotels();
    const allRoomTypes = db.getRoomTypes();

    let grossBookingValue = 0;
    let totalConfirmedStays = 0;
    let totalCancelledStays = 0;
    let totalNightsBooked = 0;

    const revenueByCityMap: Record<string, number> = {};
    for (const h of hotels) {
      revenueByCityMap[h.city] = 0;
    }

    for (const res of reservations) {
      if (res.status === 'CONFIRMED') {
        grossBookingValue += res.totalAmount;
        totalConfirmedStays += res.numRooms;
        
        const checkIn = new Date(res.checkIn);
        const checkOut = new Date(res.checkOut);
        const nights = Math.max(1, Math.ceil((checkOut.getTime() - checkIn.getTime()) / (1000 * 3600 * 24)));
        totalNightsBooked += nights * res.numRooms;

        const hotel = db.getHotelById(res.hotelId);
        if (hotel && revenueByCityMap[hotel.city] !== undefined) {
          revenueByCityMap[hotel.city] += res.totalAmount;
        }
      } else if (res.status === 'CANCELLED') {
        totalCancelledStays += res.numRooms;
      }
    }

    // Total physical rooms in portfolio
    let totalPhysicalRooms = 0;
    for (const rt of allRoomTypes) {
      totalPhysicalRooms += rt.totalPhysicalRooms;
    }

    // Active occupied rooms right now
    let totalOccupiedRooms = 0;
    for (const rt of allRoomTypes) {
      totalOccupiedRooms += db.getActiveBookedCount(rt.id);
    }

    const activeOccupancyRate = totalPhysicalRooms > 0
      ? Math.round((totalOccupiedRooms / totalPhysicalRooms) * 1000) / 10
      : 0;

    // Average Daily Rate (ADR) = Total Room Revenue / Total Nights Sold
    const averageDailyRate = totalNightsBooked > 0
      ? Math.round(grossBookingValue / totalNightsBooked)
      : (allRoomTypes.length > 0 ? Math.round(allRoomTypes.reduce((a, b) => a + b.basePrice, 0) / allRoomTypes.length) : 8500);

    // RevPAR = ADR * (Occupancy Rate / 100)
    const revPar = Math.round(averageDailyRate * (activeOccupancyRate / 100));

    // Cancellation Rate %
    const totalReservationsCount = totalConfirmedStays + totalCancelledStays;
    const cancellationRate = totalReservationsCount > 0
      ? Math.round((totalCancelledStays / totalReservationsCount) * 1000) / 10
      : 0;

    const revenueByCity = Object.entries(revenueByCityMap).map(([city, revenue]) => ({
      city,
      revenue
    }));

    const occupancyByProperty = hotels.map(hotel => {
      const roomTypes = db.getRoomTypes(hotel.id);
      const totalRooms = roomTypes.reduce((sum, r) => sum + r.totalPhysicalRooms, 0);
      const activeBookings = roomTypes.reduce((sum, r) => sum + db.getActiveBookedCount(r.id), 0);
      const occupancy = totalRooms > 0 ? Math.round((activeBookings / totalRooms) * 1000) / 10 : 0;
      return {
        hotelName: hotel.name,
        occupancy,
        activeBookings
      };
    });

    return {
      grossBookingValue,
      activeOccupancyRate,
      averageDailyRate,
      revPar,
      totalPhysicalRooms,
      totalOccupiedRooms,
      totalActiveStays: totalConfirmedStays,
      cancellationRate,
      revenueByCity,
      occupancyByProperty
    };
  }

  /**
   * Update base price for a single room type
   */
  public updateRoomBasePrice(roomTypeId: string, newPrice: number): RoomType {
    const updated = db.updateRoomTypeBasePrice(roomTypeId, newPrice);
    if (!updated) {
      throw new Error(`Room type ${roomTypeId} not found`);
    }
    return updated;
  }

  /**
   * Bulk update base tariff multiplier for a specific room tier
   */
  public updateTierTariffs(tier: string, multiplier: number): number {
    return db.updateTierBasePrices(tier, multiplier);
  }
}

export const adminService = new AdminService();

import { db } from '../db.ts';
import { PersonaRecommendation } from '../../src/types/index.ts';

export type GuestPersona = 'COUPLE' | 'BUSINESS' | 'FAMILY' | 'SOLO' | 'WELLNESS';

export class RecommendationService {
  /**
   * Recommend hotels tailored to specific guest personas
   */
  public getRecommendationsForPersona(persona: GuestPersona): PersonaRecommendation[] {
    const hotels = db.getHotels();
    const results: PersonaRecommendation[] = [];

    for (const hotel of hotels) {
      const roomTypes = db.getRoomTypes(hotel.id);
      let matchScore = 70;
      const highlights: string[] = [];
      let explanation = '';
      let recommendedRoom = roomTypes[0];

      switch (persona) {
        case 'COUPLE': {
          if (hotel.vibe === 'Heritage') {
            matchScore = 98;
            highlights.push('Royal Courtyard Candlelight Dining', 'Private Balcony Suites', 'Heritage High Tea');
            explanation = 'Perfect for romantic royal retreats with secluded heritage balconies and candlelit courtyard fine dining.';
            recommendedRoom = roomTypes.find(r => r.tier === 'Junior Suite' || r.tier === 'Deluxe') || roomTypes[0];
          } else if (hotel.vibe === 'Beach') {
            matchScore = 96;
            highlights.push('Private Plunge Pool', 'Direct Beachfront Sunset Vista', 'Ayurvedic Couple Spa');
            explanation = 'Intimate tropical sanctuary with private sunset verandahs and barefoot oceanfront luxury.';
            recommendedRoom = roomTypes.find(r => r.tier === 'Specialty' || r.tier === 'Deluxe') || roomTypes[0];
          } else if (hotel.city === 'Mumbai') {
            matchScore = 94;
            highlights.push("Queen's Necklace Sunsets", 'Seafront Champagne Lounge', 'Michelin Seafood Grill');
            explanation = 'Unrivaled sunset views over the Arabian Sea and celebratory fine dining on Marine Drive.';
            recommendedRoom = roomTypes.find(r => r.tier === 'Deluxe' || r.tier === 'Junior Suite') || roomTypes[0];
          } else if (hotel.vibe === 'Wellness') {
            matchScore = 88;
            highlights.push('Glasshouse Canopy Views', 'Couples Aromatherapy', 'Reflecting Ponds');
            explanation = 'Lush restorative sanctuary with tranquil water gardens and restorative wellness baths.';
            recommendedRoom = roomTypes.find(r => r.tier === 'Junior Suite') || roomTypes[0];
          } else {
            matchScore = 80;
            highlights.push('Contemporary Luxury', 'Acoustic Soundproofing');
            explanation = 'Sleek luxury design with discreet service.';
          }
          break;
        }

        case 'BUSINESS': {
          if (hotel.id === 'hotel-hyd-tech') {
            matchScore = 99;
            highlights.push('Motorized Ergonomic Desks', 'Soundproof Meeting Pods', 'Gigabit Wi-Fi 6', 'Financial District Core');
            explanation = 'Architected specifically for founders and executives with boardroom suites and zero-latency tech amenities.';
            recommendedRoom = roomTypes.find(r => r.id === 'rt-hyd-t-dlx' || r.tier === 'Standard') || roomTypes[0];
          } else if (hotel.id === 'hotel-del-aerocity') {
            matchScore = 97;
            highlights.push('5 Mins to Terminal 3', '24h Flexible Check-in', 'Diplomatic VIP Lounge', 'Soundproof Acoustic Glass');
            explanation = 'Prime connectivity hub for high-velocity global travelers with round-the-clock flex check-in.';
            recommendedRoom = roomTypes.find(r => r.tier === 'Deluxe' || r.tier === 'Standard') || roomTypes[0];
          } else if (hotel.city === 'Mumbai') {
            matchScore = 91;
            highlights.push('Nariman Point Proximity', 'Executive Chauffeur', 'High-Speed Wi-Fi');
            explanation = 'Strategic South Mumbai address next to corporate headquarters and financial institutions.';
            recommendedRoom = roomTypes.find(r => r.tier === 'Standard') || roomTypes[0];
          } else if (hotel.vibe === 'Wellness') {
            matchScore = 85;
            highlights.push('Silent Working Cabanas', 'Central Bangalore Hub');
            explanation = 'Peaceful workcation sanctuary with biophilic workspace and green serenity.';
            recommendedRoom = roomTypes.find(r => r.tier === 'Standard') || roomTypes[0];
          } else {
            matchScore = 75;
            highlights.push('Executive Services', 'Fast Wi-Fi');
            explanation = 'Reliable luxury hospitality with business centers.';
          }
          break;
        }

        case 'FAMILY': {
          if (hotel.vibe === 'Beach') {
            matchScore = 97;
            highlights.push('Multi-Bedroom Family Villas', 'Private Beach Lagoon', 'Surf & Paddleboard School', 'Kids Sand Activities');
            explanation = 'Idyllic tropical playground with expansive lawns, shallow lagoon pools, and bespoke coastal excursions.';
            recommendedRoom = roomTypes.find(r => r.tier === 'Presidential' || r.capacityGuests >= 3) || roomTypes[0];
          } else if (hotel.vibe === 'Heritage') {
            matchScore = 93;
            highlights.push('Sprawling Royal Grounds', 'Historic Storytelling Tours', 'Private Courtyard Suites');
            explanation = 'Immersive living history estate where kids and grandparents experience genuine royal hospitality.';
            recommendedRoom = roomTypes.find(r => r.capacityGuests >= 3) || roomTypes[0];
          } else if (hotel.vibe === 'Wellness') {
            matchScore = 89;
            highlights.push('Botanical Nature Walks', 'Saltwater Family Lap Pool', 'Greenhouse Dining');
            explanation = 'Healthy, refreshing urban oasis with expansive botanical gardens and farm-fresh organic food.';
            recommendedRoom = roomTypes.find(r => r.capacityGuests >= 3) || roomTypes[0];
          } else {
            matchScore = 78;
            highlights.push('Interconnected Rooms', 'Concierge Tour Planning');
            explanation = 'Generous room sizes and warm hospitality for traveling families.';
            recommendedRoom = roomTypes.find(r => r.capacityGuests >= 3) || roomTypes[0];
          }
          break;
        }

        case 'WELLNESS': {
          if (hotel.vibe === 'Wellness') {
            matchScore = 99;
            highlights.push('Century-Old Botanical Arboretum', 'Canopy Ayurvedic Spa', 'Saltwater Hydrotherapy', 'Holistic Detox Nutrition');
            explanation = 'Certified holistic wellness center offering authentic Ayurvedic doctor consultations, herbal baths, and silent meditation.';
            recommendedRoom = roomTypes.find(r => r.tier === 'Specialty' || r.tier === 'Junior Suite') || roomTypes[0];
          } else if (hotel.vibe === 'Beach') {
            matchScore = 95;
            highlights.push('Sunset Clifftop Yoga', 'Naturopathy Steam Rooms', 'Clean Farm-to-Table Cuisine');
            explanation = 'Rejuvenating sea-air wellness with sunrise pranayama and coastal herbal body treatments.';
            recommendedRoom = roomTypes.find(r => r.tier === 'Specialty' || r.tier === 'Standard') || roomTypes[0];
          } else if (hotel.vibe === 'Heritage') {
            matchScore = 90;
            highlights.push('Jiva Royal Spa', 'Herbal Jasmine Gardens', 'Quiet Marble Courtyards');
            explanation = 'Ancient royal wellness rituals practiced with pure organic essential oils and temple stone baths.';
            recommendedRoom = roomTypes.find(r => r.tier === 'Junior Suite') || roomTypes[0];
          } else {
            matchScore = 76;
            highlights.push('Modern Gym & Sauna', 'Lap Pool');
            explanation = 'Dedicated fitness facilities and healthy dining options.';
          }
          break;
        }

        case 'SOLO': {
          if (hotel.city === 'Mumbai') {
            matchScore = 96;
            highlights.push('Marine Drive Promenade Walks', 'Safe 24/7 Security', 'Art Deco Cocktail Bar', 'City Culture Access');
            explanation = 'The quintessential solo traveler base right on the Arabian Sea with safe vibrant street life and cultural landmarks.';
            recommendedRoom = roomTypes.find(r => r.tier === 'Standard') || roomTypes[0];
          } else if (hotel.vibe === 'Wellness') {
            matchScore = 94;
            highlights.push('Reading Conservatories', 'Aromatherapy Suites', 'Peaceful Mindful Ambiance');
            explanation = 'Restorative solo retreat for creative contemplation and digital detox.';
            recommendedRoom = roomTypes.find(r => r.tier === 'Standard') || roomTypes[0];
          } else if (hotel.id === 'hotel-hyd-tech') {
            matchScore = 92;
            highlights.push('High-Velocity Solo Tech Pod', 'Rooftop Pool', 'Workstation in Room');
            explanation = 'Effortless solo business workcation with frictionless digital keys and 24h dining.';
            recommendedRoom = roomTypes.find(r => r.tier === 'Standard' || r.tier === 'Deluxe') || roomTypes[0];
          } else {
            matchScore = 84;
            highlights.push('Boutique Comfort', 'Warm Hospitality');
            explanation = 'Safe and attentive solo stay experience with curated concierge recommendations.';
            recommendedRoom = roomTypes.find(r => r.tier === 'Standard') || roomTypes[0];
          }
          break;
        }
      }

      results.push({
        hotel,
        matchScore,
        highlights,
        recommendedRoomType: recommendedRoom,
        explanation
      });
    }

    // Sort by match score descending
    return results.sort((a, b) => b.matchScore - a.matchScore);
  }
}

export const recommendationService = new RecommendationService();

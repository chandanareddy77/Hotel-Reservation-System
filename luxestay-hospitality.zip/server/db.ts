import {
  Hotel,
  RoomType,
  PhysicalRoom,
  User,
  Reservation,
  PaymentRecord
} from '../src/types/index.ts';

// Pre-seeded Indian Luxury Hotels
export const INITIAL_HOTELS: Hotel[] = [
  {
    id: 'hotel-hyd-heritage',
    name: 'LuxeStay Nizam Heritage Palace',
    city: 'Hyderabad',
    neighborhood: 'Banjara Hills',
    address: 'Road No. 1, Banjara Hills, Hyderabad, Telangana 500034',
    rating: 4.9,
    reviewCount: 1420,
    imageUrl: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1600&q=80',
    galleryUrls: [
      'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80'
    ],
    description: 'A restored 19th-century Asaf Jahi architectural jewel set atop private hillock terraced gardens with marble colonnades, royal banquet halls, Belgian crystal chandeliers, and private butler service.',
    amenities: ['Royal High Tea', 'Heritage Courtyard Pool', 'Ayurvedic Jiva Spa', '24/7 Royal Butler', 'Fine Dining Nizam Restaurant', 'Valet Parking', 'High-Speed Wi-Fi'],
    startingPrice: 4800,
    tags: ['Heritage', 'Couple', 'Fine Dining', 'Opulent Architecture'],
    vibe: 'Heritage'
  },
  {
    id: 'hotel-hyd-tech',
    name: 'LuxeStay Grand Tech Vista',
    city: 'Hyderabad',
    neighborhood: 'HITEC City',
    address: 'Financial District, Nanakramguda, HITEC City, Hyderabad 500032',
    rating: 4.8,
    reviewCount: 980,
    imageUrl: 'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?auto=format&fit=crop&w=1600&q=80',
    galleryUrls: [
      'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=1200&q=80'
    ],
    description: 'Ultra-contemporary glass tower overlooking Cyber Towers, featuring ergonomic Herman Miller workstations, smart automated suite controls, rooftop infinity pool, and hyper-speed fiber connectivity.',
    amenities: ['Smart Room Tech', 'Rooftop Helipad & Pool', '24/7 Executive Lounge', 'Soundproof Meeting Pods', 'Fitness Hub & Sauna', 'EV Superchargers'],
    startingPrice: 3900,
    tags: ['Business Trip', 'Modern', 'Solo', 'Executive Hub'],
    vibe: 'Modern'
  },
  {
    id: 'hotel-mum-marine',
    name: 'LuxeStay Marine Bay & Residences',
    city: 'Mumbai',
    neighborhood: 'Marine Drive',
    address: '135 Marine Drive, Nariman Point, Mumbai, Maharashtra 400020',
    rating: 4.9,
    reviewCount: 2150,
    imageUrl: 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=1600&q=80',
    galleryUrls: [
      'https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1591088398332-8a7791972843?auto=format&fit=crop&w=1200&q=80'
    ],
    description: 'Iconic art deco-inspired sanctuary on the legendary Queen’s Necklace, offering panoramic Arabian Sea sunsets, Michelin-acclaimed seafood grill, and private yacht charter services.',
    amenities: ['Sea-Facing Infinity Terrace', 'Sommelier Wine Cellar', 'Private Yacht Access', 'Steam & Vitality Pool', 'Art Deco Cocktail Bar', 'Luxury Chauffeur'],
    startingPrice: 6500,
    tags: ['Luxury Stay', 'Couple', 'Oceanfront', 'Fine Dining'],
    vibe: 'Modern'
  },
  {
    id: 'hotel-goa-beach',
    name: 'LuxeStay Serene Palms Beach Resort',
    city: 'Goa',
    neighborhood: 'Vagator Beach',
    address: 'Ozran Beach Road, Small Vagator, Anjuna, Goa 403509',
    rating: 4.9,
    reviewCount: 1780,
    imageUrl: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=1600&q=80',
    galleryUrls: [
      'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1578683010236-d716f9a3f461?auto=format&fit=crop&w=1200&q=80'
    ],
    description: 'Private 12-acre beachfront tropical retreat nestled on cliffside red laterite bluffs, featuring open-air thatched villas, private infinity plunge pools, sunset yoga decks, and coastal susegad tranquility.',
    amenities: ['Private Beach Access', 'Ayurveda Naturopathy Spa', 'Sunset Cliffside Bar', 'Surf & Paddleboard School', 'Organic Farm-to-Table Dining'],
    startingPrice: 5400,
    tags: ['Beach & Resort', 'Couple', 'Wellness', 'Family Holiday'],
    vibe: 'Beach'
  },
  {
    id: 'hotel-blr-botanical',
    name: 'LuxeStay Botanical Grand & Spa',
    city: 'Bangalore',
    neighborhood: 'Central',
    address: '28 Sankey Road, Sadashivanagar, Bangalore, Karnataka 560080',
    rating: 4.8,
    reviewCount: 1120,
    imageUrl: 'https://images.unsplash.com/photo-1618773928121-c32242e63f39?auto=format&fit=crop&w=1600&q=80',
    galleryUrls: [
      'https://images.unsplash.com/photo-1618773928121-c32242e63f39?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=1200&q=80'
    ],
    description: 'An architectural glasshouse paradise integrated within a century-old tropical arboretum. Features indoor waterfalls, botanical reflexology walks, holistic wellness programs, and silent working cabanas.',
    amenities: ['Canopy Botanical Spa', 'Glasshouse Greenhouse Cafe', 'Saltwater Lap Pool', 'Meditation Pavilion', 'Aromatherapy Suites', 'High-Speed Wi-Fi'],
    startingPrice: 4400,
    tags: ['Eco-Luxury', 'Wellness', 'Business Trip', 'Solo'],
    vibe: 'Wellness'
  },
  {
    id: 'hotel-del-aerocity',
    name: 'LuxeStay Imperial Aerocity Manor',
    city: 'Delhi',
    neighborhood: 'Aerocity',
    address: 'Hospitality District, Asset Area 4, IGI Airport, New Delhi 110037',
    rating: 4.8,
    reviewCount: 1650,
    imageUrl: 'https://images.unsplash.com/photo-1564501049412-61c2a3083791?auto=format&fit=crop&w=1600&q=80',
    galleryUrls: [
      'https://images.unsplash.com/photo-1564501049412-61c2a3083791?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1200&q=80'
    ],
    description: 'Diplomatic neoclassical estate 5 minutes from Terminal 3. Quadruple-glazed acoustic tranquility, 24-hour round-the-clock check-in/out flex, grand ballroom, and high-security diplomatic suites.',
    amenities: ['Soundproof Acoustic Rooms', '24-Hour Dining & Check-in', 'Diplomatic VIP Lounge', 'Indoor Olympic Pool', 'Luxury Airport Limousine'],
    startingPrice: 4600,
    tags: ['Luxury Stay', 'Business Trip', 'Transit', 'Executive Hub'],
    vibe: 'Modern'
  }
];

// Room types with full tiers for each hotel
export const INITIAL_ROOM_TYPES: RoomType[] = [
  // 1. Nizam Heritage Palace (Hyderabad)
  {
    id: 'rt-hyd-h-std',
    hotelId: 'hotel-hyd-heritage',
    name: 'Standard Heritage Room',
    tier: 'Standard',
    basePrice: 4800,
    capacityGuests: 2,
    bedType: '1 King Bed or 2 Twin Beds',
    squareFeet: 380,
    amenities: ['Mughal Garden View', 'Handcrafted Teak Furniture', 'Marble Rain Shower', 'Complimentary High Tea', 'Illy Espresso Machine'],
    totalPhysicalRooms: 12,
    imageUrl: 'https://images.unsplash.com/photo-1618773928121-c32242e63f39?auto=format&fit=crop&w=800&q=80',
    description: 'Serene courtyard sanctuary accented with brass inlays, vintage prints, and views of the fragrant royal jasmine groves.'
  },
  {
    id: 'rt-hyd-h-dlx',
    hotelId: 'hotel-hyd-heritage',
    name: 'Deluxe Heritage Chamber',
    tier: 'Deluxe',
    basePrice: 6500,
    capacityGuests: 3,
    bedType: '1 Royal King Bed',
    squareFeet: 520,
    amenities: ['Private Balcony', 'Deep Soaking Clawfoot Tub', 'Bose Soundbar', 'Artisanal Minibar', '24/7 On-Call Butler'],
    totalPhysicalRooms: 10,
    imageUrl: 'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=800&q=80',
    description: 'Expansive chamber boasting hand-carved archways, private terrace overlooking the illuminated palace fountains.'
  },
  {
    id: 'rt-hyd-h-jste',
    hotelId: 'hotel-hyd-heritage',
    name: 'Junior Nizam Courtyard Suite',
    tier: 'Junior Suite',
    basePrice: 9800,
    capacityGuests: 3,
    bedType: '1 Maharaja King Bed',
    squareFeet: 720,
    amenities: ['Separate Sitting Parlor', 'Walk-in Dressing Room', 'Complimentary Evening Cocktails', 'Molton Brown Amenities', 'Pillow Concierge'],
    totalPhysicalRooms: 8,
    imageUrl: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80',
    description: 'Splendid two-room suite featuring an ornate sitting parlor, heritage portraits, and arched French doors opening into the central courtyard.'
  },
  {
    id: 'rt-hyd-h-pres',
    hotelId: 'hotel-hyd-heritage',
    name: 'Grand Nizam Presidential Suite',
    tier: 'Presidential',
    basePrice: 26000,
    capacityGuests: 4,
    bedType: '1 Custom Royal Canopy King Bed',
    squareFeet: 1800,
    amenities: ['Private Plunge Pool', 'Dedicated 24/7 Butler & Chef', 'Private Dining Room (8 seats)', 'Italian Marble Steam Suite', 'Chauffeured Rolls-Royce Transfers'],
    totalPhysicalRooms: 3,
    imageUrl: 'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?auto=format&fit=crop&w=800&q=80',
    description: 'The pinnacle of regal splendor. Formerly the Nizam’s guest quarters, boasting museum-grade antique artifacts, 24-carat gold leaf ceilings, and private terrace garden.'
  },
  {
    id: 'rt-hyd-h-spec',
    hotelId: 'hotel-hyd-heritage',
    name: 'Royal Nizam Heritage Suite',
    tier: 'Specialty',
    basePrice: 16500,
    capacityGuests: 3,
    bedType: '1 King Bed',
    squareFeet: 1100,
    amenities: ['Heritage Sitting Room', 'Jetted Jacuzzi Tub', 'Private Wine Cellarette', 'Afternoon Royal Tea Service'],
    totalPhysicalRooms: 4,
    imageUrl: 'https://images.unsplash.com/photo-1578683010236-d716f9a3f461?auto=format&fit=crop&w=800&q=80',
    description: 'Signature heritage specialty suite designed with historic Hyderabadi arches, Persian carpets, and hand-embroidered silk upholstery.'
  },

  // 2. Grand Tech Vista (Hyderabad HITEC City)
  {
    id: 'rt-hyd-t-std',
    hotelId: 'hotel-hyd-tech',
    name: 'Standard Business Room',
    tier: 'Standard',
    basePrice: 3900,
    capacityGuests: 2,
    bedType: '1 Queen Bed',
    squareFeet: 340,
    amenities: ['Ergonomic Work Desk', 'Acoustic Soundproofing', 'Smart Ambient Lighting', 'Wireless Charging Stations', 'Nespresso Pods'],
    totalPhysicalRooms: 15,
    imageUrl: 'https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=800&q=80',
    description: 'Precision-engineered workspace sanctuary for the modern executive with quiet acoustics and high-speed Wi-Fi 6.'
  },
  {
    id: 'rt-hyd-t-dlx',
    hotelId: 'hotel-hyd-tech',
    name: 'Deluxe Tech Pod',
    tier: 'Deluxe',
    basePrice: 5400,
    capacityGuests: 2,
    bedType: '1 King Bed',
    squareFeet: 460,
    amenities: ['Motorized Standing Desk', 'Dual 4K External Monitors', 'Smart Blackout Blinds', 'Rain Shower with Mood Lighting', 'Dyson Supersonic'],
    totalPhysicalRooms: 12,
    imageUrl: 'https://images.unsplash.com/photo-1591088398332-8a7791972843?auto=format&fit=crop&w=800&q=80',
    description: 'Futuristic comfort tailored for founders and tech leaders with voice-controlled smart glass, motorized workspace, and ergonomic lounger.'
  },
  {
    id: 'rt-hyd-t-jste',
    hotelId: 'hotel-hyd-tech',
    name: 'Junior Skyline Suite',
    tier: 'Junior Suite',
    basePrice: 8900,
    capacityGuests: 3,
    bedType: '1 King Bed',
    squareFeet: 680,
    amenities: ['Skyline Corner Views', 'Living Room with Herman Miller Seating', 'Executive Lounge Access', 'Express Dry Cleaning', 'Cocktail Hour'],
    totalPhysicalRooms: 8,
    imageUrl: 'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=800&q=80',
    description: 'High-floor corner suite offering panoramic views across HITEC City with partitioned media lounge.'
  },
  {
    id: 'rt-hyd-t-pres',
    hotelId: 'hotel-hyd-tech',
    name: 'Silicon Presidential Penthouse',
    tier: 'Presidential',
    basePrice: 21000,
    capacityGuests: 4,
    bedType: '1 Master King Bed',
    squareFeet: 1600,
    amenities: ['Private Rooftop Hot Tub', 'Private Boardroom for 8', 'Bang & Olufsen Cinema Sound', 'Dedicated Barista & Chef', 'Airport EV Transfer'],
    totalPhysicalRooms: 2,
    imageUrl: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80',
    description: 'The top-floor duplex penthouse with 20-foot glass curtain walls, private glass jacuzzi, and connected private boardroom.'
  },
  {
    id: 'rt-hyd-t-spec',
    hotelId: 'hotel-hyd-tech',
    name: 'Executive Tech Studio',
    tier: 'Specialty',
    basePrice: 12500,
    capacityGuests: 2,
    bedType: '1 King Bed',
    squareFeet: 850,
    amenities: ['Conference Video Bar', 'Smart Whiteboard', 'Stocked Nutrient Minibar', 'Fastest Fiber Connection'],
    totalPhysicalRooms: 5,
    imageUrl: 'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?auto=format&fit=crop&w=800&q=80',
    description: 'Specialty hybrid living-and-meeting studio equipped with enterprise video conferencing infrastructure.'
  },

  // 3. Marine Bay & Residences (Mumbai)
  {
    id: 'rt-mum-m-std',
    hotelId: 'hotel-mum-marine',
    name: 'Standard City View Room',
    tier: 'Standard',
    basePrice: 6500,
    capacityGuests: 2,
    bedType: '1 Queen Bed',
    squareFeet: 360,
    amenities: ['Art Deco Accents', 'South Bombay Cityscape View', 'Italian Marble Bathroom', 'TWG Luxury Teas', 'Signature Bedding'],
    totalPhysicalRooms: 12,
    imageUrl: 'https://images.unsplash.com/photo-1618773928121-c32242e63f39?auto=format&fit=crop&w=800&q=80',
    description: 'Chic Art Deco guestroom overlooking heritage South Mumbai architecture with bespoke velvet loungers.'
  },
  {
    id: 'rt-mum-m-dlx',
    hotelId: 'hotel-mum-marine',
    name: 'Premier Seafront Deluxe',
    tier: 'Deluxe',
    basePrice: 9500,
    capacityGuests: 2,
    bedType: '1 King Bed',
    squareFeet: 500,
    amenities: ['Direct Arabian Sea View', 'Balcony with Sunset Seating', 'Freestanding Bathtub with Ocean View', 'Complimentary Champagne Welcome'],
    totalPhysicalRooms: 10,
    imageUrl: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80',
    description: 'Breathtaking front-row seat to the Arabian Sea waves and the dusk glow of Queen’s Necklace.'
  },
  {
    id: 'rt-mum-m-jste',
    hotelId: 'hotel-mum-marine',
    name: 'Junior Ocean Bayfront Suite',
    tier: 'Junior Suite',
    basePrice: 14500,
    capacityGuests: 3,
    bedType: '1 King Bed',
    squareFeet: 750,
    amenities: ['Separate Glass Living Parlor', 'Dual Vanities & Rain Spa', 'Priority Table at Sea Grill', 'Curated Art Collection'],
    totalPhysicalRooms: 6,
    imageUrl: 'https://images.unsplash.com/photo-1591088398332-8a7791972843?auto=format&fit=crop&w=800&q=80',
    description: 'Sophisticated waterfront suite with wrap-around bay windows, private study, and sunset cocktail bar.'
  },
  {
    id: 'rt-mum-m-pres',
    hotelId: 'hotel-mum-marine',
    name: 'Queen’s Necklace Presidential Suite',
    tier: 'Presidential',
    basePrice: 35000,
    capacityGuests: 4,
    bedType: '1 Royal King Bed',
    squareFeet: 2100,
    amenities: ['Wrap-Around 270° Promenade Terrace', 'Steinway Baby Grand Piano', 'Private Chef Pantry', 'Master Spa with Sauna', 'Private Yacht Cruise Included'],
    totalPhysicalRooms: 2,
    imageUrl: 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=800&q=80',
    description: 'Mumbai’s most prestigious seafront address. High above Marine Drive with private terrace dining and uninterrupted ocean horizons.'
  },
  {
    id: 'rt-mum-m-spec',
    hotelId: 'hotel-mum-marine',
    name: 'Marine Grand Panorama Suite',
    tier: 'Specialty',
    basePrice: 22000,
    capacityGuests: 3,
    bedType: '1 King Bed',
    squareFeet: 1200,
    amenities: ['Panoramic Corner Ocean Balcony', 'Cocktail Bar Station', 'Jacuzzi with Sea Vista', 'Club Floor Privileges'],
    totalPhysicalRooms: 4,
    imageUrl: 'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?auto=format&fit=crop&w=800&q=80',
    description: 'Specialty panorama suite capturing the glittering curve of Marine Drive and crashing Arabian tides.'
  },

  // 4. Serene Palms Beach Resort (Goa)
  {
    id: 'rt-goa-b-std',
    hotelId: 'hotel-goa-beach',
    name: 'Standard Palms Room',
    tier: 'Standard',
    basePrice: 5400,
    capacityGuests: 2,
    bedType: '1 King Bed',
    squareFeet: 410,
    amenities: ['Private Garden Patio', 'Tropical Rain Shower', 'Handwoven Cane Daybed', 'Organic Herbal Toiletries', 'Yoga Mat & Blocks'],
    totalPhysicalRooms: 14,
    imageUrl: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=800&q=80',
    description: 'Tranquil garden retreat surrounded by swaying coconut palms, frangipani blossoms, and Goa sea breezes.'
  },
  {
    id: 'rt-goa-b-dlx',
    hotelId: 'hotel-goa-beach',
    name: 'Deluxe Coastal Verandah',
    tier: 'Deluxe',
    basePrice: 7500,
    capacityGuests: 3,
    bedType: '1 King Bed',
    squareFeet: 560,
    amenities: ['Spacious Outdoor Daybed Verandah', 'Open-Air Terrazzo Soaking Tub', 'Complimentary Sunset Coconut Waters', 'Bose Bluetooth Speaker'],
    totalPhysicalRooms: 10,
    imageUrl: 'https://images.unsplash.com/photo-1578683010236-d716f9a3f461?auto=format&fit=crop&w=800&q=80',
    description: 'Elevated cottage with breezy verandah overlooking the lagoon pool and coastal tropical flora.'
  },
  {
    id: 'rt-goa-b-jste',
    hotelId: 'hotel-goa-beach',
    name: 'Junior Sunset Bay Suite',
    tier: 'Junior Suite',
    basePrice: 11200,
    capacityGuests: 3,
    bedType: '1 Four-Poster King Bed',
    squareFeet: 820,
    amenities: ['Direct Beach Trail Access', 'Open-to-Sky Tropical Shower', 'Living Pavilion with Hammock', 'Afternoon Sundowner Drinks'],
    totalPhysicalRooms: 6,
    imageUrl: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80',
    description: 'Romantic cottage suite positioned for uninterrupted views of Vagator crimson sunsets.'
  },
  {
    id: 'rt-goa-b-pres',
    hotelId: 'hotel-goa-beach',
    name: 'Oceanfront Royal Presidential Villa',
    tier: 'Presidential',
    basePrice: 29500,
    capacityGuests: 6,
    bedType: '2 King Bedrooms',
    squareFeet: 2400,
    amenities: ['Private Heated Infinity Plunge Pool', 'Direct Private Gated Beach Access', 'Private Gazebo & Sunken Lounge', 'Dedicated Ayurvedic Wellness Butler'],
    totalPhysicalRooms: 2,
    imageUrl: 'https://images.unsplash.com/photo-1618773928121-c32242e63f39?auto=format&fit=crop&w=800&q=80',
    description: 'An exclusive oceanfront sanctuary with its own freshwater pool, private beach path, and personalized spa treatments.'
  },
  {
    id: 'rt-goa-b-spec',
    hotelId: 'hotel-goa-beach',
    name: 'Beachfront Plunge Pool Villa',
    tier: 'Specialty',
    basePrice: 18500,
    capacityGuests: 2,
    bedType: '1 King Bed',
    squareFeet: 980,
    amenities: ['Private 15ft Plunge Pool', 'Outdoor Rain Garden', 'Floating Breakfast Setup', 'Couple Spa Treatment Included'],
    totalPhysicalRooms: 4,
    imageUrl: 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=800&q=80',
    description: 'Idyllic romantic hideaway steps from the sand with secluded walled plunge pool and open sky garden.'
  },

  // 5. Botanical Grand & Spa (Bangalore)
  {
    id: 'rt-blr-b-std',
    hotelId: 'hotel-blr-botanical',
    name: 'Standard Botanical Room',
    tier: 'Standard',
    basePrice: 4400,
    capacityGuests: 2,
    bedType: '1 Queen Bed',
    squareFeet: 370,
    amenities: ['Forest Canopy View', 'Natural Linen Bedding', 'Essential Oil Diffuser', 'Purified Alkaline Water', 'Organic Tea Selection'],
    totalPhysicalRooms: 12,
    imageUrl: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=800&q=80',
    description: 'Biophilic haven bathed in gentle filtered daylight, overlooking the sprawling botanical conservatory.'
  },
  {
    id: 'rt-blr-b-dlx',
    hotelId: 'hotel-blr-botanical',
    name: 'Deluxe Garden Sanctuary',
    tier: 'Deluxe',
    basePrice: 6200,
    capacityGuests: 3,
    bedType: '1 King Bed',
    squareFeet: 510,
    amenities: ['Private Greenery Balcony', 'Himalayan Salt Lamp', 'Deep Marble Soaking Tub', 'Daily Herbal Elixir Service'],
    totalPhysicalRooms: 10,
    imageUrl: 'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=800&q=80',
    description: 'Spacious retreat with private terrace overlooking orchid gardens and soothing bamboo water fountains.'
  },
  {
    id: 'rt-blr-b-jste',
    hotelId: 'hotel-blr-botanical',
    name: 'Junior Orchid Canopy Suite',
    tier: 'Junior Suite',
    basePrice: 9500,
    capacityGuests: 3,
    bedType: '1 King Bed',
    squareFeet: 740,
    amenities: ['Living Conservatory Parlor', 'Dual Steam Shower', 'Holistic Sleep Kit with Weighted Blanket', 'Spa Club Access'],
    totalPhysicalRooms: 8,
    imageUrl: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80',
    description: 'Light-filled glass sanctuary featuring private indoor exotic plants, reading nook, and restorative spa bath.'
  },
  {
    id: 'rt-blr-b-pres',
    hotelId: 'hotel-blr-botanical',
    name: 'The Royal Glasshouse Presidential Suite',
    tier: 'Presidential',
    basePrice: 22500,
    capacityGuests: 4,
    bedType: '1 Custom Master Bed',
    squareFeet: 1900,
    amenities: ['Private Heated Hydrotherapy Pool', 'Botanical Atrium Dining Room', 'Private Ayurvedic Treatment Room', 'Sound Healing Sessions'],
    totalPhysicalRooms: 2,
    imageUrl: 'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?auto=format&fit=crop&w=800&q=80',
    description: 'Stunning glass-encased penthouse floating above the tree canopy with private rooftop botanical pool.'
  },
  {
    id: 'rt-blr-b-spec',
    hotelId: 'hotel-blr-botanical',
    name: 'Holistic Wellness Club Suite',
    tier: 'Specialty',
    basePrice: 14000,
    capacityGuests: 2,
    bedType: '1 King Bed',
    squareFeet: 920,
    amenities: ['In-Room Infrared Sauna', 'Daily Hydrotherapy Treatment', 'Custom Detox Menu by Nutritionist', 'Private Sun Deck'],
    totalPhysicalRooms: 4,
    imageUrl: 'https://images.unsplash.com/photo-1618773928121-c32242e63f39?auto=format&fit=crop&w=800&q=80',
    description: 'Purpose-built restorative suite featuring in-room cedar sauna and personalized wellness consultations.'
  },

  // 6. Imperial Aerocity Manor (Delhi)
  {
    id: 'rt-del-a-std',
    hotelId: 'hotel-del-aerocity',
    name: 'Standard Transit Room',
    tier: 'Standard',
    basePrice: 4600,
    capacityGuests: 2,
    bedType: '1 Queen Bed',
    squareFeet: 350,
    amenities: ['Acoustic Triple-Pane Glass', '100% Blackout Curtains', 'Featherbed Mattress', 'Express 4-Hour Laundry', 'Runway View on Request'],
    totalPhysicalRooms: 15,
    imageUrl: 'https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=800&q=80',
    description: 'Engineered for seamless rest between flights with sound isolation and 24/7 in-room dining.'
  },
  {
    id: 'rt-del-a-dlx',
    hotelId: 'hotel-del-aerocity',
    name: 'Deluxe Manor Chamber',
    tier: 'Deluxe',
    basePrice: 6600,
    capacityGuests: 2,
    bedType: '1 King Bed',
    squareFeet: 480,
    amenities: ['Deep Soaking Tub', 'Coffee Bar with Single-Origin Roasts', 'Executive Lounge Privileges', 'Flexible 24h Check-in/out Option'],
    totalPhysicalRooms: 12,
    imageUrl: 'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=800&q=80',
    description: 'Refined colonial-manor styling with rich walnut paneling, leather writing desk, and marble bath.'
  },
  {
    id: 'rt-del-a-jste',
    hotelId: 'hotel-del-aerocity',
    name: 'Junior Diplomatic Suite',
    tier: 'Junior Suite',
    basePrice: 10200,
    capacityGuests: 3,
    bedType: '1 King Bed',
    squareFeet: 700,
    amenities: ['Formal Sitting Room', 'Walk-in Closet', 'Complimentary Aerocity Luxury Shuttles', 'Evening High Tea Buffet Access'],
    totalPhysicalRooms: 8,
    imageUrl: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80',
    description: 'Distinguished suite featuring an elegant sitting parlor suitable for intimate diplomatic or corporate meetings.'
  },
  {
    id: 'rt-del-a-pres',
    hotelId: 'hotel-del-aerocity',
    name: 'Imperial Diplomatic Presidential Suite',
    tier: 'Presidential',
    basePrice: 24000,
    capacityGuests: 4,
    bedType: '1 Master Canopy King Bed',
    squareFeet: 1850,
    amenities: ['Secure Private Wing', 'Bullet-Resistant Glass Glazing', 'Formal Dining Hall (10 Guests)', 'Dedicated Butler & Security Detail Room', 'VIP T3 Airport Fast-Track'],
    totalPhysicalRooms: 2,
    imageUrl: 'https://images.unsplash.com/photo-1564501049412-61c2a3083791?auto=format&fit=crop&w=800&q=80',
    description: 'High-security diplomatic residence hosting visiting dignitaries, ministers, and heads of industry.'
  },
  {
    id: 'rt-del-a-spec',
    hotelId: 'hotel-del-aerocity',
    name: 'Club Executive Manor Suite',
    tier: 'Specialty',
    basePrice: 15500,
    capacityGuests: 3,
    bedType: '1 King Bed',
    squareFeet: 1050,
    amenities: ['Club Lounge Access', 'Conference Room Access (2 hrs)', 'Private Barista Station', 'Bespoke Airport Escort'],
    totalPhysicalRooms: 4,
    imageUrl: 'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?auto=format&fit=crop&w=800&q=80',
    description: 'Exclusive club-tier residence featuring private check-in lounge and complimentary boardroom hours.'
  }
];

// Pre-seeded Users (2 accounts)
export const INITIAL_USERS: User[] = [
  {
    id: 'user-guest-001',
    name: 'Aarav Sharma',
    email: 'user@luxestay.com',
    role: 'USER',
    phone: '+91 98201 54321',
    createdAt: '2026-01-10T10:00:00.000Z'
  },
  {
    id: 'user-admin-001',
    name: 'Vikram Singhania',
    email: 'admin@luxestay.com',
    role: 'ADMIN',
    phone: '+91 98110 88990',
    createdAt: '2025-11-01T08:00:00.000Z'
  }
];

// In-Memory Database store with transactional methods
class LuxeStayDatabase {
  private hotels: Map<string, Hotel> = new Map();
  private roomTypes: Map<string, RoomType> = new Map();
  private physicalRooms: Map<string, PhysicalRoom> = new Map();
  private users: Map<string, User> = new Map();
  private userPasswords: Map<string, string> = new Map(); // email -> password
  private reservations: Map<string, Reservation> = new Map();
  private idempotencyRecords: Map<string, string> = new Map(); // key -> reservationId
  private payments: Map<string, PaymentRecord> = new Map();

  constructor() {
    this.seed();
  }

  public seed(): void {
    // 1. Hotels
    this.hotels.clear();
    for (const h of INITIAL_HOTELS) {
      this.hotels.set(h.id, { ...h });
    }

    // 2. Room Types
    this.roomTypes.clear();
    for (const rt of INITIAL_ROOM_TYPES) {
      this.roomTypes.set(rt.id, { ...rt });
    }

    // 3. Physical Rooms
    this.physicalRooms.clear();
    for (const rt of INITIAL_ROOM_TYPES) {
      for (let i = 1; i <= rt.totalPhysicalRooms; i++) {
        const floor = Math.floor((i - 1) / 5) + 1;
        const roomNum = `${floor}0${(i % 5) || 5}`;
        const physicalId = `pr-${rt.id}-${i}`;
        this.physicalRooms.set(physicalId, {
          id: physicalId,
          hotelId: rt.hotelId,
          roomTypeId: rt.id,
          roomNumber: roomNum,
          floor,
          status: 'AVAILABLE'
        });
      }
    }

    // 4. Users
    this.users.clear();
    this.userPasswords.clear();
    for (const u of INITIAL_USERS) {
      this.users.set(u.id, { ...u });
    }
    this.userPasswords.set('user@luxestay.com', 'user123');
    this.userPasswords.set('admin@luxestay.com', 'admin123');

    // 5. Seed some initial reservations
    this.reservations.clear();
    this.idempotencyRecords.clear();
    this.payments.clear();

    const sampleRes1: Reservation = {
      id: 'res-seed-001',
      bookingRef: 'LX-489210',
      userId: 'user-guest-001',
      guestName: 'Aarav Sharma',
      guestEmail: 'user@luxestay.com',
      guestPhone: '+91 98201 54321',
      hotelId: 'hotel-hyd-heritage',
      hotelName: 'LuxeStay Nizam Heritage Palace',
      roomTypeId: 'rt-hyd-h-jste',
      roomTypeName: 'Junior Nizam Courtyard Suite',
      roomTier: 'Junior Suite',
      checkIn: '2026-10-15',
      checkOut: '2026-10-18',
      numRooms: 1,
      guestsCount: 2,
      totalAmount: 34692,
      currency: 'INR',
      status: 'CONFIRMED',
      paymentMethod: 'CARD',
      paymentStatus: 'SUCCESS',
      idempotencyKey: 'idemp-seed-001',
      createdAt: new Date(Date.now() - 3600000 * 24 * 3).toISOString()
    };
    this.reservations.set(sampleRes1.id, sampleRes1);
    this.idempotencyRecords.set(sampleRes1.idempotencyKey, sampleRes1.id);

    const sampleRes2: Reservation = {
      id: 'res-seed-002',
      bookingRef: 'LX-710433',
      userId: 'user-guest-001',
      guestName: 'Aarav Sharma',
      guestEmail: 'user@luxestay.com',
      guestPhone: '+91 98201 54321',
      hotelId: 'hotel-goa-beach',
      hotelName: 'LuxeStay Serene Palms Beach Resort',
      roomTypeId: 'rt-goa-b-spec',
      roomTypeName: 'Beachfront Plunge Pool Villa',
      roomTier: 'Specialty',
      checkIn: '2026-11-20',
      checkOut: '2026-11-23',
      numRooms: 1,
      guestsCount: 2,
      totalAmount: 65490,
      currency: 'INR',
      status: 'CONFIRMED',
      paymentMethod: 'UPI',
      paymentStatus: 'SUCCESS',
      idempotencyKey: 'idemp-seed-002',
      createdAt: new Date(Date.now() - 3600000 * 24 * 7).toISOString()
    };
    this.reservations.set(sampleRes2.id, sampleRes2);
    this.idempotencyRecords.set(sampleRes2.idempotencyKey, sampleRes2.id);

    // Initial payments
    this.payments.set('pay-seed-001', {
      id: 'pay-seed-001',
      reservationId: sampleRes1.id,
      transactionRef: 'TXN_CARD_489210_OK',
      method: 'CARD',
      amount: 34692,
      status: 'SUCCESS',
      createdAt: sampleRes1.createdAt
    });

    this.payments.set('pay-seed-002', {
      id: 'pay-seed-002',
      reservationId: sampleRes2.id,
      transactionRef: 'UPI_REF_710433_OK',
      method: 'UPI',
      amount: 65490,
      status: 'SUCCESS',
      createdAt: sampleRes2.createdAt
    });
  }

  // Hotels
  public getHotels(): Hotel[] {
    return Array.from(this.hotels.values());
  }

  public getHotelById(id: string): Hotel | undefined {
    return this.hotels.get(id);
  }

  // Room Types
  public getRoomTypes(hotelId?: string): RoomType[] {
    const all = Array.from(this.roomTypes.values());
    if (hotelId) {
      return all.filter(rt => rt.hotelId === hotelId);
    }
    return all;
  }

  public getRoomTypeById(id: string): RoomType | undefined {
    return this.roomTypes.get(id);
  }

  public updateRoomTypeBasePrice(roomTypeId: string, newBasePrice: number): RoomType | undefined {
    const rt = this.roomTypes.get(roomTypeId);
    if (!rt) return undefined;
    rt.basePrice = newBasePrice;
    this.roomTypes.set(roomTypeId, rt);
    return rt;
  }

  public updateTierBasePrices(tier: string, multiplier: number): number {
    let updatedCount = 0;
    for (const [id, rt] of this.roomTypes.entries()) {
      if (rt.tier.toLowerCase() === tier.toLowerCase()) {
        rt.basePrice = Math.round(rt.basePrice * multiplier);
        this.roomTypes.set(id, rt);
        updatedCount++;
      }
    }
    return updatedCount;
  }

  // Physical Rooms & Inventory
  public getPhysicalRooms(roomTypeId?: string): PhysicalRoom[] {
    const all = Array.from(this.physicalRooms.values());
    if (roomTypeId) {
      return all.filter(pr => pr.roomTypeId === roomTypeId);
    }
    return all;
  }

  // Active bookings count for room type (status == 'CONFIRMED' or 'PENDING')
  public getActiveBookedCount(roomTypeId: string): number {
    let count = 0;
    for (const r of this.reservations.values()) {
      if (r.roomTypeId === roomTypeId && (r.status === 'CONFIRMED' || r.status === 'PENDING')) {
        count += r.numRooms;
      }
    }
    return count;
  }

  // Users & Auth
  public getUserByEmail(email: string): User | undefined {
    for (const u of this.users.values()) {
      if (u.email.toLowerCase() === email.toLowerCase()) {
        return u;
      }
    }
    return undefined;
  }

  public getUserById(id: string): User | undefined {
    return this.users.get(id);
  }

  public verifyCredentials(email: string, password: string):User | null {
    const expectedPassword = this.userPasswords.get(email.toLowerCase());
    if (!expectedPassword || expectedPassword !== password) {
      return null;
    }
    return this.getUserByEmail(email) || null;
  }

  public createUser(name: string, email: string, password: string, role: 'USER' | 'ADMIN' = 'USER', phone: string = ''): User {
    const id = `user-${Date.now()}`;
    const user: User = {
      id,
      name,
      email: email.toLowerCase(),
      role,
      phone,
      createdAt: new Date().toISOString()
    };
    this.users.set(id, user);
    this.userPasswords.set(email.toLowerCase(), password);
    return user;
  }

  // Reservations
  public getReservations(userId?: string): Reservation[] {
    const all = Array.from(this.reservations.values());
    if (userId) {
      return all.filter(r => r.userId === userId);
    }
    return all;
  }

  public getReservationById(id: string): Reservation | undefined {
    return this.reservations.get(id);
  }

  public getReservationByRef(ref: string): Reservation | undefined {
    for (const r of this.reservations.values()) {
      if (r.bookingRef.toUpperCase() === ref.toUpperCase()) {
        return r;
      }
    }
    return undefined;
  }

  public getReservationByIdempotencyKey(key: string): Reservation | undefined {
    const resId = this.idempotencyRecords.get(key);
    if (!resId) return undefined;
    return this.reservations.get(resId);
  }

  public createReservation(res: Reservation): Reservation {
    this.reservations.set(res.id, res);
    if (res.idempotencyKey) {
      this.idempotencyRecords.set(res.idempotencyKey, res.id);
    }
    return res;
  }

  public updateReservationStatus(id: string, status: Reservation['status'], paymentStatus?: Reservation['paymentStatus'], refundAmount?: number): Reservation | undefined {
    const res = this.reservations.get(id);
    if (!res) return undefined;
    res.status = status;
    if (paymentStatus) res.paymentStatus = paymentStatus;
    if (refundAmount !== undefined) res.refundAmount = refundAmount;
    this.reservations.set(id, res);
    return res;
  }

  // Payments
  public createPayment(pay: PaymentRecord): PaymentRecord {
    this.payments.set(pay.id, pay);
    return pay;
  }

  public getPaymentsForReservation(resId: string): PaymentRecord[] {
    return Array.from(this.payments.values()).filter(p => p.reservationId === resId);
  }

  public getPayments(): PaymentRecord[] {
    return Array.from(this.payments.values());
  }

  // Clear or reset test reservations
  public resetToSeed(): void {
    this.seed();
  }
}

export const db = new LuxeStayDatabase();
